import java.util.ArrayList;
/**
 * Write a description of class BoxCanyon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BoxCanyon
{
    ArrayList <BoxCanyonUnit> units1 = new ArrayList <BoxCanyonUnit> ();
    ArrayList <BoxCanyonUnit> units2 = new ArrayList <BoxCanyonUnit> ();
    BoxCanyonPlayer[] playerArray = new BoxCanyonPlayer[] {null,null,null};
    BoxCanyonTile[] tileArray = new BoxCanyonTile[] {null,null,null,null,null};
    BoxCanyonImportantStringHolder s;
    /**
     * Constructor for objects of class BoxCanyon
     */
    public BoxCanyon(BoxCanyonImportantStringHolder s)
    {
        this.playerArray[0] = new BoxCanyonPlayer("Green Team",false);
        this.playerArray[1] = new BoxCanyonPlayer("Yellow Team", false);
        this.playerArray[2] = new BoxCanyonPlayer("Uncontrolled", true);
        
        
        this.tileArray[0] = new BoxCanyonTile("Green Base", 0, playerArray[0], new ArrayList<BoxCanyonUnit>(), new ArrayList<BoxCanyonUnit>(),s, 10);        
        this.tileArray[1] = new BoxCanyonTile("Center of the Canyon", 0, playerArray[2], new ArrayList<BoxCanyonUnit>(),new ArrayList<BoxCanyonUnit>(),s, 7.5);
        this.tileArray[2] = new BoxCanyonTile("Yellow Base", 0, playerArray[1], new ArrayList<BoxCanyonUnit>(),new ArrayList<BoxCanyonUnit>(),s, 10);
        this.tileArray[3] = new BoxCanyonTile("The Caverns", 0, playerArray[2], new ArrayList<BoxCanyonUnit>(),new ArrayList<BoxCanyonUnit>(),s, 5);
        this.tileArray[4] = new BoxCanyonTile("The Sheer Walls", 0, playerArray[2], new ArrayList<BoxCanyonUnit>(),new ArrayList<BoxCanyonUnit>(),s, 6.25);
        
        /*tileArray[0].add1(new BoxCanyonUnit (0, 0.1, "Locomotive", playerArray[0], 100));
        tileArray[0].add1(new BoxCanyonUnit (0, 1, "Cathedral", playerArray[0], 100));
        tileArray[0].add1(new BoxCanyonUnit (0, .9, "Trucker", playerArray[0], 100));
        tileArray[0].add1(new BoxCanyonUnit (0, 3, "Alaska", playerArray[0], 100));
        tileArray[0].add1(new BoxCanyonUnit (0, 2, "Oregon", playerArray[0], 100));*/
        ArrayList <String> names = new ArrayList <String> ();
        names.add("Joseph Stalin");
        names.add("Taylor Swift");
        names.add("Helena of Troy");
        names.add("George Washington");
        names.add("Mr. Schreiber");
        names.add("Larry the Cucumber");
        names.add("Donald Trump");
        names.add("Neville Chamberlain");
        names.add("Julius Caesar");
        names.add("Lawrence of Arabia");
        names.add("Joan of Arc");
        names.add("Captian Picard");
        names.add("Bob the Tomato");
        names.add("King Solomon");
        names.add("Luke Skywalker");
        names.add("Mahatma Gandhi");
        names.add("Abraham Lincoln");
        names.add("Claus von Stauffenberg");
        names.add("Sun Tzu");
        names.add("Benjamin Franklin");
        names.add("Nelson Mandela");
        names.add("Leonardo da Vinci");
        names.add("Harrison Ford");
        names.add("Mr. T");
        names.add("K.I.T.T.");
        names.add("Genghis Khan");
        names.add("Montezuma");
        names.add("Arnold Schwarzenegger");
        names.add("Queen Isabela");
        names.add("President Snow");
        names.add("Gandalf the Grey");
        names.add("Louix the Fourteenth");
        names.add("Giuseppe Garibaldi");
        names.add("William of Orange");
        names.add("Mr. Potatohead");
        names.add("Karl Marx");
        names.add("Steve Jobs");
        names.add("Kermit the Frog");
        names.add("Jar Jar Binks");
        names.add("Wesley Crusher");
        names.add("Master Chief");
        names.add("John Wayne");
        names.add("Edward Snowden");
        names.add("Alexander the Great");
        names.add("Archduke Franz Ferdinand");
        names.add("Thor");
        
        double health1 = 2485;
        double health2 = 2500;
        double[] health1Spread = new double[20];
        double[] health2Spread = new double[20];
        double dam1 = 100;
        double dam2 = 100;
        double[] dam1Spread = new double[20];
        double[] dam2Spread = new double[20];
        double h;        
        double ran1h = 0;
        double ran2h = 0; 
        double ran1d = 0;
        double ran2d = 0; 
        for (int i = 0; i < 20;i++)
        {
            h = Math.random();      
            health1Spread[i] = h +.015;
            ran1h = ran1h + h +.015;
            h = Math.random();
            dam1Spread[i] = h +.015;
            ran1d = ran1d + h +.015;
            h = Math.random();
            health2Spread[i] = h +.015;
            ran2h = ran2h + h +.015;
            h = Math.random();
            dam2Spread[i] = h +.015;
            ran2d = ran2d + h +.015;
        }     
        
        for(int i = 0; i < 20;i++)
        {
            tileArray[0].add1(new BoxCanyonUnit (0, dam1*dam1Spread[i]/ran1d, names.remove((int)(Math.random()*names.size())), playerArray[0], health1*health1Spread[i]/ran1h));
            tileArray[2].add2(new BoxCanyonUnit (0, dam2*dam2Spread[i]/ran2d, names.remove((int)(Math.random()*names.size())), playerArray[1], health2*health2Spread[i]/ran2h));
        }
        
        
        //tileArray[0].add1(new BoxCanyonUnit (0, 9.5, names.remove((int)(Math.random()*names.size())), playerArray[0], 160));           
        //tileArray[2].add2(new BoxCanyonUnit (0, 10.1, names.remove((int)(Math.random()*names.size())), playerArray[1], 160));
        
        
        
        units1 = tileArray[0].getUnit1();
        units2 = tileArray[2].getUnit2();
        
        /*tileArray[2].add2(new BoxCanyonUnit (0, 1.1, "Corporal", playerArray[1], 100));
        tileArray[2].add2(new BoxCanyonUnit (0, 1.05, "Gruff", playerArray[1], 100));
        tileArray[2].add2(new BoxCanyonUnit (0, 1.2, "Simon", playerArray[1], 100));
        tileArray[2].add2(new BoxCanyonUnit (0, 1.09, "Bagel", playerArray[1], 100));
        tileArray[2].add2(new BoxCanyonUnit (0, 1.9, "Juan", playerArray[1], 100));*/
        
        
        /*tileArray[0].setAdjecent(tileArray[1], 0);
        tileArray[0].setAdjecent(tileArray[3], 1);
        tileArray[0].setAdjecent(tileArray[4], 2);
        tileArray[1].setAdjecent(tileArray[0], 0);
        tileArray[1].setAdjecent(tileArray[2], 1);
        tileArray[1].setAdjecent(tileArray[3], 2);
        tileArray[2].setAdjecent(tileArray[1], 0);
        tileArray[2].setAdjecent(tileArray[3], 1);
        tileArray[2].setAdjecent(tileArray[4], 2);
        tileArray[3].setAdjecent(tileArray[0], 0);
        tileArray[3].setAdjecent(tileArray[1], 1);
        tileArray[3].setAdjecent(tileArray[2], 2);
        tileArray[4].setAdjecent(tileArray[0], 0);
        tileArray[4].setAdjecent(tileArray[2], 1);
        tileArray[4].setAdjecent(tileArray[4], 2);*/
    }
    
    public void healStuff()
    {
        double heal1 = 0;
        double heal2 = 0;
        for (int i = 0; i < tileArray.length;i++)
        {
            if (tileArray[i].getOwner().getName().equals("Green Team"))
            {
                heal1 = heal1 + tileArray[i].getHeal();
            }
            if (tileArray[i].getOwner().getName().equals("Yellow Team"))
            {
                heal2 = heal2 + tileArray[i].getHeal();
            }
        }
        double[] heal1Spread = new double[units1.size()];
        double[] heal2Spread = new double[units2.size()];
        double h;        
        double ran1 = 0;
        double ran2 = 0;
        for (int i = 0; i < units1.size();i++)
        {
            h = Math.random();
        
            heal1Spread[i] = h;
            ran1 = ran1 + h;
        }
        for (int i = 0; i < units2.size();i++)
        {
            h = Math.random();
            heal2Spread[i] = h;
            ran2 = ran2 + h;
        }
        
        for(int i = 0; i < units1.size();i++)
        {
            units1.get(i).damage(-(heal1*heal1Spread[i]/ran1));
        }
        for(int i = 0; i < units2.size();i++)
        {
            units2.get(i).damage(-(heal2*heal2Spread[i]/ran2));
        }
    }
    
    void removeDead()
    {
        if (units1.size() > 0)
        {
            for (int i = 0; i < units1.size();i++)
            {
                if (units1.get(i).getHealth() <= 0 && units1.size() == 1)
                {
                    units1.remove(i);                   
                    break;
                }
                if (units1.get(i).getHealth() <= 0)
                {
                    units1.remove(i);
                    i = -1;
                }
            }
        }
        if (units2.size() > 0)
        {
                for (int i = 0; i < units2.size();i++)
                {
                    if (units2.get(i).getHealth() <= 0 && units2.size() == 1)
                    {   
                        units2.remove(i);
                        break;
                    }
                    if (units2.get(i).getHealth() <= 0)
                    {
                        units2.remove(i);
                        i = -1;
                    }
                }
        }
    }

    public BoxCanyonTile selectTile(int i)
    {
        return tileArray[i];
    }
    
    public BoxCanyonPlayer selectPlayer(int i)
    {   
        return playerArray[i];
    }
}
