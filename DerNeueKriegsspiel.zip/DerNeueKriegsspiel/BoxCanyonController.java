import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import java.io.InputStream;

import java.io.IOException;

import java.net.URL;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;



import javafx.scene.control.CheckBox;

import javafx.scene.image.Image;

import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
/**
 * Write a description of class BoxCanyonController here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BoxCanyonController
{
    @FXML
    private Button button1;
    @FXML
    private Button button2;
    @FXML
    private Button button3;
    @FXML
    private Button button4;
    @FXML
    private Button button5;
    @FXML
    private Button button6;    
    @FXML
    private Button button7;
    
    @FXML
    private CheckBox checkBox1;
    @FXML
    private CheckBox checkBox2;
    @FXML
    private CheckBox checkBox3;
    @FXML
    private CheckBox checkBox4;
    @FXML
    private CheckBox checkBox5;
    @FXML
    private CheckBox checkBox6;
    @FXML
    private CheckBox checkBox7;
    @FXML
    private CheckBox checkBox8;
    @FXML
    private CheckBox checkBox9;
    @FXML
    private CheckBox checkBox10;
    @FXML
    private CheckBox checkBox11;
    @FXML
    private CheckBox checkBox12;
    @FXML
    private CheckBox checkBox13;
    @FXML
    private CheckBox checkBox14;
    @FXML
    private CheckBox checkBox15;
    @FXML
    private CheckBox checkBox16;
    @FXML
    private CheckBox checkBox17;
    @FXML
    private CheckBox checkBox18;
    @FXML
    private CheckBox checkBox19;
    @FXML
    private CheckBox checkBox20;
    
    
    @FXML
    private Label label;
    
    @FXML
    private ImageView image;
    
    @FXML
    private ImageView victoryImage;
    
    private int turn = 0;
    
    private int input = 6;
    
    private int t1 = 0;
    
    private int t2 = 0;
    
    BoxCanyonImportantStringHolder s = new BoxCanyonImportantStringHolder();
    
    private BoxCanyon boxCanyon = new BoxCanyon(s);
    
    private BoxCanyonPlayer player;
    
        
    
    @FXML
    void button1()
    {
        //Green Base
        player = boxCanyon.selectPlayer(turn);
        if (input != 0 && input != 6)
        {           
            if (player.getName().equals("Green Team"))
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(19, boxCanyon.selectTile(0));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(18, boxCanyon.selectTile(0));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(17, boxCanyon.selectTile(0));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(16, boxCanyon.selectTile(0));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(15, boxCanyon.selectTile(0));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(14, boxCanyon.selectTile(0));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(13, boxCanyon.selectTile(0));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(12, boxCanyon.selectTile(0));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(11, boxCanyon.selectTile(0));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(10, boxCanyon.selectTile(0));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(9, boxCanyon.selectTile(0));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(8, boxCanyon.selectTile(0));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(7, boxCanyon.selectTile(0));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(6, boxCanyon.selectTile(0));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(5, boxCanyon.selectTile(0));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(4, boxCanyon.selectTile(0));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(3, boxCanyon.selectTile(0));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(2, boxCanyon.selectTile(0));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(1, boxCanyon.selectTile(0));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(0, boxCanyon.selectTile(0));
                }
            }
            else
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(19, boxCanyon.selectTile(0));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(18, boxCanyon.selectTile(0));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(17, boxCanyon.selectTile(0));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(16, boxCanyon.selectTile(0));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(15, boxCanyon.selectTile(0));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(14, boxCanyon.selectTile(0));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(13, boxCanyon.selectTile(0));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(12, boxCanyon.selectTile(0));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(11, boxCanyon.selectTile(0));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(10, boxCanyon.selectTile(0));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(9, boxCanyon.selectTile(0));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(8, boxCanyon.selectTile(0));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(7, boxCanyon.selectTile(0));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(6, boxCanyon.selectTile(0));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(5, boxCanyon.selectTile(0));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(4, boxCanyon.selectTile(0));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(3, boxCanyon.selectTile(0));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(2, boxCanyon.selectTile(0));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(1, boxCanyon.selectTile(0));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(0, boxCanyon.selectTile(0));
                }
            }
        }
        
        
        input = 0;       
        
        writeNewText(boxCanyon.selectTile(getInput()).displayOfTile());
        button1.setVisible(false);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(true);
        button5.setVisible(false);
        
    }

    @FXML
    void button2()
    {
        //Caverns
        player = boxCanyon.selectPlayer(turn);
        
        /*if (input != 3 && input != 7 && input != 6)
        { 
            
            if (checkBox5.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) == 5)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 5)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(3));
            }
            if (checkBox4.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 4)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 4)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(3));
            }
            if (checkBox3.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 3)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 3)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(3));
            }
            if (checkBox2.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 2)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 2)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(3));
            }
            if (checkBox1.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 1)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 1)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(3));
            }*/
          /*  if (input != 3 && input != 7 && input != 6)
            {
            if (checkBox5.isSelected())
            {
                boxCanyon.selectTile(getInput()).moveUnit(4, boxCanyon.selectTile(3));
            }
            if (checkBox4.isSelected())
            {
                boxCanyon.selectTile(getInput()).moveUnit(3, boxCanyon.selectTile(3));
            }
            if (checkBox3.isSelected())
            {
                boxCanyon.selectTile(getInput()).moveUnit(2, boxCanyon.selectTile(3));
            }
            if (checkBox2.isSelected())
            {
                boxCanyon.selectTile(getInput()).moveUnit(1, boxCanyon.selectTile(3));
            }
            if (checkBox1.isSelected())
            {
                boxCanyon.selectTile(getInput()).moveUnit(0, boxCanyon.selectTile(3));
            }
        }*/
        
        if (input != 3 && input != 6)
        {           
            if (player.getName().equals("Green Team"))
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(19, boxCanyon.selectTile(3));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(18, boxCanyon.selectTile(3));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(17, boxCanyon.selectTile(3));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(16, boxCanyon.selectTile(3));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(15, boxCanyon.selectTile(3));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(14, boxCanyon.selectTile(3));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(13, boxCanyon.selectTile(3));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(12, boxCanyon.selectTile(3));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(11, boxCanyon.selectTile(3));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(10, boxCanyon.selectTile(3));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(9, boxCanyon.selectTile(3));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(8, boxCanyon.selectTile(3));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(7, boxCanyon.selectTile(3));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(6, boxCanyon.selectTile(3));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(5, boxCanyon.selectTile(3));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(4, boxCanyon.selectTile(3));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(3, boxCanyon.selectTile(3));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(2, boxCanyon.selectTile(3));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(1, boxCanyon.selectTile(3));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(0, boxCanyon.selectTile(3));
                }
            }
            else
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(19, boxCanyon.selectTile(3));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(18, boxCanyon.selectTile(3));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(17, boxCanyon.selectTile(3));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(16, boxCanyon.selectTile(3));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(15, boxCanyon.selectTile(3));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(14, boxCanyon.selectTile(3));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(13, boxCanyon.selectTile(3));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(12, boxCanyon.selectTile(3));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(11, boxCanyon.selectTile(3));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(10, boxCanyon.selectTile(3));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(9, boxCanyon.selectTile(3));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(8, boxCanyon.selectTile(3));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(7, boxCanyon.selectTile(3));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(6, boxCanyon.selectTile(3));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(5, boxCanyon.selectTile(3));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(4, boxCanyon.selectTile(3));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(3, boxCanyon.selectTile(3));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(2, boxCanyon.selectTile(3));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(1, boxCanyon.selectTile(3));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(0, boxCanyon.selectTile(3));
                }
            }
        }
        
        input = 3;
        
        writeNewText(boxCanyon.selectTile(getInput()).displayOfTile());
        
        button1.setVisible(true);
        button2.setVisible(false);
        button3.setVisible(true);
        button4.setVisible(false);
        button5.setVisible(true);
        
    }
    
    @FXML
    void button3()
    {
        //Center of Canyon
        player = boxCanyon.selectPlayer(turn);
        
        if (input != 1 && input != 6)
        {           
            if (player.getName().equals("Green Team"))
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(19, boxCanyon.selectTile(1));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(18, boxCanyon.selectTile(1));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(17, boxCanyon.selectTile(1));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(16, boxCanyon.selectTile(1));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(15, boxCanyon.selectTile(1));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(14, boxCanyon.selectTile(1));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(13, boxCanyon.selectTile(1));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(12, boxCanyon.selectTile(1));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(11, boxCanyon.selectTile(1));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(10, boxCanyon.selectTile(1));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(9, boxCanyon.selectTile(1));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(8, boxCanyon.selectTile(1));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(7, boxCanyon.selectTile(1));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(6, boxCanyon.selectTile(1));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(5, boxCanyon.selectTile(1));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(4, boxCanyon.selectTile(1));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(3, boxCanyon.selectTile(1));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(2, boxCanyon.selectTile(1));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(1, boxCanyon.selectTile(1));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(0, boxCanyon.selectTile(1));
                }
            }
            else
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(19, boxCanyon.selectTile(1));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(18, boxCanyon.selectTile(1));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(17, boxCanyon.selectTile(1));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(16, boxCanyon.selectTile(1));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(15, boxCanyon.selectTile(1));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(14, boxCanyon.selectTile(1));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(13, boxCanyon.selectTile(1));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(12, boxCanyon.selectTile(1));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(11, boxCanyon.selectTile(1));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(10, boxCanyon.selectTile(1));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(9, boxCanyon.selectTile(1));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(8, boxCanyon.selectTile(1));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(7, boxCanyon.selectTile(1));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(6, boxCanyon.selectTile(1));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(5, boxCanyon.selectTile(1));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(4, boxCanyon.selectTile(1));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(3, boxCanyon.selectTile(1));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(2, boxCanyon.selectTile(1));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(1, boxCanyon.selectTile(1));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(0, boxCanyon.selectTile(1));
                }
            }
        }
        
        
       
       
        
        input = 1;
        
        writeNewText(boxCanyon.selectTile(getInput()).displayOfTile());
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(true);
        
    }
    
    @FXML
    void button4()
    {
        //Sheer Wall
        player = boxCanyon.selectPlayer(turn);
        
        
        if (input != 4 && input != 6)
        {           
            if (player.getName().equals("Green Team"))
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(19, boxCanyon.selectTile(4));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(18, boxCanyon.selectTile(4));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(17, boxCanyon.selectTile(4));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(16, boxCanyon.selectTile(4));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(15, boxCanyon.selectTile(4));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(14, boxCanyon.selectTile(4));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(13, boxCanyon.selectTile(4));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(12, boxCanyon.selectTile(4));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(11, boxCanyon.selectTile(4));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(10, boxCanyon.selectTile(4));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(9, boxCanyon.selectTile(4));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(8, boxCanyon.selectTile(4));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(7, boxCanyon.selectTile(4));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(6, boxCanyon.selectTile(4));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(5, boxCanyon.selectTile(4));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(4, boxCanyon.selectTile(4));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(3, boxCanyon.selectTile(4));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(2, boxCanyon.selectTile(4));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(1, boxCanyon.selectTile(4));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(0, boxCanyon.selectTile(4));
                }
            }
            else
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(19, boxCanyon.selectTile(4));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(18, boxCanyon.selectTile(4));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(17, boxCanyon.selectTile(4));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(16, boxCanyon.selectTile(4));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(15, boxCanyon.selectTile(4));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(14, boxCanyon.selectTile(4));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(13, boxCanyon.selectTile(4));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(12, boxCanyon.selectTile(4));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(11, boxCanyon.selectTile(4));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(10, boxCanyon.selectTile(4));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(9, boxCanyon.selectTile(4));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(8, boxCanyon.selectTile(4));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(7, boxCanyon.selectTile(4));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(6, boxCanyon.selectTile(4));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(5, boxCanyon.selectTile(4));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(4, boxCanyon.selectTile(4));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(3, boxCanyon.selectTile(4));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(2, boxCanyon.selectTile(4));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(1, boxCanyon.selectTile(4));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(0, boxCanyon.selectTile(4));
                }
            }
        }
        
        input = 4;
        
        writeNewText(boxCanyon.selectTile(getInput()).displayOfTile());
        button1.setVisible(true);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(true);
        
    }
    
    @FXML
    void button5()
    {
        //Yellow Base
        player = boxCanyon.selectPlayer(turn);
        
        /*if (input != 2 && input != 7 && input != 6)
        {
            if (checkBox5.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) == 5)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 5)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(2));
            }
            if (checkBox4.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 4)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 4)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(2));
            }
            if (checkBox3.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 3)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 3)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(2));
            }
            if (checkBox2.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 2)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 2)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(2));
            }
            if (checkBox1.isSelected() && boxCanyon.selectTile(getInput()).movableFriendlyUnits(player) >= 1)
            {
                int q = 0;
                int h = 0;
                for (int i = 0; i < boxCanyon.selectTile(getInput()).moveableUnitTotal(); i++)
                {
                    if (boxCanyon.selectTile(getInput()).getMoveableUnit(i).getOwner() == player)
                    {
                        q = i;
                        h ++;
                    }
                    if (h == 1)
                    {
                        break;
                    }
                }
                boxCanyon.selectTile(getInput()).moveUnit(q, boxCanyon.selectTile(2));
            }
        }*/
        
        if (input != 2 && input != 6)
        {           
            if (player.getName().equals("Green Team"))
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(19, boxCanyon.selectTile(2));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(18, boxCanyon.selectTile(2));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(17, boxCanyon.selectTile(2));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(16, boxCanyon.selectTile(2));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(15, boxCanyon.selectTile(2));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(14, boxCanyon.selectTile(2));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(13, boxCanyon.selectTile(2));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(12, boxCanyon.selectTile(2));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(11, boxCanyon.selectTile(2));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(10, boxCanyon.selectTile(2));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(9, boxCanyon.selectTile(2));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(8, boxCanyon.selectTile(2));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(7, boxCanyon.selectTile(2));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(6, boxCanyon.selectTile(2));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(5, boxCanyon.selectTile(2));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(4, boxCanyon.selectTile(2));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(3, boxCanyon.selectTile(2));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(2, boxCanyon.selectTile(2));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(1, boxCanyon.selectTile(2));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit1(0, boxCanyon.selectTile(2));
                }
            }
            else
            {
                if (checkBox20.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(19, boxCanyon.selectTile(2));
                }
                if (checkBox19.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(18, boxCanyon.selectTile(2));
                }
                if (checkBox18.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(17, boxCanyon.selectTile(2));
                }
                if (checkBox17.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(16, boxCanyon.selectTile(2));
                }
                if (checkBox16.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(15, boxCanyon.selectTile(2));
                }
                if (checkBox15.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(14, boxCanyon.selectTile(2));
                }
                if (checkBox14.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(13, boxCanyon.selectTile(2));
                }
                if (checkBox13.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(12, boxCanyon.selectTile(2));
                }
                if (checkBox12.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(11, boxCanyon.selectTile(2));
                }
                if (checkBox11.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(10, boxCanyon.selectTile(2));
                }
                if (checkBox10.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(9, boxCanyon.selectTile(2));
                }
                if (checkBox9.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(8, boxCanyon.selectTile(2));
                }
                if (checkBox8.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(7, boxCanyon.selectTile(2));
                }
                if (checkBox7.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(6, boxCanyon.selectTile(2));
                }
                if (checkBox6.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(5, boxCanyon.selectTile(2));
                }
                if (checkBox5.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(4, boxCanyon.selectTile(2));
                }
                if (checkBox4.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(3, boxCanyon.selectTile(2));
                }
                if (checkBox3.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(2, boxCanyon.selectTile(2));
                }
                if (checkBox2.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(1, boxCanyon.selectTile(2));
                }
                if (checkBox1.isSelected())
                {
                    boxCanyon.selectTile(getInput()).moveUnit2(0, boxCanyon.selectTile(2));
                }
            }
        }
        
        input = 2;
        
        writeNewText(boxCanyon.selectTile(getInput()).displayOfTile());
        button1.setVisible(false);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(true);
        button5.setVisible(false);
        
    }
    
    @FXML
    void button6()
    {
        //End Turn
        
        
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(true);
        button5.setVisible(true);
        
        
        turn ++;
        if (turn > 1)
        {
            turn = 0;
        }
                
        player = boxCanyon.selectPlayer(turn);
        
        s.clearBattleReports();
        for (int i = 0; i < 5; i++)
        {
            boxCanyon.selectTile(i).checkForControl(boxCanyon.selectPlayer(0), boxCanyon.selectPlayer(1), boxCanyon.selectPlayer(2));
        }
        
        boxCanyon.healStuff();
        
        for (int i = 0; i < 5; i++)
        {
            if (!boxCanyon.selectTile(i).checkTeam1())
            {
                t1++;
            }
            if (!boxCanyon.selectTile(i).checkTeam2())
            {
                t2++;
            }
            boxCanyon.selectTile(i).healInsteadOfFight();
            boxCanyon.selectTile(i).fight();
            boxCanyon.selectTile(i).giveMoveBack();
            boxCanyon.selectTile(i).bringOutYourDead();
        }
        
        boxCanyon.removeDead();
        
        s.getTurn(player);
        writeNewText(s.getString());
        
        input = 6;
        
        if (t1 == 5)
        {
            team2Win();
        }
        if (t2 == 5)
        {
            team1Win();
        }
        t1 = 0;
        t2 = 0;
    }
    
    @FXML
    void button7()
    {
        //Cancel
        player = boxCanyon.selectPlayer(turn);
        
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(true);
        button5.setVisible(true);
        
        
        writeNewText(s.getString());
        
        input = 6;
    }
    
    void team1Win()
    {
        victoryImage.setVisible(true);
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        checkBox1.setVisible(false);
        checkBox2.setVisible(false);
        checkBox3.setVisible(false);
        checkBox4.setVisible(false);
        checkBox5.setVisible(false);
        checkBox6.setVisible(false);
        checkBox7.setVisible(false);
        checkBox8.setVisible(false);
        checkBox9.setVisible(false);
        checkBox10.setVisible(false);
        checkBox11.setVisible(false);
        checkBox12.setVisible(false);
        checkBox13.setVisible(false);
        checkBox14.setVisible(false);
        checkBox15.setVisible(false);
        checkBox16.setVisible(false);
        checkBox17.setVisible(false);
        checkBox18.setVisible(false);
        checkBox19.setVisible(false);
        checkBox20.setVisible(false);
        image.setVisible(false);
        writeNewText("Green Team has conquered the strategically important box canyon!\n\n" + s.getTheDead());
    }
    
    void team2Win()
    {
        victoryImage.setVisible(true);
        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        button6.setVisible(false);
        button7.setVisible(false);
        checkBox1.setVisible(false);
        checkBox2.setVisible(false);
        checkBox3.setVisible(false);
        checkBox4.setVisible(false);
        checkBox5.setVisible(false);
        checkBox6.setVisible(false);
        checkBox7.setVisible(false);
        checkBox8.setVisible(false);
        checkBox9.setVisible(false);
        checkBox10.setVisible(false);
        checkBox11.setVisible(false);
        checkBox12.setVisible(false);
        checkBox13.setVisible(false);
        checkBox14.setVisible(false);
        checkBox15.setVisible(false);
        checkBox16.setVisible(false);
        checkBox17.setVisible(false);
        checkBox18.setVisible(false);
        checkBox19.setVisible(false);
        checkBox20.setVisible(false);
        image.setVisible(false);
        writeNewText("Yellow Team has conquered the strategically important box canyon!\n\n" + s.getTheDead());
    }
    
    @FXML
    void checkBox1(){}
    
    public int getInput()
    {
        return input;
    }
    
    void writeNewText(String s)
    {
        label.setText(s);
    }
    
    
    
}
