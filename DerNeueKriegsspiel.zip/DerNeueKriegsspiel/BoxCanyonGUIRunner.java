import java.io.FileInputStream;
import java.io.IOException;

import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;



/**
 * Write a description of class TextController1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BoxCanyonGUIRunner extends Application
{
    
    public static void main(String[] args)
    {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws IOException
    {
        URL location = getClass().getResource("Sample GUI.fxml");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(location);
        
        Parent root = (Parent) fxmlLoader.load(location.openStream());

		stage.setTitle("Box Canyon");
		stage.setScene(new Scene(root, 1000, 1000));
		stage.show();
	
    }
}
