import java.util.ArrayList;
/**
 * Write a description of class BoxCanyonImportantStringHolder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BoxCanyonImportantStringHolder
{
    String battleReports;
    String playerTurn;
    String theDead;
    
    /**
     * Constructor for objects of class BoxCanyonImportantStringHolder
     */
    public BoxCanyonImportantStringHolder()
    {
        this.battleReports = "";
        this.playerTurn = "Green Team";
        this.theDead = "";
    }

    public void clearBattleReports()
    {
        battleReports = "";
    }
    
    public void reportPrebattle(String tileName, ArrayList<BoxCanyonUnit> units1 , ArrayList<BoxCanyonUnit> units2)
    {
        battleReports = battleReports + "Battle at " + tileName + ":\nGreen Team: ";
        for (int i = 0; i < units1.size(); i++)
        {
            battleReports = battleReports + units1.get(i).getName() + " with " + Math.round(units1.get(i).getHealth()) + " health, ";     
            if (i != 0 && i%5 == 0)
            {
                battleReports = battleReports + "\n";
            }
        }
        battleReports = battleReports.substring(0,battleReports.length()-2);
        battleReports = battleReports + "\n";        
        battleReports = battleReports + "Yellow Team: ";
        for (int i = 0; i < units2.size(); i++)
        {
            battleReports = battleReports + units2.get(i).getName() + " with " + Math.round(units2.get(i).getHealth()) + " health, ";   
            if (i != 0 && i%5 == 0)
            {
                battleReports = battleReports + "\n";
            }
        }
        battleReports = battleReports.substring(0,battleReports.length()-2);
        battleReports = battleReports + "\n";        
    }
    
    public void reportPostbattle(ArrayList<BoxCanyonUnit> units1 , ArrayList<BoxCanyonUnit> units2)
    {
        battleReports = battleReports + "Green Team's units ended at: ";
        for (int i = 0; i < units1.size(); i++)
        {
            battleReports = battleReports + units1.get(i).getName() + " with " + Math.round(units1.get(i).getHealth()) + " health, ";  
            if (i != 0 && i%5 == 0)
            {
                battleReports = battleReports + "\n";
            }
        }
        battleReports = battleReports.substring(0,battleReports.length()-2);
        battleReports = battleReports + "\n";
        
        battleReports = battleReports + "Yellow Team's units ended at: ";
        for (int i = 0; i < units2.size(); i++)
        {
            battleReports = battleReports + units2.get(i).getName() + " with " + Math.round(units2.get(i).getHealth()) + " health, ";   
            if (i != 0 && i%5 == 0)
            {
                battleReports = battleReports + "\n";
            }
        }
        battleReports = battleReports.substring(0,battleReports.length()-2);
        battleReports = battleReports + "\n";
        
    }
    
    public String getPlayerTurn()
    {
        return playerTurn + "'s turn";
    }
    
    public void getTurn(BoxCanyonPlayer p)
    {
        playerTurn = p.getName();
    }
    
    public String getString()
    {
        String theString = playerTurn + "'s turn\n";
        if(battleReports.equals("") && theDead.equals(""))
        {
           // theString = theString.substring(0,theString.length()-2);
        }
        else if(battleReports.equals(""))
        {
            theString = theString + theDead;            
        }       
        else if(theDead.equals(""))
        {
            theString = theString + battleReports;
           // theString = theString.substring(0,theString.length()-2);
        }
        else
        {
            theString = theString + battleReports + theDead;
        }
             
        return theString;
    }   
    
    public String getTheDead()
    {
        return theDead;
    }
    
    public void reportDeath(BoxCanyonUnit u)
    {
        if (theDead.equals(""))
        {
            theDead = "and let us not forget those who have died including:\n" + u.getName() + " of " + u.getOwner().getName() + ", cause of death: " + getDeathType();
        }
        else
        {
            theDead = theDead + "\n" + u.getName() + " of " + u.getOwner().getName() + ", cause of death: " + getDeathType();
        }
    }
    
    public String getDeathType()
    {   
        double i = Math.random();
        if (i > .95)
        {
            return "Food poisoning";
        }
        else if (i > .9)
        {
            return "Drowning";
        }
        else if (i > .85)
        {
            return "Spontanious combustion";
        }
        else if (i > .8)
        {
            return "Lung cancer";
        }
        else if (i > .75)
        {
            return "Running with scissors";
        }
        else if (i > .7)
        {
            return "Getting stabbed by a fork";
        }
        else if (i > .65)
        {
            return "A bad day at the office";
        }
        else if (i > .6)
        {
            return "Choking on a grape";
        }
        else if (i > .55)
        {
            return "Getting pulled into a black hole";
        }
        else if (i > .5)
        {
            return "Tripping on a rock";
        }
        else if (i > .45)
        {
            return "Falling in lava";
        }
        else if (i > .4)
        {
            return "Getting sent to a 2-dimensional plane of existence";
        }
        else if (i > .35)
        {
            return "Justin Bieber";
        }
        else if (i > .3)
        {
            return "The border patrol";
        }
        else if (i > .25)
        {
            return "An arrow to the knee";
        }
        else if (i > .2)
        {
            return "Hypothermia";
        }
        else if (i > .15)
        {
            return "Getting lost in Siberia";
        }
        else if (i > .1)
        {
            return "Heat stroke";
        }
        else if (i > .05)
        {
            return "Rat poison";
        }
        else
        {
            return "Coffee overdose";
        }
    }
}
