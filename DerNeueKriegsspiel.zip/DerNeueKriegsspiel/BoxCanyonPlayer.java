
/**
 * Write a description of class BoxCanyonPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BoxCanyonPlayer extends Player
{
    

    /**
     * Constructor for objects of class BoxCanyonPlayer
     */
    public BoxCanyonPlayer(String name,  boolean isAI)
    {
        super(name, isAI);
        
    }

    public String toString()
    {
        return "Name: " + name + ", is AI: " + isAI;
    }
}
