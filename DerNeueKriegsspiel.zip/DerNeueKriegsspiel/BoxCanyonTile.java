import java.util.ArrayList;
/**
 * Write a description of class BoxCanyonTile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BoxCanyonTile extends Territory
{
    ArrayList<BoxCanyonUnit> units1;
    ArrayList<BoxCanyonUnit> units2;
    BoxCanyonImportantStringHolder s;
    ArrayList<BoxCanyonUnit> movedUnits1;
    ArrayList<BoxCanyonUnit> movedUnits2;
    double heal;
    /**
     * Constructor for objects of class BoxCanyonTile
     */
    public BoxCanyonTile (String name, int population, BoxCanyonPlayer owner, ArrayList<BoxCanyonUnit> units1, ArrayList<BoxCanyonUnit> units2, BoxCanyonImportantStringHolder s, double heal)
    {
        super(name, population,/*geographicalFeatures,*/ owner);
        this.units1 = units1;
        this.units2 = units2;
        this.movedUnits1 = new ArrayList<BoxCanyonUnit> ();
        this.movedUnits2 = new ArrayList<BoxCanyonUnit> ();
        this.s = s;
        this.heal = heal;
    }
    
    public BoxCanyonPlayer getOwner()
    {
        return (BoxCanyonPlayer)(owner);
    }
    
    public ArrayList<BoxCanyonUnit> getUnit1()
    {
        return units1;
    }
    
    public ArrayList<BoxCanyonUnit> getUnit2()
    {
        return units2;
    }
    
    public double getHeal()
    {
        return heal;
    }
    
    public void checkForControl(BoxCanyonPlayer t1, BoxCanyonPlayer t2, BoxCanyonPlayer t3)
    {
        if (owner != t1 && checkTeam1() && !checkTeam2())
        {
            owner = t1;
        }
        if (owner != t2 && checkTeam2() && !checkTeam1())
        {
            owner = t2;
        }
        if (checkTeam1() && checkTeam2())
        {
            owner = t3;
        }
    }

    public boolean checkTeam1()
    {
        if (units1.size() < 1 && movedUnits1.size() < 1)
        {
            return false;
        }
        return true;
    }
    
    public boolean checkTeam2()
    {
        if (units2.size() < 1 && movedUnits2.size() < 1)
        {
            return false;
        }
        return true;
    }
    
    public void add1(BoxCanyonUnit u)
    {
        units1.add(u);
    }
        
        public void add2(BoxCanyonUnit u)
        {
            units2.add(u);
        }
        
        public int moveableUnitTotal1()
        {
            return units1.size();
        }
        
        public int moveableUnitTotal2()
        {
            return units2.size();
        }
        
        public BoxCanyonUnit getMoveableUnit1(int i)
        {
            return units1.get(i);
        }
        
        public BoxCanyonUnit getMoveableUnit2(int i)
        {
            return units2.get(i);
        }
        
        public int movableFriendlyUnits(BoxCanyonPlayer p)
    {
        int f = 0;
        for (int i = units1.size(); i < 0; i++)
        {
            if (units1.get(i).getOwner() == p )
            {
                f ++;
            }
            
        }
        for (int i = units2.size(); i < 0; i++)
        {
            if (units2.get(i).getOwner() == p )
            {
                f ++;
            }
            
        }
        
        return f;
    }
        
    public String displayOfTile()
        {
            String units1String = "";
            String movedUnits1String = "";
            
            String units2String = "";
            String movedUnits2String = "";
            for (int i = 0; i < units1.size(); i++)
            {
                units1String = units1String + "At position " + (i + 1) + " we have: " + units1.get(i).toString() + ",\n";
                
            }
                        
            if (!units1String.equals(""))
            {
                units1String = units1String.substring(0,units1String.length() - 2);
            }
            
            for (int i = 0; i < units2.size(); i++)
            {
                units2String = units2String + "At position " + (i + 1) + " we have: " + units2.get(i).toString() + ",\n";
                
            }
                        
            if (!units2String.equals(""))
            {
                units2String = units2String.substring(0,units2String.length() - 2);
            }
            
            for (int i = 0; i < movedUnits1.size(); i++)
            {
                movedUnits1String = movedUnits1String + "At position " + (i + 1) + " we have: " + movedUnits1.get(i).toString() + ",\n";
                
            }
            
            if (!movedUnits1String.equals(""))
            {
                movedUnits1String = movedUnits1String.substring(0,movedUnits1String.length() - 2);
            }
            
            for (int i = 0; i < movedUnits2.size(); i++)
            {
                movedUnits2String = movedUnits2String + "At position " + (i + 1) + " we have: " + movedUnits2.get(i).toString() + ",\n";
                
            }
            
            if (!movedUnits2String.equals(""))
            {
                movedUnits2String = movedUnits2String.substring(0,movedUnits2String.length() - 2);
            }
            
            return s.getPlayerTurn() + "\n" + name + ": \nOwner: (" + owner.toString() + ")\nGreen Team Units:\n" + units1String + "\nYellow Team Units:\n" + units2String + "\n Green Team Moved Units:\n" + movedUnits1String + "\nYellow Team Moved Units:\n" + movedUnits2String;
        }
    
    public void healInsteadOfFight()
    {
        if(((units1.size() > 0 || movedUnits1.size() > 0) && !(units2.size() > 0 || movedUnits2.size() > 0)) || (!(units1.size() > 0 || movedUnits1.size() > 0) && (units2.size() > 0 || movedUnits2.size() > 0)))
        {
            for (int i = 0; i < units1.size();i++)
            {   
                units1.get(i).damage(-2);
            }
            for (int i = 0; i < movedUnits1.size();i++)
            {
                movedUnits1.get(i).damage(-2);
            }
            for (int i = 0; i < units2.size();i++)
            {   
                units2.get(i).damage(-2);
            }
            for (int i = 0; i < movedUnits2.size();i++)
            {
                movedUnits2.get(i).damage(-2);
            }
        }
    }
    
    public void fight()
    {
        
        if((units1.size() > 0 || movedUnits1.size() > 0) && (units2.size() > 0 || movedUnits2.size() > 0))
        {
            ArrayList<BoxCanyonUnit> team1 = new ArrayList<BoxCanyonUnit> ();
            ArrayList<BoxCanyonUnit> team2 = new ArrayList<BoxCanyonUnit> ();
            for (int i = 0; i < units1.size();i++)
            {
                team1.add(units1.get(i));
            }
            for (int i = 0; i < movedUnits1.size();i++)
            {
                team1.add(movedUnits1.get(i));
            }
            for (int i = 0; i < units2.size();i++)
            {
                team2.add(units2.get(i));
            }
            for (int i = 0; i < movedUnits2.size();i++)
            {
                team2.add(movedUnits2.get(i));
            }
            s.reportPrebattle(name, team1, team2);
            double dam1 = 0;
            double dam2 = 0;
            for(int i = 10; i < team1.size();i++)
            {
                dam1 = dam1 - .1;
                dam2 = dam2 + .1;
            } 
            for(int i = 15; i < team1.size();i++)
            {
                dam1 = dam1 - .1;
                dam2 = dam2 + .1;
            }
            for(int i = 17; i < team1.size();i++)
            {
                dam1 = dam1 - .2;
                dam2 = dam2 + .2;
            }
            for(int i = 10; i < team2.size();i++)
            {
                dam2 = dam2 - .1;
                dam1 = dam1 + .1;
            } 
            for(int i = 15; i < team2.size();i++)
            {
                dam2 = dam2 - .1;
                dam1 = dam1 + .1;
            }
            for(int i = 17; i < team2.size();i++)
            {
                dam2 = dam2 - .1;
                dam1 = dam1 + .1;
            }
            
            for (int i = 0; i < units1.size(); i++)
            {
                /*if(units1.get(i).getName().equals("Locamotive"))
                {
                    if (Math.random() > .5)
                    {
                        dam1 = dam1 + units1.get(i).combatValue;
                    }
                    else
                    {
                        dam2 = dam2 + units1.get(i).combatValue;
                    }
                }
                else if(units1.get(i).getName().equals("Cathedral"))
                {
                    if (Math.random() < .01)
                    {
                        dam1 = dam1 + (int)units1.get(i).combatValue;
                    }
                
                }
                else 
                {*/
                    if  (Math.random() > .45)
                    {
                        dam1 = dam1 + units1.get(i).combatValue;
                    }
                    else if (Math.random() > .45)
                    {
                        dam1 = dam1 + (units1.get(i).combatValue/2);
                    }                    
                //}
            }
            for (int i = 0; i < movedUnits1.size(); i++)
            {
                /*if(movedUnits1.get(i).getName().equals("Locamotive"))
                {
                    if (Math.random() > .5)
                    {
                        dam1 = dam1 + movedUnits1.get(i).combatValue;
                    }
                    else
                    {
                        dam2 = dam2 + movedUnits1.get(i).combatValue;
                    }
                }
                else if(movedUnits1.get(i).getName().equals("Cathedral"))
                {
                    if (Math.random() < .01)
                    {
                        dam1 = dam1 + (int)movedUnits1.get(i).combatValue;
                    }
                
                }
                else 
                {*/
                    if  (Math.random() > .45)
                    {
                        dam1 = dam1 + movedUnits1.get(i).combatValue;
                    }
                    else if (Math.random() > .45)
                    {
                        dam1 = dam1 + (movedUnits1.get(i).combatValue/2);
                    }                    
                //}
            }
            
            for (int i = 0; i < units2.size(); i++)
            {                             
                    if  (Math.random() > .45)
                    {
                        dam2 = dam2 + units2.get(i).combatValue;
                    }
                    else if (Math.random() > .45)
                    {
                        dam2 = dam2 + (units2.get(i).combatValue/2);
                    }                                  
            }
            for (int i = 0; i < movedUnits2.size(); i++)
            {                             
                    if  (Math.random() > .45)
                    {
                        dam2 = dam2 + movedUnits2.get(i).combatValue;
                    }
                    else if (Math.random() > .45)
                    {
                        dam2 = dam2 + (movedUnits2.get(i).combatValue/2);
                    }                                  
            }
            
            double[] dam1Spread = new double[units1.size() + movedUnits1.size()];
            double[] dam2Spread = new double[units2.size() + movedUnits2.size()];
            double h;
            double t1 = 0;
            double t2 = 0;
            
            for (int i = 0; i < units1.size() + movedUnits1.size();i++)
            {
                h = Math.random();
                dam1Spread[i] = h;
                t1 = t1 + h;
            }
            for(int i = 0; i < units1.size();i++)
            {
                units1.get(i).damage(dam2*dam1Spread[i]/t1);
            }
            for(int i = 0; i < movedUnits1.size();i++)
            {
                movedUnits1.get(i).damage(dam2*dam1Spread[i + units1.size()]/t1);
            }
            
            for (int i = 0; i < units2.size() + movedUnits2.size();i++)
            {
                h = Math.random();
                dam2Spread[i] = h;
                t2 = t2 + h;
            }
            for(int i = 0; i < units2.size();i++)
            {
                units2.get(i).damage(dam1*dam2Spread[i]/t2);
            }
            for(int i = 0; i < movedUnits2.size();i++)
            {
                movedUnits2.get(i).damage(dam1*dam2Spread[i + units2.size()]/t2);
            }
            
            s.reportPostbattle(team1,team2);
        }
         
    }
    
    public void bringOutYourDead()
    {
        if (units1.size() > 0)
        {
            for (int i = 0; i < units1.size();i++)
            {
                if (units1.get(i).getHealth() <= 0 && units1.size() == 1)
                {
                    s.reportDeath(units1.remove(i));                   
                    break;
                }
                if (units1.get(i).getHealth() <= 0)
                {
                    s.reportDeath(units1.remove(i));
                    i = -1;
                }
            }
        }
        if (units2.size() > 0)
        {
                for (int i = 0; i < units2.size();i++)
                {
                    if (units2.get(i).getHealth() <= 0 && units2.size() == 1)
                    {   
                        s.reportDeath(units2.remove(i));
                        break;
                    }
                    if (units2.get(i).getHealth() <= 0)
                    {
                        s.reportDeath(units2.remove(i));
                        i = -1;
                    }
                }
        }
        if (movedUnits1.size() > 0)
        {
            for (int i = 0; i < movedUnits1.size();i++)
            {
                if (movedUnits1.get(i).getHealth() <= 0 && movedUnits1.size() == 1)
                {
                    s.reportDeath(movedUnits1.remove(i));
                    break;
                }
                if (movedUnits1.get(i).getHealth() <= 0)
                {
                    s.reportDeath(movedUnits1.remove(i));
                    i = -1;
                }
            }
        }
        if (movedUnits2.size() > 0)
        {
            for (int i = 0; i < movedUnits2.size();i++)
            {
                if (movedUnits2.get(i).getHealth() <= 0 && movedUnits2.size() == 1)
                {
                    s.reportDeath(movedUnits2.remove(i));
                    break;
                }
                if (movedUnits2.get(i).getHealth() <= 0)
                {
                    s.reportDeath(movedUnits2.remove(i));
                    i = -1;
                }
            }
        }      
        
    }
    
    public void moveUnit1(int pos,BoxCanyonTile t)
    {        
        if (units1.size() > 0 && pos < units1.size())
        {
            if (checkTeam2() && t.getOwner().getName().equals("Yellow Team"))
            {
                   
            }                  
            else
            {
                t.movedUnits1.add(units1.remove(pos));
            }
        }                
    }
    
    public void moveUnit2(int pos,BoxCanyonTile t)
    {        
        if (units2.size() > 0 && pos < units2.size())
        {
            if (checkTeam1() && t.getOwner().getName().equals("Green Team"))
            {
                   
            }     
            else
            {
                t.movedUnits2.add(units2.remove(pos));
            }
        }                
    }
    
    public void giveMoveBack()
    {
        if (movedUnits1.size() > 0)
        {
            for (int i = 0; i < movedUnits1.size();)
            {
                units1.add(movedUnits1.remove(i));
            }
        }
        if (movedUnits2.size() > 0)
        {
            for (int i = 0; i < movedUnits2.size();)
            {
                units2.add(movedUnits2.remove(i));
            }
        }
    }
}
