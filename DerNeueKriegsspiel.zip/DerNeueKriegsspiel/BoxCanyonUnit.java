
/**
 * Write a description of class BoxCanyonUnit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BoxCanyonUnit extends Unit
{
    BoxCanyonPlayer owner;
    double health;
    
    /**
     * Constructor for objects of class BoxCanyonUnit
     */
    public BoxCanyonUnit(int move,  double combatValue, String unitType, BoxCanyonPlayer owner, double health)
    {
        super(move, combatValue, unitType);
        this.owner = owner;
        this.health = health;
    }
        
        public String toString()
        {
            return getName() + ", Combat Value: " + (double)(Math.round(combatValue) + ((double)(Math.round(10*combatValue)-(Math.round(combatValue)*10))/10))   + ", Owner: " + owner.getName() + ", Health: " + Math.round(health);
        }
    
        public BoxCanyonPlayer getOwner()
        {
            return owner;
        }
        
        public String getName()
        {
            return unitType;
        }
        
        public void damage(double i)
        {
            health = health - i;
        }
        
        public double getHealth()
        {
            return health;
        }
      /*
       * public void fight()
        {
            
        }*/
}
