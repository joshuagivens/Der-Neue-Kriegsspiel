 

import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * 
 * This class is the entry point for the Java FX Font Editor GUI application. It
 * uses the FontFileEditorFX.fxml XML file for layout of components.
 * 
 * <pre>
 * Revision History
 * PCR      Version   Author          Date        Comment
 * C2075    000       jack         Apr 24, 2015     Class Created.
 * </pre>
 * 
 * @author jack
 * @version {@value #VERSION}
 */
public class FontFileEditor extends Application {

	public static void main(String[] args) {
		Application.launch(FontFileEditor.class, args);
	}




	@Override
	public void start(Stage stage) throws Exception {
		// Parent root =
		// FXMLLoader.load(getClass().getResource("FontFileEditorFX.fxml"));
		URL location = getClass().getResource("FontFileEditorFX.fxml");
		FXMLLoader fxmlLoader = new FXMLLoader();
		fxmlLoader.setLocation(location);
		fxmlLoader.setBuilderFactory(new JavaFXBuilderFactory());
		Parent root = (Parent) fxmlLoader.load(location.openStream());

		stage.setTitle("CIS Font Editor");
		stage.setScene(new Scene(root, 1000, 1000));
		stage.show();

		FontFileEditorController controller = fxmlLoader.getController();
		controller.loadTestFontFile();
	}
}
