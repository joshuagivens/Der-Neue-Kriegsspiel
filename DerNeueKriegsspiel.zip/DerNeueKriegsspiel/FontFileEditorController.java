 

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBoxBuilder;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import mil.army.lt2.jmrc.symbols.Constants;
import mil.army.lt2.jmrc.symbols.fonts.CisFontChar;
import mil.army.lt2.jmrc.symbols.fonts.CisFontFile;
import mil.army.lt2.jmrc.symbols.sidc.SymbolException;

/**
 * 
 * This class acts as the controller for the Java FX GUI font editor
 * application.
 * 
 * <pre>
 * Revision History
 * PCR      Version   Author          Date        Comment
 * C2075    000       jack         Apr 24, 2015     Class Created.
 * </pre>
 * 
 * @author jack
 * @version {@value #VERSION}
 */
public class FontFileEditorController {
	private static final boolean DEBUG = Constants.DEBUG;
	private int zoomRatio = 1;
	@FXML
	Label charDesc;
	@FXML
	private MenuItem menuLoadFile;
	@FXML
	private MenuItem menuSaveFile;
	@FXML
	private MenuItem menuExit;
	@FXML
	private MenuItem menuDrawModeDraw;
	@FXML
	private MenuItem menuDrawModeErase;
	@FXML
	private MenuItem menuDrawModeToggle;
	@FXML
	private Button buttonSaveChar;
	private CisFontFile fontFile;

	@FXML
	private TableView tableFontSelector;
	@FXML
	private TableColumn colFontIndex;
	@FXML
	private TableColumn colFontIcon;

	@FXML
	private ImageView imageView;
	private WritableImage writeableImage;

	@FXML
	private Label labelFontChars;
	private javafx.scene.paint.Color colorFXBG = javafx.scene.paint.Color.rgb(
			Constants.COLOR_SYMBOL_BACKGROUND.getGreen(), Constants.COLOR_SYMBOL_BACKGROUND.getGreen(),
			Constants.COLOR_SYMBOL_BACKGROUND.getBlue());
	private javafx.scene.paint.Color colorFXFG = javafx.scene.paint.Color.rgb(
			Constants.COLOR_SYMBOL_FOREGROUND.getGreen(), Constants.COLOR_SYMBOL_FOREGROUND.getGreen(),
			Constants.COLOR_SYMBOL_FOREGROUND.getBlue());

	private boolean charModified = false;
	/**
	 * Set when to match the a char when first selected. This BufferedImage is
	 * updated as the user makes edits. When a save is required this image can
	 * be used to save back to char.
	 */
	private BufferedImage currentCharBufferedImage;
	private CisFontChar selectedChar;
	private ObservableList<CisFontChar> fontCharsObservableList;
	private File selectedFile;




	public FontFileEditorController() {
		log("FontFileEditorController()", "Starting controller...");

	}




	/**
	 * Saves the current edits to the current char
	 *
	 * @pre init complete.
	 * @post no change to object.
	 */
	@FXML
	public void saveChar() {
		if (DEBUG)
			log("saveChar()", "Saving changes to char " + selectedChar);

		// Save original offsets and dimensions...
		int offsetCenterToBaseline = selectedChar.getOffsetCenterToBaseline();
		int offsetCenterToLeft = selectedChar.getOffsetCenterToLeft();
		int bitMapRows = selectedChar.getBitMapRows();
		int bitMapColumns = selectedChar.getBitMapColumns();
		selectedChar.drawWithBufferedImage(currentCharBufferedImage, Constants.COLOR_SYMBOL_BACKGROUND);
		/*
		 * Because of presumed rounding error we reset the char offsets and
		 * dimensions
		 */
		selectedChar.setOffsetCenterToBaseline(offsetCenterToBaseline);
		selectedChar.setOffsetCenterToLeft(offsetCenterToLeft);
		// selectedChar.setBitMapRows(bitMapRows);
		// selectedChar.setBitMapColumns(bitMapColumns);

		// Now update the char in the original CisFontFile object
		try {
			this.fontFile.put(selectedChar);
		} catch (SymbolException e) {
			showUserException(e);
		}

		// save done, set char as unmodified (since last save)
		this.charModified = false;
	}




	/**
	 * This method is called when the user clicks on a row in the editor (see
	 * FontFileEditorFX.fxml).
	 * 
	 * @see https
	 *      ://blog.idrsolutions.com/2012/11/convert-bufferedimage-to-javafx
	 *      -image/
	 */
	@FXML
	void loadChar() {
		if (this.charModified) {
			this.saveChar();
		}

		selectedChar = (CisFontChar) this.tableFontSelector.getSelectionModel().getSelectedItem();
		log("loadChar", "called. Clicked char " + selectedChar);
		this.currentCharBufferedImage = selectedChar.getBufferedImage(Constants.COLOR_SYMBOL_FOREGROUND,
				Constants.COLOR_SYMBOL_BACKGROUND);

		// nice for debug
		if (false) {
			Graphics g = currentCharBufferedImage.getGraphics();
			g.setColor(Color.BLUE);
			int xMid = currentCharBufferedImage.getWidth() / 2;
			int yMid = currentCharBufferedImage.getHeight() / 2;
			g.drawLine(xMid, 0, xMid, currentCharBufferedImage.getHeight());
			g.drawLine(0, yMid, currentCharBufferedImage.getWidth(), yMid);
		}
		// Set zoom ratio
		int ratioX = Constants.SVG_WIDTH / currentCharBufferedImage.getWidth();
		int ratioY = Constants.SVG_HEIGHT / currentCharBufferedImage.getHeight();
		if (ratioX < ratioY) {
			zoomRatio = ratioX;
		} else {
			zoomRatio = ratioY;
		}
		if (DEBUG)
			log("loadChar", "Setting zoomRatio to " + zoomRatio);

		if (currentCharBufferedImage != null) {
			// WritableImage writeableImage = SwingFXUtils.toFXImage(bi, null);
			writeableImage = null;
			writeableImage = new WritableImage(currentCharBufferedImage.getWidth() * zoomRatio,
					currentCharBufferedImage.getHeight() * zoomRatio);
			PixelWriter pw = writeableImage.getPixelWriter();
			for (int x = 0; x < currentCharBufferedImage.getWidth(); x++) {
				for (int y = 0; y < currentCharBufferedImage.getHeight(); y++) {
					int zoomedX = x * zoomRatio;
					int zoomedY = y * zoomRatio;
					pw.setArgb(zoomedX, zoomedY, currentCharBufferedImage.getRGB(x, y));
					for (int xval = 0; xval < zoomRatio; xval++) {
						for (int yval = 0; yval < zoomRatio; yval++) {
							pw.setArgb(zoomedX + xval, zoomedY + yval, currentCharBufferedImage.getRGB(x, y));
						}
					}
				}
			}
			// this.imageView.setScaleX(ZOOMFACTOR);
			// this.imageView.setScaleY(ZOOMFACTOR);
			this.imageView.setFitHeight(0);
			this.imageView.setFitWidth(0);
			this.imageView.setImage(writeableImage);
			this.labelFontChars.setText(selectedChar.getFontCharLine());
		}
		this.charModified = false;
	}




	@FXML
	void mousePressDraw(MouseEvent me) {
		javafx.scene.paint.Color colorFound = writeableImage.getPixelReader()
				.getColor((int) me.getX(), (int) me.getY());
		javafx.scene.paint.Color drawColor;
		Color biColor;
		if (colorFound.equals(colorFXBG)) {
			log("mousePressDraw", "draw at x=" + me.getX() + ", y=" + me.getY() + ", colorFound=" + colorFound);
			drawColor = this.colorFXFG;
			biColor = Constants.COLOR_SYMBOL_FOREGROUND;
		} else {
			log("mousePressDraw", "erase at x=" + me.getX() + ", y=" + me.getY() + ", colorFound=" + colorFound
					+ " is not " + colorFXBG);
			drawColor = this.colorFXBG;
			biColor = Constants.COLOR_SYMBOL_BACKGROUND;
		}

		int drawX = ((int) me.getX() / zoomRatio) * zoomRatio;
		int drawY = ((int) me.getY() / zoomRatio) * zoomRatio;
		for (int spreadX = 0; spreadX < this.zoomRatio; spreadX++) {
			for (int spreadY = 0; spreadY < this.zoomRatio; spreadY++) {
				writeableImage.getPixelWriter().setColor(drawX + spreadX, drawY + spreadY, drawColor);
			}
		}
		// update BufferedImage to use for saves to selected char...
		this.currentCharBufferedImage.setRGB(drawX / zoomRatio, drawY / zoomRatio, biColor.getRGB());
		charModified = true;
	}




	@FXML
	protected void exit() {
		log("exit()", "exiting");
		Platform.exit();
	}




	private static void log(String methodName, String message) {
		System.out.println(FontFileEditorController.class.getSimpleName() + "." + methodName + ": " + message);
	}




	@FXML
	void openFontFileChooser() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open Resource File");
		// fileChooser.getExtensionFilters().addAll(new
		// ExtensionFilter("Any File", "*.*"));
		File dialogSelectedFile = fileChooser.showOpenDialog(null);
		if (dialogSelectedFile != null) {
			try {

				loadFontFile(dialogSelectedFile);
			} catch (SymbolException e) {
				showUserException(e);
			}
		}
	}




	private void showUserException(Exception e) {
		e.printStackTrace();

		Stage dialogStage = new Stage();
		dialogStage.initModality(Modality.WINDOW_MODAL);
		dialogStage.setScene(new Scene(VBoxBuilder.create()
				.children(new Text("Exception: " + e.toString()), new Button("Ok.")).alignment(Pos.CENTER)
				.padding(new Insets(5)).build()));
		dialogStage.show();
	}




	private void loadFontFile(File fontFileFile) throws SymbolException {
		this.selectedFile = fontFileFile;
		log("loadFontFile", "Loading font file " + selectedFile);
		fontFile = new CisFontFile(selectedFile);
		fontCharsObservableList = FXCollections.observableArrayList(fontFile.getFontChars());
		tableFontSelector.setItems(fontCharsObservableList);
		// setup table columns
		colFontIndex
				.setCellValueFactory(new Callback<CellDataFeatures<CisFontChar, String>, ObservableValue<String>>() {
					public ObservableValue<String> call(CellDataFeatures<CisFontChar, String> p) {
						// p.getValue() returns the Person instance for a
						// particular TableView row
						CisFontChar theChar = p.getValue();
						return new SimpleStringProperty(theChar, "index", theChar.getCharIndex().toString());
					}
				});
		colFontIcon.setCellValueFactory(new Callback<CellDataFeatures<CisFontChar, String>, ObservableValue<String>>() {
			public ObservableValue<String> call(CellDataFeatures<CisFontChar, String> p) {
				// p.getValue() returns the Person instance for a
				// particular TableView row
				CisFontChar theChar = p.getValue();
				return new SimpleStringProperty(theChar, "index", theChar.getComment());
			}
		});

	}




	/**
	 * Calling this will write out all changes to the chars made by the user...
	 * 
	 * @throws SymbolException
	 *
	 * @pre init complete.
	 * @post no change to object.
	 */
	@FXML
	public void saveFontFile() {
		try {
			if (this.charModified) {
				this.saveChar();
			}
			this.fontFile.writeFontFile(selectedFile);
			log("saveFontFile", "Saved font file edits to " + selectedFile);
		} catch (IOException e) {
			showUserException(e);
		}
	}




	/**
	 *
	 * @pre init complete.
	 * @post no change to object.
	 */
	public void loadTestFontFile() {
		try {
			File fFile = new File(
					"/Users/jack/Documents/raytheon/projects/mil2525_for_cis/java_projects/MilSymbolTools/unit_test/font.player-friendly");
			if (fFile.exists()) {
				loadFontFile(fFile);
				log("loadTestFontFile", "Loaded test font file " + fFile);
			}
		} catch (SymbolException e) {
			showUserException(e);
		}
	}
}