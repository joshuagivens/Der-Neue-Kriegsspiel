
/**
 * Abstract class Player - write a description of the class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public  class Player
{
    
    boolean isAI;
    String name;

    public Player(String name, boolean isAI)
    {
         
        this.name = name;
        this.isAI = isAI;
    }
    
    public String getName()
    {
        return name;
    }
}
