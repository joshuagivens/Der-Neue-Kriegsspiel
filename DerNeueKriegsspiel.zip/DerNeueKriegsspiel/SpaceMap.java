import java.util.ArrayList;
/**
 * Write a description of class SpaceMap here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMap
{
    ArrayList <SpaceMapPlanet> planets;
    //SpaceMapPlanet[][] thePlanets;
    SpaceMapPlayer[] players;
    SpaceMapPlanet selectedPlanet;
    SpaceMapPlayer playerTurn;
    short turnCount;
    /**
     * Constructor for objects of class SpaceMap
     */
    public SpaceMap(int computerPlayers, boolean secondHuman)
    {
        if (computerPlayers > 19 && secondHuman)
        {
            computerPlayers = 19;
        }
        else if(computerPlayers > 20)
        {
            computerPlayers = 20;
        }
        //this.thePlanets = new SpaceMapPlanet[16][10];
        this.planets = new ArrayList <SpaceMapPlanet> ();
        short q = 1;
        if(secondHuman)
        {
            q++;
        }
        this.players = new SpaceMapPlayer[computerPlayers + q];
        ArrayList <String[]> countryNames = new ArrayList <String[]> ();
        countryNames.add(new String[] {"Greenland", "Greenlandic"});
        countryNames.add(new String[] {"Luxembourg", "Luxembourgish"});
        countryNames.add(new String[] {"Antarctica", "Antarctic"});
        countryNames.add(new String[] {"the Arctic", "Arctic"});
        countryNames.add(new String[] {"Jamaica", "Jamaican"});
        countryNames.add(new String[] {"the Vatican", "Vatican"});
        countryNames.add(new String[] {"Puerto Rico", "Puerto Rican"});
        countryNames.add(new String[] {"Corsica", "Corsican"});
        countryNames.add(new String[] {"Kuwait", "Kuwaiti"});
        countryNames.add(new String[] {"Baveria", "Baverian"});
        countryNames.add(new String[] {"Iceland", "Icelandic"});
        countryNames.add(new String[] {"Switzerland", "Swiss"});
        countryNames.add(new String[] {"Malta", "Maltese"});
        countryNames.add(new String[] {"Sicily", "Sicilian"});
        countryNames.add(new String[] {"Sardinia", "Sardinian"});
        countryNames.add(new String[] {"Ireland", "Irish"});
        countryNames.add(new String[] {"Finland", "Finnish"});
        countryNames.add(new String[] {"Estonia", "Estonian"});
        countryNames.add(new String[] {"Latvia", "Latvian"});
        countryNames.add(new String[] {"Lithuania", "Lithuanian"});
        countryNames.add(new String[] {"Latvia", "Latvian"});
        ArrayList <String[]> countryDescriptions = new ArrayList <String[]> ();
        countryDescriptions.add(new String[] {"The Kingdom of 0", ""});
        countryDescriptions.add(new String[] {"The 1", " Empire"});
        countryDescriptions.add(new String[] {"The 1", " Union"});
        countryDescriptions.add(new String[] {"The 1", " Confederation"});
        countryDescriptions.add(new String[] {"The 1", " Democratic Republic"});
        countryDescriptions.add(new String[] {"The United 1", " Emirates"});
        countryDescriptions.add(new String[] {"The United States of 0", ""});
        countryDescriptions.add(new String[] {"The Federal Republic of 0", ""});
        countryDescriptions.add(new String[] {"The Peoples Republic of 0", ""});
        countryDescriptions.add(new String[] {"The Republic of 0", ""});
        countryDescriptions.add(new String[] {"The Union of 1", " Republics"});
        countryDescriptions.add(new String[] {"The 1", " Commonwealth"});
        countryDescriptions.add(new String[] {"The Democratic Peoples Republic of 0", ""});
        //countryDescriptions.add(new String[] {"2", " and "});
        ArrayList <String> playerNames = new ArrayList <String> ();
        for (short i = 0; i < countryNames.size();)
        {
            short k = (short)(Math.random()*countryDescriptions.size());
            if (countryDescriptions.get(k)[0].substring(countryDescriptions.get(k)[0].length()-1).equals("0"))
            {
                playerNames.add(countryDescriptions.get(k)[0].substring(0, countryDescriptions.get(k)[0].length()-1) + countryNames.remove((int)(Math.random()*countryNames.size()))[0] + countryDescriptions.get(k)[1]);     
            }
            else if(countryDescriptions.get(k)[0].substring(countryDescriptions.get(k)[0].length()-1).equals("2") && countryNames.size() > 1)
            {
                playerNames.add(countryDescriptions.get(k)[0].substring(0, countryDescriptions.get(k)[0].length()-1) + countryNames.remove((int)(Math.random()*countryNames.size()))[0] + countryDescriptions.get(k)[1] + countryNames.remove((int)(Math.random()*countryNames.size()))[0]);
            }
            else
            {
                playerNames.add(countryDescriptions.get(k)[0].substring(0, countryDescriptions.get(k)[0].length()-1) + countryNames.remove((int)(Math.random()*countryNames.size()))[1] + countryDescriptions.get(k)[1]);
            }
        }

        ArrayList <String> names = new ArrayList <String> ();
        names.add("Joseph Stalin");
        names.add("Taylor Swift");
        names.add("Helena of Troy");
        names.add("George Washington");
        names.add("Mr. Schreiber");
        names.add("Larry the Cucumber");
        names.add("Donald Trump");
        names.add("Neville Chamberlain");
        names.add("Julius Caesar");
        names.add("Lawrence of Arabia");
        names.add("Joan of Arc");
        names.add("Captian Picard");
        names.add("Bob the Tomato");
        names.add("King Solomon");
        names.add("Luke Skywalker");
        names.add("Mahatma Gandhi");
        names.add("Abraham Lincoln");
        names.add("Claus von Stauffenberg");
        names.add("Sun Tzu");
        names.add("Benjamin Franklin");
        names.add("Nelson Mandela");
        names.add("Leonardo da Vinci");
        names.add("Harrison Ford");
        names.add("Mr. T");
        names.add("K.I.T.T.");
        names.add("Genghis Khan");
        names.add("Montezuma");
        names.add("Arnold Schwarzenegger");
        names.add("Queen Isabela");
        names.add("President Snow");
        names.add("Gandalf the Grey");
        names.add("Louix the Fourteenth");
        names.add("Giuseppe Garibaldi");
        names.add("William of Orange");
        names.add("Mr. Potatohead");
        names.add("Karl Marx");
        names.add("Steve Jobs");
        names.add("Kermit the Frog");
        names.add("Jar Jar Binks");
        names.add("Wesley Crusher");
        names.add("Master Chief");
        names.add("John Wayne");
        names.add("Edward Snowden");
        names.add("Alexander the Great");
        names.add("Archduke Franz Ferdinand");
        names.add("Thor");
        names.add("Joshua Givens");
        names.add("Jack Givens");
        names.add("Angela Merkel");
        names.add("Regret");
        names.add("Truth");
        names.add("Mercy");

        ArrayList<String> nullNames = new ArrayList<String> ();
        for(short i = 0; i < computerPlayers*16; i++)
        {
            nullNames.add("null name");
        }

        boolean usesBothCapitals = false;

        this.players[0] = new SpaceMapPlayer (playerNames.remove((int)(playerNames.size()*Math.random())), (short)(4*Math.random()), (short)4, (short)3, (short)1/*(short)(6*Math.random()), (short)(3*Math.random()), (short)(5*Math.random()),*/, usesBothCapitals, names, (short)0);
        //this.players[0] = new SpaceMapAIPlayer (playerNames.remove((int)(playerNames.size()*Math.random())), (short)(4*Math.random()), (short)4, (short)3, (short)1/*(short)(6*Math.random()), (short)(3*Math.random()), (short)(5*Math.random())*/, usesBothCapitals, nullNames, (short)1, (short)0);

        this.players[0].setSelf(players[0]);
        usesBothCapitals = false;

        if(secondHuman)
        {
            this.players[1] = new SpaceMapPlayer (playerNames.remove((int)(playerNames.size()*Math.random())), (short)(4*Math.random()), (short)4, (short)3, (short)1/*(short)(6*Math.random()), (short)(3*Math.random()), (short)(5*Math.random()),*/, usesBothCapitals, names, (short)0);
            this.players[1].setSelf(players[1]);
            for(short i = 2; i < players.length;i++)
            {
                this.players[i] = new SpaceMapAIPlayer (playerNames.remove((int)(playerNames.size()*Math.random())), (short)(4*Math.random()), (short)4, (short)3, (short)1/*(short)(6*Math.random()), (short)(3*Math.random()), (short)(5*Math.random())*/, usesBothCapitals, nullNames, (short)1, (short)0);
                this.players[i].setSelf(players[i]);
            }
        }
        else
        {
            for(short i = 1; i < players.length;i++)
            {
                this.players[i] = new SpaceMapAIPlayer (playerNames.remove((int)(playerNames.size()*Math.random())), (short)(4*Math.random()), (short)4, (short)3, (short)1/*(short)(6*Math.random()), (short)(3*Math.random()), (short)(5*Math.random())*/, usesBothCapitals, nullNames, (short)1, (short)0);
                this.players[i].setSelf(players[i]);
            }
        }

        ArrayList <String> planetNames = new ArrayList <String> ();
        planetNames.add("Pluto");
        planetNames.add("Mars");
        planetNames.add("Mercury");
        planetNames.add("Venus");
        planetNames.add("Earth");
        planetNames.add("Jupiter");
        planetNames.add("Neptune");
        // planetNames.add("Schreiber");
        // planetNames.add("Givens");
        planetNames.add("Hörmansdorf");
        planetNames.add("Regensburg");
        planetNames.add("Regensberg");
        planetNames.add("Cairo");
        planetNames.add("Bayern");
        planetNames.add("München");
        planetNames.add("Munich");
        planetNames.add("Berlin");
        planetNames.add("Hamburg");
        planetNames.add("Schweinfurt");
        planetNames.add("Frankfurt");
        planetNames.add("Nuremburg");
        planetNames.add("Rome");
        planetNames.add("Germany");
        planetNames.add("France");
        planetNames.add("Italy");
        planetNames.add("Paris");
        planetNames.add("Versialles");
        planetNames.add("Dresden");
        planetNames.add("Leningrad");
        planetNames.add("St. Petersburg");
        planetNames.add("Stalingrad");
        planetNames.add("Moscow");
        planetNames.add("Vladivostok");
        planetNames.add("Egypt");
        planetNames.add("Jordan");
        planetNames.add("Prussia");
        planetNames.add("Austria");
        planetNames.add("Viena");
        planetNames.add("Switzerland");
        planetNames.add("Bern");
        planetNames.add("Zurich");
        planetNames.add("Copenhagen");
        planetNames.add("Brasilia");
        planetNames.add("Brazil");
        planetNames.add("Brasil");
        planetNames.add("Geneva");
        planetNames.add("Denmark");
        planetNames.add("Norway");
        planetNames.add("Stavanger");
        planetNames.add("Oslo");
        planetNames.add("Stockholm");
        planetNames.add("Sweden");
        planetNames.add("Belgium");
        planetNames.add("Brussels");
        planetNames.add("Quebec");
        planetNames.add("Montreal");
        planetNames.add("Nova Scotia");
        planetNames.add("New Brunswick");
        planetNames.add("Newfoundland");
        planetNames.add("Labrador");
        planetNames.add("Ontario");
        planetNames.add("Ottawa");
        planetNames.add("Toronto");
        planetNames.add("Manitoba");
        planetNames.add("Saskatchewan");
        planetNames.add("British Columbia");
        planetNames.add("Alberta");
        planetNames.add("Vancouver");
        planetNames.add("Edmonton");
        planetNames.add("Calgary");
        planetNames.add("Victoria");
        planetNames.add("Chigago");
        planetNames.add("York");
        planetNames.add("New York");
        planetNames.add("Washington");
        planetNames.add("Spain");
        planetNames.add("Portugal");
        planetNames.add("Lisbon");
        planetNames.add("Madrid");
        planetNames.add("Jacksterdam");
        planetNames.add("Amsterdam");
        planetNames.add("New Amsterdam");
        planetNames.add("Barcalona");
        planetNames.add("Tangiers");
        planetNames.add("Morroco");
        planetNames.add("Algeria");
        planetNames.add("Algiers");
        planetNames.add("Tunis");
        planetNames.add("Tunisia");
        planetNames.add("Carthage");
        planetNames.add("Dallas");
        planetNames.add("Cinncinati");
        planetNames.add("Los Angeles");
        planetNames.add("San Diego");
        planetNames.add("San Francisco");
        planetNames.add("Sacramento");
        planetNames.add("Rocklin");
        planetNames.add("Boise");
        planetNames.add("Las Vegas");
        planetNames.add("Trenton");
        planetNames.add("Albany");
        planetNames.add("Boston");
        planetNames.add("Richmond");
        planetNames.add("Baltimore");
        planetNames.add("St. Louis");
        planetNames.add("Baton Rouge");
        planetNames.add("Montgomery");
        planetNames.add("Dublin");
        planetNames.add("Ireland");
        planetNames.add("England");
        planetNames.add("Wales");
        planetNames.add("Scotland");
        planetNames.add("Britain");
        planetNames.add("Austin");
        planetNames.add("London");
        planetNames.add("Glasgow");
        planetNames.add("Texas");
        planetNames.add("Mexico");
        planetNames.add("New Mexico");
        planetNames.add("Arizona");
        planetNames.add("Phoenix");
        planetNames.add("California");
        planetNames.add("Oregon");
        planetNames.add("Salem");
        planetNames.add("Idaho");
        planetNames.add("Nevada");
        planetNames.add("Utah");
        planetNames.add("Montana");
        planetNames.add("Deseret");
        planetNames.add("Colorado");
        planetNames.add("Florida");
        planetNames.add("Georgia");
        planetNames.add("Azerbajan");
        planetNames.add("Armenia");
        planetNames.add("Maine");
        planetNames.add("Vermont");
        planetNames.add("Massachusetts");
        planetNames.add("Connecticut");
        planetNames.add("New England");
        planetNames.add("Pennsylvania");
        planetNames.add("New Jersey");
        planetNames.add("Virginia");
        planetNames.add("Dakota");
        planetNames.add("Tahoe");
        planetNames.add("Wyoming");
        planetNames.add("Ohio");
        planetNames.add("Delaware");
        planetNames.add("Maryland");
        planetNames.add("Carolina");
        planetNames.add("Tennesee");
        planetNames.add("Memphis");
        planetNames.add("Kansas");
        planetNames.add("Kentucky");
        planetNames.add("Illinois");
        planetNames.add("Puerto Rico");
        planetNames.add("Costa Rica");
        planetNames.add("San Salvador");
        planetNames.add("El Salvador");
        planetNames.add("Managua");
        planetNames.add("Nicaragua");
        planetNames.add("Masaya");
        planetNames.add("Leon");
        planetNames.add("Honduras");
        planetNames.add("Panama");
        planetNames.add("Belize");
        planetNames.add("Guatemala");
        planetNames.add("Indiana");
        planetNames.add("Wisconsin");
        planetNames.add("Michigan");
        planetNames.add("Eire");
        planetNames.add("Erie");
        planetNames.add("Nebraska");
        planetNames.add("Iowa");
        planetNames.add("Mississippi");
        planetNames.add("Minnesota");
        planetNames.add("Alaska");
        planetNames.add("Hawaii");
        planetNames.add("Missouri");
        planetNames.add("Oklahoma");
        planetNames.add("Omaha");
        planetNames.add("Louisiana");
        planetNames.add("New Hampshire");
        planetNames.add("Arkansas");
        planetNames.add("Greenland");
        planetNames.add("Raykjavik");
        planetNames.add("Iceland");
        planetNames.add("Cuba");
        planetNames.add("Havana");
        planetNames.add("Habana");
        planetNames.add("Santo Domingo");
        planetNames.add("Marseille");
        planetNames.add("Hannover");
        planetNames.add("Saxony");
        planetNames.add("Köln");
        planetNames.add("Hesse");
        planetNames.add("Leipzig");
        planetNames.add("Zürich");
        planetNames.add("Brandenburg");
        planetNames.add("Rostock");
        planetNames.add("Bremerhaven");
        planetNames.add("Kiel");
        planetNames.add("Salzburg");
        planetNames.add("Grenada");
        planetNames.add("Russia");
        planetNames.add("Moldovia");
        planetNames.add("Romania");
        planetNames.add("Poland");
        planetNames.add("Belorus");
        planetNames.add("Lithuania");
        planetNames.add("Latvia");
        planetNames.add("Finland");
        planetNames.add("Estonia");
        planetNames.add("Kazakhstan");
        planetNames.add("Uzbekistan");
        planetNames.add("Turkmenistan");
        planetNames.add("Korea");
        planetNames.add("Seoul");
        planetNames.add("Pyongyang");
        planetNames.add("Japan");
        planetNames.add("Tokyo");
        planetNames.add("Warsaw");
        planetNames.add("Danzig");
        planetNames.add("Königsberg");
        planetNames.add("Kaliningrad");
        planetNames.add("Helsinki");
        planetNames.add("Maputo");
        planetNames.add("Mozambique");
        planetNames.add("Alexandria");
        planetNames.add("Libya");
        planetNames.add("Tripoli");
        planetNames.add("Toranto");
        planetNames.add("Greece");
        planetNames.add("Crete");
        planetNames.add("Cyprus");
        planetNames.add("Malta");
        planetNames.add("India");
        planetNames.add("Calcutta");
        planetNames.add("New Delhi");
        planetNames.add("Delhi");
        planetNames.add("Vietnam");
        planetNames.add("Cambodia");
        planetNames.add("Macedonia");
        planetNames.add("Argentina");
        planetNames.add("Chile");
        planetNames.add("Bolivia");
        planetNames.add("Paraguay");
        planetNames.add("Uruguay");
        planetNames.add("Peru");
        planetNames.add("Ecuador");
        planetNames.add("Venezuala");
        planetNames.add("Columbia");
        planetNames.add("Quito");
        planetNames.add("Lima");
        planetNames.add("Santiago");
        planetNames.add("Buanos Aires");
        planetNames.add("Star");
        planetNames.add("Nampa");
        planetNames.add("España");
        planetNames.add("Lebanon");
        planetNames.add("Beirut");
        planetNames.add("Jordan");
        planetNames.add("Amman");
        planetNames.add("Holstein");
        planetNames.add("Haiti");
        planetNames.add("Sudan");
        planetNames.add("Angola");
        planetNames.add("Africa");
        planetNames.add("America");
        planetNames.add("Europe");
        planetNames.add("Asia");
        planetNames.add("Australia");
        planetNames.add("Austria");
        planetNames.add("Macedonia");
        planetNames.add("Skopje");
        planetNames.add("Bulgaria");
        planetNames.add("Yugoslavia");
        planetNames.add("Serbia");
        planetNames.add("Belgrade");
        planetNames.add("Budapest");
        planetNames.add("Hungary");
        planetNames.add("Belfast");
        planetNames.add("Bucharest");
        planetNames.add("Slovenia");
        planetNames.add("Slovakia");
        planetNames.add("Czechoslovakia");
        planetNames.add("Bohemia");
        planetNames.add("Moravia");
        planetNames.add("Prague");
        planetNames.add("Silesia");
        planetNames.add("Pretoria");
        planetNames.add("Bloemfont");
        planetNames.add("Johannesburg");
        planetNames.add("Guazapa");
        planetNames.add("Beijing");
        planetNames.add("Hanio");
        planetNames.add("Hainan");
        planetNames.add("Taiwan");
        planetNames.add("Honshu");
        planetNames.add("Hokkaido");
        planetNames.add("Kyushu");
        planetNames.add("Mongolia");
        planetNames.add("China");
        planetNames.add("Kyrgyzstan");
        planetNames.add("Tajikistan");
        planetNames.add("Afganistan");
        planetNames.add("Pakistan");
        planetNames.add("Nepal");
        planetNames.add("Oman");
        planetNames.add("Yemen");
        planetNames.add("Qatar");
        planetNames.add("Kuwait");
        planetNames.add("Iraq");
        planetNames.add("Baghdad");
        planetNames.add("Iran");
        planetNames.add("Tehran");
        planetNames.add("Dar es Salaam");
        planetNames.add("Tanzania");
        planetNames.add("Tanganyika");
        planetNames.add("Zanzibar");
        planetNames.add("Kenya");
        planetNames.add("Uganda");
        planetNames.add("Somalia");
        planetNames.add("Ethiopia");
        planetNames.add("Eritrea");
        planetNames.add("Chad");
        planetNames.add("Myanmar");
        planetNames.add("Burma");
        planetNames.add("Thailand");
        planetNames.add("Laos");
        planetNames.add("Malaysia");
        planetNames.add("Indonesia");
        planetNames.add("Singapore");
        planetNames.add("New Guinea");
        planetNames.add("Sri Lanka");
        planetNames.add("Zimbabwe");
        planetNames.add("Congo");
        planetNames.add("Cameroon");
        planetNames.add("Kamerun");
        planetNames.add("Nigeria");
        planetNames.add("Niger");
        planetNames.add("Mali");
        planetNames.add("Mauritania");
        planetNames.add("Svalbard");
        planetNames.add("Karachi");
        planetNames.add("Phnom Penh");
        planetNames.add("Java");
        planetNames.add("Sumatra");
        planetNames.add("Borneo");
        planetNames.add("Celebes");
        planetNames.add("Timor");
        planetNames.add("New Zealand");
        planetNames.add("Manila");
        planetNames.add("Luzon");
        planetNames.add("Jakarta");
        planetNames.add("Guyana");
        planetNames.add("Suriname");
        planetNames.add("Guiana");
        planetNames.add("Ghana");
        planetNames.add("Côte D'Ivoire");
        planetNames.add("Togo");
        planetNames.add("Guinea");
        planetNames.add("Sierra Leone");
        planetNames.add("Liberia");
        planetNames.add("Kabul");
        planetNames.add("Minsk");
        planetNames.add("Kiev");
        planetNames.add("Syria");
        planetNames.add("Damascus");
        planetNames.add("Rio de Janeiro");
        planetNames.add("Bangkok");
        planetNames.add("Fiji");
        planetNames.add("Croatia");
        planetNames.add("Bahrain");
        planetNames.add("Riyadh");
        planetNames.add("Sardinia");
        planetNames.add("Corsica");
        planetNames.add("Athens");
        planetNames.add("Sparta");
        planetNames.add("Istanbul");
        planetNames.add("Ankara");
        planetNames.add("Turkey");
        planetNames.add("Liechtenstein");
        planetNames.add("Albania");
        planetNames.add("Bombay");
        planetNames.add("Mumbia");
        planetNames.add("Bangalore");
        planetNames.add("Shanghai");
        planetNames.add("Osaka");
        planetNames.add("Essen");
        planetNames.add("São Paulo");
        planetNames.add("Addis Ababa");
        planetNames.add("Québec");
        planetNames.add("Halifax");
        planetNames.add("Winnipeg");
        planetNames.add("Regina");
        planetNames.add("Nunavut");
        planetNames.add("Yukon");
        planetNames.add("Denver");
        planetNames.add("Milwaukee");
        planetNames.add("Detroit");
        planetNames.add("Toledo");
        planetNames.add("Concord");
        planetNames.add("Augusta");
        planetNames.add("Norfolk");
        planetNames.add("Philadelphia");
        planetNames.add("Savannah");
        planetNames.add("Atlanta");
        planetNames.add("Tampa");
        planetNames.add("Jackson");
        planetNames.add("Tallahassee");
        planetNames.add("Miami");
        planetNames.add("Orlando");
        planetNames.add("Birmingham");
        planetNames.add("Springfield");
        planetNames.add("Santa Fe");
        planetNames.add("Portland");
        planetNames.add("Seattle");
        planetNames.add("Honolulu");
        planetNames.add("Juneau");
        planetNames.add("Anchorage");
        planetNames.add("Buffalo");
        planetNames.add("Newark");
        planetNames.add("Campeche");
        planetNames.add("Oaxaca");
        planetNames.add("Veracruz");
        planetNames.add("Guadalajara");
        planetNames.add("Zacatecas");
        planetNames.add("Sonora");
        planetNames.add("Acapulco");
        planetNames.add("Sofia");
        planetNames.add("Venice");
        planetNames.add("Milan");
        planetNames.add("Genoa");
        planetNames.add("Lyon");
        planetNames.add("Canberra");
        planetNames.add("Queensland");
        planetNames.add("New Britain");
        planetNames.add("Sydney");
        planetNames.add("Derby");
        planetNames.add("Tasmania");
        planetNames.add("Wellington");
        planetNames.add("Perth");
        planetNames.add("Darwin");
        planetNames.add("Newcastle");
        planetNames.add("Samoa");
        planetNames.add("Polynesia");
        planetNames.add("New Caledonia");
        planetNames.add("Palau");
        planetNames.add("The Netherlands");
        planetNames.add("The Hague");
        planetNames.add("Die Schweiz");
        planetNames.add("Mordor");
        planetNames.add("Bluefields");
        planetNames.add("Malta");

        short r = 0;
        short r2d2 = 0;
        /*for(short i = 0; i < thePlanets.length;i++)
        {
        for(short j = 0; j < thePlanets[i].length;j++)
        {
        r = (short)(9*Math.random());
        r2d2 = (short)Math.round(Math.random());
        this.thePlanets[i][j] = new SpaceMapPlanet (planetNames.remove((short)(Math.random()*planetNames.size())), r, players[r2d2],players);
        }
        }*/

        for (short i = 0; i < 98/*307*/;i++)
        {
            r = (short)(9*Math.random());
            r2d2 = (short)(Math.random()*players.length);
            this.planets.add(new SpaceMapPlanet (planetNames.remove((short)(Math.random()*planetNames.size())), r, players[r2d2],players, i));
            this.planets.get(i).fixFleetsLocation(planets.get(i));
            players[r2d2].addPlanet(planets.get(i));
        }

        for(int i = 0; i < 13; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+1));
            this.planets.get(i+1).setAdjecent(planets.get(i));

            this.planets.get(i).setAdjecent(planets.get(i+15));
            this.planets.get(i+15).setAdjecent(planets.get(i));
        }
        for(int i = 0; i < 14; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+14));
            this.planets.get(i+14).setAdjecent(planets.get(i));
        }

        for(int i = 14; i < 27; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+1));
            this.planets.get(i+1).setAdjecent(planets.get(i));

            this.planets.get(i).setAdjecent(planets.get(i+14));
            this.planets.get(i+14).setAdjecent(planets.get(i));
        }
        for(int i = 14; i < 28; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+13));
            this.planets.get(i+13).setAdjecent(planets.get(i));
        }

        for(int i = 28; i < 41; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+1));
            this.planets.get(i+1).setAdjecent(planets.get(i));

            this.planets.get(i).setAdjecent(planets.get(i+15));
            this.planets.get(i+15).setAdjecent(planets.get(i));
        }
        for(int i = 28; i < 42; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+14));
            this.planets.get(i+14).setAdjecent(planets.get(i));
        }

        for(int i = 42; i < 55; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+1));
            this.planets.get(i+1).setAdjecent(planets.get(i));

            this.planets.get(i).setAdjecent(planets.get(i+14));
            this.planets.get(i+14).setAdjecent(planets.get(i));
        }
        for(int i = 42; i < 56; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+13));
            this.planets.get(i+13).setAdjecent(planets.get(i));
        }

        for(int i = 56; i < 69; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+1));
            this.planets.get(i+1).setAdjecent(planets.get(i));

            this.planets.get(i).setAdjecent(planets.get(i+15));
            this.planets.get(i+15).setAdjecent(planets.get(i));
        }
        for(int i = 56; i < 70; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+14));
            this.planets.get(i+14).setAdjecent(planets.get(i));
        }

        for(int i = 70; i < 83; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+1));
            this.planets.get(i+1).setAdjecent(planets.get(i));

            this.planets.get(i).setAdjecent(planets.get(i+14));
            this.planets.get(i+14).setAdjecent(planets.get(i));
        }
        for(int i = 70; i < 84; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+13));
            this.planets.get(i+13).setAdjecent(planets.get(i));
        }

        for(int i = 84; i < 97; i++)
        {
            this.planets.get(i).setAdjecent(planets.get(i+1));
            this.planets.get(i+1).setAdjecent(planets.get(i));

            //this.planets.get(i).setAdjecent(planets.get(i+15));
            //this.planets.get(i+15).setAdjecent(planets.get(i));
        }        

        /*ArrayList <SpaceMapPlanet> p1Planets = players[0].getPlanets();
        players[0].setCapital(p1Planets.get((short)(Math.random()*p1Planets.size())));
        if(players[0].usesBothCapitals())
        {
            while(players[0].capitalCheck() || players[0].getAlternateCapital() == null)
            {
                players[0].setAlternateCapital(p1Planets.get((short)(Math.random()*p1Planets.size())));             
            }
        }
        ArrayList <SpaceMapPlanet> p2Planets = players[1].getPlanets();
        players[1].setCapital(p2Planets.get((short)(Math.random()*p2Planets.size())));
        if(players[1].usesBothCapitals())
        {
            while(players[1].capitalCheck() || players[1].getAlternateCapital() == null)
            {
                players[1].setAlternateCapital(p2Planets.get((short)(Math.random()*p2Planets.size())));             
            }
        }*/

        for(short i = 0; i < players.length;i++)
        {
            for(short j = 0; j < players.length; j++)
            {
                if(i != j)
                {
                    players[i].addEnemy(players[j]);
                }
            }
        }

        this.playerTurn = players[0];
        this.turnCount = 0;
    }
    
    public String listPlayers()
    {
        String s = "";
        for(short i = 0; i < players.length; i++)
        {
            s = s + players[i].getName() + " with " + players[i].planetCount() + " planets and a fleet size of " + players[i].getFleetSize();
            if(players[i] instanceof SpaceMapAIPlayer)
            {
                s = s + " (AI)";
            }
            else
            {
                s = s + " (Human)";
            }
            s = s + "\n";
        }
        return s.substring(0, s.length()-1);
    }

    public String getPlanetDescription()
    {
        if(selectedPlanet == null)
        {
            return "No planet selected";
        }
        return selectedPlanet.getDescription();
    }
    
    public short getDifficulty()
    {
        short i = 0;
        while(true)
        {
            if(players[i] instanceof SpaceMapAIPlayer)
            {
                return ((SpaceMapAIPlayer)players[i]).getDifficulty();
            }
            i++;
        }
    }
    
    public void changeDifficulty(short i)
    {
        for(short q = 0; q < players.length; q++)
        {
            if(players[q] instanceof SpaceMapAIPlayer)
            {
                ((SpaceMapAIPlayer)players[q]).changeDifficulty(i);
            }
        }
    }

    public String getPlayerDescription()
    {
        if(playerTurn == null)
        {
            return "FATAL ERROR!!!";
        }
        return playerTurn.getDescription();
    }

    public String getPlayerResourceList()
    {
        return playerTurn.getResourcesForLabel();
    }

    public String getPlanetNames()
    {
        String theString = "";
        for (int i = 0; i < planets.size(); i++)
        {
            theString = theString + planets.get(i).getName() + " " + planets.get(i).getOwner().getName() + ", " ;
        }
        return theString.substring(0,theString.length()-2);
    }

    public void selectPlanet(int i)
    {
        if(selectedPlanet != null)
        {
            SpaceMapFleet selectedFleet = selectedPlanet.getFleet(playerTurn);
            if(planets.get(i).getOwner() == playerTurn)
            {
                selectedFleet.moveShip(planets.get(i));
                players[0].reintegrateShips();
                players[1].reintegrateShips();
            }
            else if(planets.get(i).checkAdjecentOwner(playerTurn))
            {
                selectedFleet.moveShip(planets.get(i));
                players[0].reintegrateShips();
                players[1].reintegrateShips();
            }
        }
        selectedPlanet = planets.get(i);
    }

    public void cancel()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).cancel();
        }       
    }

    public void scrap()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).scrap();
        }       
    }

    public void scrapAll()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).scrapAll();
        }       
    }

    public void selectAll()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).selectAll();
        }
    }

    public String selectedShip()
    {
        if(selectedPlanet != null)
        {
            SpaceMapFleet selectedFleet = selectedPlanet.getFleet(playerTurn);
            //selectedFleet.selectShip(i);
            if(selectedFleet.getSelected() != null)
            {
                return selectedFleet.getSelected().getDescription();
            }
            else if(selectedFleet.fleetSize() == 0)
            {
                return "No ship to select!";
            }
            else
            {
                return "No ship selected!";
            }
        }
        else
        {
            return "No planet selected!";
        }
    }

    public void upgradeUranium()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).upgradeUranium();
        }
    }

    public void upgradeTitanium()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).upgradeTitanium();
        }
    }

    public void autoUpgrade()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).autoUpgrade();
        } 
    }

    public void autoUpgrade(SpaceMapPlanet p)
    {
        if(p != null)
        {
            p.getFleet(playerTurn).autoUpgrade();
        } 
    }

    public void upgradePromethium()
    {
        if(selectedPlanet != null)
        {
            selectedPlanet.getFleet(playerTurn).upgradePromethium();
        }        
    }

    public void selectShip(short i)
    {
        if(selectedPlanet != null)
        {
            SpaceMapFleet selectedFleet = selectedPlanet.getFleet(playerTurn);
            selectedFleet.selectShip(i);
            /*if(selectedFleet.getSelected() != null)
            {
            return selectedFleet.getSelected().getDescription();
            }
            else
            {
            return "No ship to select!";
            }*/
        }
    }

    public String getShipList()
    {

        if(selectedPlanet != null)
        {
            SpaceMapFleet selectedFleet = selectedPlanet.getFleet(playerTurn);
            if (selectedFleet.fleetSize() > 0)
            {
                return "Your Ships:\n" + selectedFleet.listFleet() /*"Ships"*/;
            }
            else
            {
                return "You do not have any ships at this planet!";
            }
        }
        else
        {
            return "No planet selected!";
        }

    }

    public String getParasites()
    {
        return playerTurn.getParasites();
    }

    public String getPresident()
    {
        return playerTurn.president();
    }

    public String getVicePresident()
    {
        return playerTurn.vicePresident();
    }

    public String getCommander()
    {
        return playerTurn.commander();
    }

    public String getSubCommander()
    {
        return playerTurn.subCommander();
    }

    public String getTreasury()
    {
        return playerTurn.treasury();
    }

    public String getForeign()
    {
        return playerTurn.foreign();
    }

    public String getCouncil()
    {
        return playerTurn.council();
    }

    public String getScience()
    {
        return playerTurn.science();
    }

    public void changePresident(short i)
    {
        playerTurn.switchPresident(i);
    }

    public void changeVicePresident(short i)
    {
        playerTurn.switchVicePresident(i);
    }

    public void changeCommander(short i)
    {
        playerTurn.switchCommander(i);
    }

    public void changeSubCommander(short i)
    {
        playerTurn.switchSubCommander(i);
    }

    public void changeTreasury(short i)
    {
        playerTurn.switchTreasury(i);
    }

    public void changeForeign(short i)
    {
        playerTurn.switchForeign(i);
    }

    public void changeCouncil(short i)
    {
        playerTurn.switchCouncil(i);
    }

    public void changeScience(short i)
    {
        playerTurn.switchScience(i);
    }

    public String getEnemyShipList()
    {

        if(selectedPlanet != null)
        {
            SpaceMapPlayer p = null;
            if(playerTurn == players[0])
            {
                p = players[1];
            }
            else
            {
                p = players[0];
            }
            SpaceMapFleet selectedFleet = selectedPlanet.getFleet(p);
            if (selectedFleet.fleetSize() > 0)
            {
                return "Enemy Ships:\n" + selectedFleet.listFleet() /*"Ships"*/;
            }
            else
            {
                return "There are no enemy ships at this planet!";
            }
        }
        else
        {
            return "No planet selected!";
        }

    }

    public String getQueue()
    {
        return playerTurn.getQueue();
    }

    public void addQueueItem(short i)
    {
        if(selectedPlanet != null && selectedPlanet.getOwner() == playerTurn)
        {
            playerTurn.addQueueItem(selectedPlanet, i);
        }
    }

    public void addQueueItem(short i,boolean b)
    {
        if(selectedPlanet != null && selectedPlanet.getOwner() == playerTurn && !b)
        {
            playerTurn.addQueueItem(selectedPlanet, i);
        }
        else if(playerTurn.getPlanets().size() > 0 && b)
        {
            playerTurn.addQueueItem(playerTurn.getPlanets().get((short)(playerTurn.getPlanets().size()*Math.random())), i);
        }
    }

    public void endTurn()
    {
        playerTurn.endTurnStuff();
        playerTurn.checkEnemies();
        if (playerTurn == players[players.length-1])
        {
            playerTurn = players[0];
            turnCount ++;
        }
        else
        {
            for(short i = 0; i < players.length-1; i++)
            {
                if(playerTurn == players[i])
                {
                    playerTurn = players[i+1];
                    break;
                }
            }
        }

        for(short i = 0; i < players.length; i++)
        {
            players[i].reintegrateShips();
        }

        if (playerTurn instanceof SpaceMapAIPlayer /*&& turnCount < 60*/)
        {
            doAITurn();
        }
        /*else if(playerTurn instanceof SpaceMapAIPlayer && turnCount < 70 && turnCount > 60)
        {
        doAITurn();
        }*/
    }

    public boolean[] checkBorder()
    {
        return null;
    }

    public void doAITurn()
    {
        //Update Threats
        double maxFleet = 0;
        double minBorderFleet = playerTurn.getFleetSize();
        for(short i = 0; i < 2; i++)
        {
            if(players[i] != playerTurn)
            {
                if(players[i].getFleetSize() > maxFleet)
                {
                    maxFleet = players[i].getFleetSize();
                }
                if(players[i].borders(playerTurn) && players[i].getFleetSize() < minBorderFleet)
                {
                    minBorderFleet = players[i].getFleetSize();
                }
            }            
        }
        ((SpaceMapAIPlayer)(playerTurn)).updateFleetAnalysisSize(maxFleet,minBorderFleet);
        //Update Mode
        ((SpaceMapAIPlayer)(playerTurn)).updateMode();
        //Research
        if(((SpaceMapAIPlayer)(playerTurn)).getMode() == 0)
        {
            if(turnCount == 0)
            {
                for(short i = 0; i < 3; i++)
                {
                    if(playerTurn.enoughFood())
                    {
                        researchMoney();
                        researchFood();
                        researchIndustry();
                        researchMetal();                                            
                    }
                    else
                    {
                        researchFood();
                        researchMoney();                    
                        researchIndustry();
                        researchMetal();      
                    }
                }
            }
            else
            {
                if(playerTurn.enoughFood())
                {
                    researchMoney();
                    researchFood();
                    researchIndustry();
                    researchMetal();                                            
                }
                else
                {
                    researchFood();
                    researchMoney();                    
                    researchIndustry();
                    researchMetal();      
                }
            }
        }
        else if(((SpaceMapAIPlayer)(playerTurn)).getMode() == 1)
        {
            for(short i = 0; i < 2; i++)
            {
                if(playerTurn.enoughFood())
                {
                    researchMoney();
                    researchFood();
                    researchIndustry();
                    researchMetal();                                            
                }
                else
                {
                    researchFood();
                    researchMoney();                    
                    researchIndustry();
                    researchMetal();      
                }
            }
            researchDefense();
            researchWeapons();
        }
        else if(((SpaceMapAIPlayer)(playerTurn)).getMode() == 2)
        {
            for(short i = 0; i < 2; i++)
            {
                if(playerTurn.enoughFood())
                {
                    researchDefense();
                    researchWeapons();
                    researchMoney();
                    researchFood();
                    researchIndustry();
                    researchMetal();                                            
                }
                else
                {
                    researchFood();
                    researchDefense();
                    researchWeapons();
                    researchMoney();                    
                    researchIndustry();
                    researchMetal();      
                }
            }
        }
        else if(((SpaceMapAIPlayer)(playerTurn)).getMode() == 3)
        {            
            for(short i = 0; i < 2; i++)
            {
                researchDefense();   
                researchWeapons();
            }      
        }
        //Population growth rate adjustment.
        ((SpaceMapAIPlayer)playerTurn).setGrowthRate();

        //Upgrades ships.
        /*for(short i = 0; i < playerTurn.getPlanets().size();i++)
        {
        autoUpgrade(playerTurn.getPlanets().get(i));
        }*/

        //Moves the AI's ships.
        ((SpaceMapAIPlayer)playerTurn).setFleetBase();
        ((SpaceMapAIPlayer)playerTurn).collectShips();
        ((SpaceMapAIPlayer)playerTurn).checkForScrap();
        if(playerTurn.getEnemyAttacks().size() > 0)
        {
            if(Math.random() < .75)
            {
                ((SpaceMapAIPlayer)playerTurn).defendAndProbe();
            }
            else
            {
                ((SpaceMapAIPlayer)playerTurn).moveForDefense();
            }
        }
        else if (Math.random() < .25)
        {
            ((SpaceMapAIPlayer)playerTurn).invadeForReal();
        }
        else if(Math.random() < .75)
        {
            ((SpaceMapAIPlayer)playerTurn).probeAttack();
        }

        //Sets the AI's queue.
        if(playerTurn.getEnemyAttacks().size() == 0)
        {
            ((SpaceMapAIPlayer)playerTurn).setQueue(turnCount);
        }
        else
        {
            ((SpaceMapAIPlayer)playerTurn).setQueue(turnCount, playerTurn.getEnemyAttacks());
        }
        //playerTurn.addQueueItem(playerTurn.getPlanets().get((short)(Math.random()*playerTurn.getPlanets().size())),(short)0);

        //Ends the AI's turn.
        endTurn();
    }

    public String getPlayerRares()
    {
        return playerTurn.getRares();
    }

    public void cancelQueue(short i)
    {
        playerTurn.cancelQueueItem(i);
    }

    public void cancelQueue()
    {
        playerTurn.emptyQueue();
    }

    public double getFoodResearchCost()
    {
        return playerTurn.getFoodResearchCost();
    }

    public double getMetalResearchCost()
    {
        return playerTurn.getMetalResearchCost();
    }

    public double getIndustryResearchCost()   
    {
        return playerTurn.getIndustryResearchCost();
    } 

    public double getMoneyResearchCost()  
    {
        return playerTurn.getMoneyResearchCost();
    }   

    public double getShieldsResearchCost()   
    {
        return playerTurn.getShieldsResearchCost();
    }

    public double getWeaponsResearchCost()
    {
        return playerTurn.getWeaponsResearchCost();
    }

    public void researchFood()
    {
        playerTurn.researchFoodTech();
    }

    public void researchMoney()
    {
        playerTurn.researchMoneyTech();
    }

    public void researchMetal()
    {
        playerTurn.researchMetalTech();
    }

    public void researchIndustry()
    {
        playerTurn.researchIndustryTech();
    }

    public void researchWeapons()
    {
        playerTurn.researchAttackTech();
    }

    public void researchDefense()
    {
        playerTurn.researchDefenseTech();
    }

    public void changeRate(double d)
    {
        playerTurn.setGrowthRate(d);
    }
}
