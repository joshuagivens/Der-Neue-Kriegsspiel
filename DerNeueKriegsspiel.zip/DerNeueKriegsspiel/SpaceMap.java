import java.util.ArrayList;
/**
 * Write a description of class SpaceMap here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMap
{
    ArrayList <SpaceMapPlanet> planets;
    SpaceMapPlayer[] players;
    SpaceMapPlanet selectedPlanet;
    SpaceMapPlayer playerTurn;
    int turnCount;
    /**
     * Constructor for objects of class SpaceMap
     */
    public SpaceMap()
    {
        this.planets = new ArrayList <SpaceMapPlanet> ();
        this.players = new SpaceMapPlayer[2];
        ArrayList <String[]> countryNames = new ArrayList <String[]> ();
        countryNames.add(new String[] {"Greenland", "Greenlandic"});
        countryNames.add(new String[] {"Luxembourg", "Luxembourgish"});
        countryNames.add(new String[] {"Antarctica", "Antarctic"});
        countryNames.add(new String[] {"the Arctic", "Arctic"});
        countryNames.add(new String[] {"Jamaica", "Jamaican"});
        countryNames.add(new String[] {"the Vatican", "Vatican"});
        countryNames.add(new String[] {"Puerto Rico", "Puerto Rican"});
        countryNames.add(new String[] {"Corsica", "Corsican"});
        countryNames.add(new String[] {"Kuwait", "Kuwaiti"});
        countryNames.add(new String[] {"Baveria", "Baverian"});
        countryNames.add(new String[] {"Iceland", "Icelandic"});
        countryNames.add(new String[] {"Trump", "Trumpian"});
        ArrayList <String[]> countryDescriptions = new ArrayList <String[]> ();
        countryDescriptions.add(new String[] {"The Kingdom of 0", ""});
        countryDescriptions.add(new String[] {"The 1", " Empire"});
        countryDescriptions.add(new String[] {"The 1", " Union"});
        countryDescriptions.add(new String[] {"The 1", " Confederation"});
        countryDescriptions.add(new String[] {"The 1", " Democratic Republic"});
        countryDescriptions.add(new String[] {"The United 1", " Emirates"});
        countryDescriptions.add(new String[] {"The United States of 0", ""});
        countryDescriptions.add(new String[] {"The Federal Republic of 0", ""});
        countryDescriptions.add(new String[] {"The Peoples Republic of 0", ""});
        countryDescriptions.add(new String[] {"The Republic of 0", ""});
        countryDescriptions.add(new String[] {"The Union of 1", " Republics"});
        countryDescriptions.add(new String[] {"The 1", " Commonwealth"});
        countryDescriptions.add(new String[] {"The Democratic Peoples Republic of 0", ""});
        //countryDescriptions.add(new String[] {"2", " and "});
        ArrayList <String> playerNames = new ArrayList <String> ();
        for (int i = 0; i < countryNames.size();)
        {
            int k = (int)(Math.random()*countryDescriptions.size());
            if (countryDescriptions.get(k)[0].substring(countryDescriptions.get(k)[0].length()-1).equals("0"))
            {
                playerNames.add(countryDescriptions.get(k)[0].substring(0, countryDescriptions.get(k)[0].length()-1) + countryNames.remove((int)(Math.random()*countryNames.size()))[0] + countryDescriptions.get(k)[1]);     
            }
            else if(countryDescriptions.get(k)[0].substring(countryDescriptions.get(k)[0].length()-1).equals("2") && countryNames.size() > 1)
            {
                playerNames.add(countryDescriptions.get(k)[0].substring(0, countryDescriptions.get(k)[0].length()-1) + countryNames.remove((int)(Math.random()*countryNames.size()))[0] + countryDescriptions.get(k)[1] + countryNames.remove((int)(Math.random()*countryNames.size()))[0]);
            }
            else
            {
                playerNames.add(countryDescriptions.get(k)[0].substring(0, countryDescriptions.get(k)[0].length()-1) + countryNames.remove((int)(Math.random()*countryNames.size()))[1] + countryDescriptions.get(k)[1]);
            }
        }
        boolean usesBothCapitals = false;
        if (Math.random() > .5)
        {
            usesBothCapitals = true;
        }
        this.players[0] = new SpaceMapPlayer (playerNames.remove((int)(playerNames.size()*Math.random())), (int)(4*Math.random()), (int)(6*Math.random()), (int)(3*Math.random()), (int)(5*Math.random()), usesBothCapitals);
        usesBothCapitals = false;
        if (Math.random() > .5)
        {
            usesBothCapitals = true;
        }
        this.players[1] = new SpaceMapPlayer (playerNames.remove((int)(playerNames.size()*Math.random())), (int)(4*Math.random()), (int)(6*Math.random()), (int)(3*Math.random()), (int)(5*Math.random()), usesBothCapitals);
        ArrayList <String> planetNames = new ArrayList <String> ();
        planetNames.add("Pluto");
        planetNames.add("Mars");
        planetNames.add("Mercury");
        planetNames.add("Venus");
        planetNames.add("Earth");
        planetNames.add("Jupiter");
        planetNames.add("Neptune");
        planetNames.add("Schreiber");
        planetNames.add("Givens");
        planetNames.add("Hörmansdorf");
        planetNames.add("Regensburg");
        planetNames.add("Regensberg");
        planetNames.add("Cairo");
        planetNames.add("Bayern");
        planetNames.add("München");
        planetNames.add("Munich");
        planetNames.add("Berlin");
        planetNames.add("Hamburg");
        planetNames.add("Schweinfurt");
        planetNames.add("Frankfurt");
        planetNames.add("Nuremburg");
        planetNames.add("Rome");
        planetNames.add("Germany");
        planetNames.add("France");
        planetNames.add("Italy");
        planetNames.add("Paris");
        planetNames.add("Versialles");
        planetNames.add("Dresden");
        planetNames.add("Leningrad");
        planetNames.add("St. Petersburg");
        planetNames.add("Stalingrad");
        planetNames.add("Moscow");
        planetNames.add("Vladivostok");
        planetNames.add("Egypt");
        planetNames.add("Jordan");
        planetNames.add("Prussia");
        planetNames.add("Austria");
        planetNames.add("Viena");
        planetNames.add("Switzerland");
        planetNames.add("Bern");
        planetNames.add("Zurich");
        planetNames.add("Copenhagen");
        planetNames.add("Brasilia");
        planetNames.add("Brazil");
        planetNames.add("Brasil");
        planetNames.add("Geneva");
        planetNames.add("Denmark");
        planetNames.add("Norway");
        planetNames.add("Stavanger");
        planetNames.add("Oslo");
        planetNames.add("Stockholm");
        planetNames.add("Sweden");
        planetNames.add("Belgium");
        planetNames.add("Brussels");
        planetNames.add("Quebec");
        planetNames.add("Montreal");
        planetNames.add("Nova Scotia");
        planetNames.add("New Brunswick");
        planetNames.add("Newfoundland");
        planetNames.add("Labrador");
        planetNames.add("Ontario");
        planetNames.add("Ottawa");
        planetNames.add("Toronto");
        planetNames.add("Manitoba");
        planetNames.add("Saskatchewan");
        planetNames.add("British Columbia");
        planetNames.add("Alberta");
        planetNames.add("Vancouver");
        planetNames.add("Edmonton");
        planetNames.add("Calgary");
        planetNames.add("Victoria");
        planetNames.add("Chigago");
        planetNames.add("York");
        planetNames.add("New York");
        planetNames.add("Washington");
        planetNames.add("Spain");
        planetNames.add("Portugal");
        planetNames.add("Lisbon");
        planetNames.add("Madrid");
        planetNames.add("Jacksterdam");
        planetNames.add("Amsterdam");
        planetNames.add("New Amsterdam");
        planetNames.add("Barcalona");
        planetNames.add("Tangiers");
        planetNames.add("Morroco");
        planetNames.add("Algeria");
        planetNames.add("Algiers");
        planetNames.add("Tunis");
        planetNames.add("Tunisia");
        planetNames.add("Carthage");
        planetNames.add("Dallas");
        planetNames.add("Cinncinati");
        planetNames.add("Los Angeles");
        planetNames.add("San Diego");
        planetNames.add("San Francisco");
        planetNames.add("Sacramento");
        planetNames.add("Rocklin");
        planetNames.add("Boise");
        planetNames.add("Las Vegas");
        planetNames.add("Trenton");
        planetNames.add("Albany");
        planetNames.add("Boston");
        planetNames.add("Richmond");
        planetNames.add("Baltimore");
        planetNames.add("St. Louis");
        planetNames.add("Baton Rouge");
        planetNames.add("Montgomery");
        planetNames.add("Dublin");
        planetNames.add("Ireland");
        planetNames.add("England");
        planetNames.add("Wales");
        planetNames.add("Scotland");
        planetNames.add("Britain");
        planetNames.add("Austin");
        planetNames.add("London");
        planetNames.add("Glasgow");
        planetNames.add("Texas");
        planetNames.add("Mexico");
        planetNames.add("New Mexico");
        planetNames.add("Arizona");
        planetNames.add("Phoenix");
        planetNames.add("California");
        planetNames.add("Oregon");
        planetNames.add("Salem");
        planetNames.add("Idaho");
        planetNames.add("Nevada");
        planetNames.add("Utah");
        planetNames.add("Montana");
        planetNames.add("Deseret");
        planetNames.add("Colorado");
        planetNames.add("Florida");
        planetNames.add("Georgia");
        planetNames.add("Azerbajan");
        planetNames.add("Armenia");
        planetNames.add("Maine");
        planetNames.add("Vermont");
        planetNames.add("Massachusetts");
        planetNames.add("Connecticut");
        planetNames.add("New England");
        planetNames.add("Pennsylvania");
        planetNames.add("New Jersey");
        planetNames.add("Virginia");
        planetNames.add("Dakota");
        planetNames.add("Tahoe");
        planetNames.add("Wyoming");
        planetNames.add("Ohio");
        planetNames.add("Delaware");
        planetNames.add("Maryland");
        planetNames.add("Carolina");
        planetNames.add("Tennesee");
        planetNames.add("Memphis");
        planetNames.add("Kansas");
        planetNames.add("Kentucky");
        planetNames.add("Illinois");
        planetNames.add("Puerto Rico");
        planetNames.add("Costa Rica");
        planetNames.add("San Salvador");
        planetNames.add("El Salvador");
        planetNames.add("Managua");
        planetNames.add("Nicaragua");
        planetNames.add("Masaya");
        planetNames.add("Leon");
        planetNames.add("Honduras");
        planetNames.add("Panama");
        planetNames.add("Belize");
        planetNames.add("Guatemala");
        planetNames.add("Indiana");
        planetNames.add("Wisconsin");
        planetNames.add("Michigan");
        planetNames.add("Eire");
        planetNames.add("Erie");
        planetNames.add("Nebraska");
        planetNames.add("Iowa");
        planetNames.add("Mississippi");
        planetNames.add("Minnesota");
        planetNames.add("Alaska");
        planetNames.add("Hawaii");
        planetNames.add("Missouri");
        planetNames.add("Oklahoma");
        planetNames.add("Omaha");
        planetNames.add("Louisiana");
        planetNames.add("New Hampshire");
        planetNames.add("Arkansas");
        planetNames.add("Greenland");
        planetNames.add("Raykjavik");
        planetNames.add("Iceland");
        planetNames.add("Cuba");
        planetNames.add("Havana");
        planetNames.add("Habana");
        planetNames.add("Santo Domingo");
        planetNames.add("Marseille");
        planetNames.add("Hannover");
        planetNames.add("Saxony");
        planetNames.add("Köln");
        planetNames.add("Hesse");
        planetNames.add("Leipzig");
        planetNames.add("Zürich");
        planetNames.add("Brandenburg");
        planetNames.add("Rostock");
        planetNames.add("Bremerhaven");
        planetNames.add("Kiel");
        planetNames.add("Salzburg");
        planetNames.add("Grenada");
        planetNames.add("Russia");
        planetNames.add("Moldovia");
        planetNames.add("Romania");
        planetNames.add("Poland");
        planetNames.add("Belorus");
        planetNames.add("Lithuania");
        planetNames.add("Latvia");
        planetNames.add("Finland");
        planetNames.add("Estonia");
        planetNames.add("Kazakhstan");
        planetNames.add("Uzbekistan");
        planetNames.add("Turkmenistan");
        planetNames.add("Korea");
        planetNames.add("Seoul");
        planetNames.add("Pyongyang");
        planetNames.add("Japan");
        planetNames.add("Tokyo");
        planetNames.add("Warsaw");
        planetNames.add("Danzig");
        planetNames.add("Königsberg");
        planetNames.add("Kaliningrad");
        planetNames.add("Helsinki");
        planetNames.add("Maputo");
        planetNames.add("Mozambique");
        planetNames.add("Alexandria");
        planetNames.add("Libya");
        planetNames.add("Tripoli");
        planetNames.add("Toranto");
        planetNames.add("Greece");
        planetNames.add("Crete");
        planetNames.add("Cyprus");
        planetNames.add("Malta");
        planetNames.add("India");
        planetNames.add("Calcutta");
        planetNames.add("New Delhi");
        planetNames.add("Delhi");
        planetNames.add("Vietnam");
        planetNames.add("Cambodia");
        planetNames.add("Macedonia");
        planetNames.add("Argentina");
        planetNames.add("Chile");
        planetNames.add("Bolivia");
        planetNames.add("Paraguay");
        planetNames.add("Uruguay");
        planetNames.add("Peru");
        planetNames.add("Ecuador");
        planetNames.add("Venezuala");
        planetNames.add("Columbia");
        planetNames.add("Quito");
        planetNames.add("Lima");
        planetNames.add("Santiago");
        planetNames.add("Buanos Aires");
        planetNames.add("Star");
        planetNames.add("Nampa");
        planetNames.add("España");
        planetNames.add("Lebanon");
        planetNames.add("Beirut");
        planetNames.add("Jordan");
        planetNames.add("Amman");
        planetNames.add("Holstein");
        planetNames.add("Haiti");
        planetNames.add("Sudan");
        planetNames.add("Angola");
        planetNames.add("Africa");
        planetNames.add("America");
        planetNames.add("Europe");
        planetNames.add("Asia");
        planetNames.add("Australia");
        planetNames.add("Austria");
        planetNames.add("Macedonia");
        planetNames.add("Skopje");
        planetNames.add("Bulgaria");
        planetNames.add("Yugoslavia");
        planetNames.add("Serbia");
        planetNames.add("Belgrade");
        planetNames.add("Budapest");
        planetNames.add("Hungary");
        planetNames.add("Belfast");
        planetNames.add("Bucharest");
        planetNames.add("Slovenia");
        planetNames.add("Slovakia");
        planetNames.add("Czechoslovakia");
        planetNames.add("Bohemia");
        planetNames.add("Moravia");
        planetNames.add("Prague");
        planetNames.add("Silesia");
        planetNames.add("Pretoria");
        planetNames.add("Bloemfont");
        planetNames.add("Johannesburg");
        planetNames.add("Guazapa");
        planetNames.add("Beijing");
        planetNames.add("Hanio");
        planetNames.add("Hainan");
        planetNames.add("Taiwan");
        planetNames.add("Honshu");
        planetNames.add("Hokkaido");
        planetNames.add("Kyushu");
        planetNames.add("Mongolia");
        planetNames.add("China");
        planetNames.add("Kyrgyzstan");
        planetNames.add("Tajikistan");
        planetNames.add("Afganistan");
        planetNames.add("Pakistan");
        planetNames.add("Nepal");
        planetNames.add("Oman");
        planetNames.add("Yemen");
        planetNames.add("Qatar");
        planetNames.add("Kuwait");
        planetNames.add("Iraq");
        planetNames.add("Baghdad");
        planetNames.add("Iran");
        planetNames.add("Tehran");
        planetNames.add("Dar es Salaam");
        planetNames.add("Tanzania");
        planetNames.add("Tanganyika");
        planetNames.add("Zanzibar");
        planetNames.add("Kenya");
        planetNames.add("Uganda");
        planetNames.add("Somalia");
        planetNames.add("Ethiopia");
        planetNames.add("Eritrea");
        planetNames.add("Chad");
        planetNames.add("Myanmar");
        planetNames.add("Burma");
        planetNames.add("Thailand");
        planetNames.add("Laos");
        planetNames.add("Malaysia");
        planetNames.add("Indonesia");
        planetNames.add("Singapore");
        planetNames.add("New Guinea");
        planetNames.add("Sri Lanka");
        planetNames.add("Zimbabwe");
        planetNames.add("Congo");
        planetNames.add("Cameroon");
        planetNames.add("Kamerun");
        planetNames.add("Nigeria");
        planetNames.add("Niger");
        planetNames.add("Mali");
        planetNames.add("Mauritania");
        planetNames.add("Svalbard");
        planetNames.add("Karachi");
        planetNames.add("Phnom Penh");
        planetNames.add("Java");
        planetNames.add("Sumatra");
        planetNames.add("Borneo");
        planetNames.add("Celebes");
        planetNames.add("Timor");
        planetNames.add("New Zealand");
        planetNames.add("Manila");
        planetNames.add("Luzon");
        planetNames.add("Jakarta");
        planetNames.add("Guyana");
        planetNames.add("Suriname");
        planetNames.add("Guiana");
        planetNames.add("Ghana");
        planetNames.add("Côte D'Ivoire");
        planetNames.add("Togo");
        planetNames.add("Guinea");
        planetNames.add("Sierra Leone");
        planetNames.add("Liberia");
        planetNames.add("Kabul");
        planetNames.add("Minsk");
        planetNames.add("Kiev");
        planetNames.add("Syria");
        planetNames.add("Damascus");
        planetNames.add("Rio de Janeiro");
        planetNames.add("Bangkok");
        planetNames.add("Fiji");
        planetNames.add("Croatia");
        planetNames.add("Bahrain");
        planetNames.add("Riyadh");
        planetNames.add("Sardinia");
        planetNames.add("Corsica");
        planetNames.add("Athens");
        planetNames.add("Sparta");
        planetNames.add("Istanbul");
        planetNames.add("Ankara");
        planetNames.add("Turkey");
        planetNames.add("Liechtenstein");
        planetNames.add("Albania");
        planetNames.add("Bombay");
        planetNames.add("Mumbia");
        planetNames.add("Bangalore");
        planetNames.add("Shanghai");
        planetNames.add("Osaka");
        planetNames.add("Essen");
        planetNames.add("São Paulo");
        planetNames.add("Addis Ababa");
        planetNames.add("Québec");
        planetNames.add("Halifax");
        planetNames.add("Winnipeg");
        planetNames.add("Regina");
        planetNames.add("Nunavut");
        planetNames.add("Yukon");
        planetNames.add("Denver");
        planetNames.add("Milwaukee");
        planetNames.add("Detroit");
        planetNames.add("Toledo");
        planetNames.add("Concord");
        planetNames.add("Augusta");
        planetNames.add("Norfolk");
        planetNames.add("Philadelphia");
        planetNames.add("Savannah");
        planetNames.add("Atlanta");
        planetNames.add("Tampa");
        planetNames.add("Jackson");
        planetNames.add("Tallahassee");
        planetNames.add("Miami");
        planetNames.add("Orlando");
        planetNames.add("Birmingham");
        planetNames.add("Springfield");
        planetNames.add("Santa Fe");
        planetNames.add("Portland");
        planetNames.add("Seattle");
        planetNames.add("Honolulu");
        planetNames.add("Juneau");
        planetNames.add("Anchorage");
        planetNames.add("Buffalo");
        planetNames.add("Newark");
        planetNames.add("Campeche");
        planetNames.add("Oaxaca");
        planetNames.add("Veracruz");
        planetNames.add("Guadalajara");
        planetNames.add("Zacatecas");
        planetNames.add("Sonora");
        planetNames.add("Acapulco");
        planetNames.add("Sofia");
        planetNames.add("Venice");
        planetNames.add("Milan");
        planetNames.add("Genoa");
        planetNames.add("Lyon");
        planetNames.add("Canberra");
        planetNames.add("Queensland");
        planetNames.add("New Britain");
        planetNames.add("Sydney");
        planetNames.add("Derby");
        planetNames.add("Tasmania");
        planetNames.add("Wellington");
        planetNames.add("Perth");
        planetNames.add("Darwin");
        planetNames.add("Newcastle");
        planetNames.add("Samoa");
        planetNames.add("Polynesia");
        planetNames.add("New Caledonia");
        planetNames.add("Palau");
        planetNames.add("The Netherlands");
        planetNames.add("The Hague");
        
        int r = 0;
        int r2d2 = 0;
        for (int i = 0; i < 307;i++)
        {
            r = (int)(9*Math.random());
            r2d2 = (int)Math.round(Math.random());
            this.planets.add(new SpaceMapPlanet (planetNames.remove((int)(Math.random()*planetNames.size())), r, players[r2d2]));
            players[r2d2].addPlanet(planets.get(i));
        }
        ArrayList <SpaceMapPlanet> p1Planets = players[0].getPlanets();
        players[0].setCapital(p1Planets.get((int)(Math.random()*p1Planets.size())));
        if(players[0].usesBothCapitals())
        {
            while(players[0].capitalCheck() || players[0].getAlternateCapital() == null)
            {
                players[0].setAlternateCapital(p1Planets.get((int)(Math.random()*p1Planets.size())));             
            }
        }
        ArrayList <SpaceMapPlanet> p2Planets = players[1].getPlanets();
        players[1].setCapital(p2Planets.get((int)(Math.random()*p2Planets.size())));
        if(players[1].usesBothCapitals())
        {
            while(players[1].capitalCheck() || players[1].getAlternateCapital() == null)
            {
                players[1].setAlternateCapital(p2Planets.get((int)(Math.random()*p2Planets.size())));             
            }
        }
        
        this.playerTurn = players[0];
    }
    
    public String getPlanetDescription()
    {
        if(selectedPlanet == null)
        {
            return "No planet selected";
        }
        return selectedPlanet.getDescription();
    }
    
    public String getPlayerDescription()
    {
        if(playerTurn == null)
        {
            return "FATAL ERROR!!!";
        }
        return playerTurn.getDescription();
    }

    public String getPlanetNames()
    {
        String theString = "";
        for (int i = 0; i < planets.size(); i++)
        {
            theString = theString + planets.get(i).getName() + " " + planets.get(i).getOwner().getName() + ", " ;
        }
        return theString.substring(0,theString.length()-2);
    }
    
    public void selectPlanet(int i)
    {
        selectedPlanet = planets.get(i);
    }
}
