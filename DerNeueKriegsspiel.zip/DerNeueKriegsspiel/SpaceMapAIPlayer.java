import java.util.ArrayList;
/**
 * Write a description of class SpaceMapAIPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapAIPlayer extends SpaceMapPlayer
{
    
    
    private short mode; //Determines the mode it needs to be in. 0 is peaceful construction when it is on par with neighbors and to a lesser extent everyone and the AI
    //is not going to be angry enough for war in a few turns, 1 is slight military construction and is turned on if there are neighbors that are more powerful or if
    //there are conflicts boiling up in the galaxy; a preventative measure and possibly could be changed to 2 if the AI decides that it will be attacked or that it
    //will attack, 2 is mostly military construction and changes to some combat bonuses over economic ones and is automatically on if 3 is not on during war, 3 is
    //total military focus and all bonuses are oriented towards achieving victory in battle it is only reached when the opponent has caused a lot of "anger" or is
    //fairly powerful.
    
    private boolean treasuryFocus; //false is general focus, true is gold focus.
    
    private short difficulty;//Because the player will likely need some advantage over the AI.(The game will be easier for the AI to keep track of than for the player)
    //0 is easy and gives a 30% penalty, 1 is normal and gives a 5% penalty, 2 is hard and gives a 1% penalty, 3 is super hardcore and gives a 1% bonus.
    
    private short danger;//Represents the assessed threat to the player.
    
    private short anger;//Represents the players total anger.
    
    public SpaceMapAIPlayer(String name, short culture, short gov, short econGov, short forGov, boolean usesBothCapitals, ArrayList<String> leaderNames, short index, short difficulty)
    {
        super(name,culture,gov,econGov,forGov,usesBothCapitals, leaderNames, index);
        this.mode = 0;
        this.treasuryFocus = false;
        this.difficulty = difficulty;
        this.danger = 0;
        this.anger = 0;
        /*if(difficulty == 0)
        {
            this.foodTech = 1;
            this.moneyTech = 1;
        }*/      
    }
    
    public double getDifficultyEffect()
    {
        if(difficulty == 0)
        {
            return .75;
        }
        else if(difficulty == 1)
        {
            return .95;
        }
        else if(difficulty == 2)
        {
            return .99;
        }
        else
        {
            return 1.01;
        }
    }
    
    public void updateFleetAnalysisSize(double maxFleet, double minBorderFleet)
    {
        double realThreat = 0;
        for(short i = 0; i < enemies.size();i++)
        {
            realThreat = realThreat + enemies.get(i).getFleetSize();
        }
        if(realThreat/1.5 > getFleetSize() || (anger > 5 && realThreat*1.5 > getFleetSize()) || (maxFleet/5 > getFleetSize() && maxFleet > 25))
        {
            danger = 3;
        }
        else if(((maxFleet/1.7 > getFleetSize() && maxFleet > 15) || realThreat/1.5 > getFleetSize()) || (minBorderFleet*5 < getFleetSize() && getFleetSize() > 100))
        {
            danger = 2;
        }
        else if(maxFleet/1.3 > getFleetSize() && maxFleet > 10)
        {
            danger = 1;
        }
        else
        {
            danger = 0;
        }
        
    }
    
    public void updateMode()
    {
        if(enemies.size() > 0 && mode < 2)
        {
            mode = 2;
        }
        else if(danger == 1 && mode == 0)
        {
            mode = 1;
        }
        else if(danger == 3)
        {
            mode = 3;
        }
        else if(danger == 0 && enemies.size() == 0)
        {
            mode = 0;
        }
        else if(danger == 2)
        {
            mode = 2;
        }
        if(enemies.size() > 0 && danger < 3)
        {
            mode = 2;
        }
    }
    
    public short getMode()
    {
        return mode;
    }

    public void treasuryFocus(boolean b)
    {
        treasuryFocus = b;
    }
    
    public void updateBonuses(/*boolean treasuryFocus*/)
    {
        bonuses = new double[9];
        double totalPresidentBonus = 26;
        double totalPresidentPenalty = 8.5;
        double totalCommanderBonus = 26;
        double totalCommanderPenalty = 8.5;
        double totalScienceBonus = 4;
        double totalSciencePenalty = 1.4;
        double totalDiplomacyBonus = 21;
        double totalDiplomacyPenalty = 7;
        double totalTreasuryBonus = Math.random()/5;
        double totalTreasuryPenalty = Math.random()/10;
        if(treasuryFocus)
        {
            bonuses[3] = totalTreasuryBonus;
            bonuses[4] = totalTreasuryPenalty/4;
        }
        else
        {
            bonuses[4] = totalTreasuryBonus/4;
            bonuses[3] = totalTreasuryPenalty;
        }
        
        if(mode == 0 || mode == 1)
        {
            double[] bonusPresidentSpread = new double[7];
            double[] penaltyPresidentSpread = new double[2];
            double h;
            double t1 = 0; 
            double t2 = 0; 
            int counter = 0;
            //int counter2 = 0;
            for (int i = 0; i < 7;i++)
            {
                h = Math.random();
                bonusPresidentSpread[i] = h;
                t1 = t1 + h;
            }
            for (int i = 0; i < 2;i++)
            {
                h = Math.random();
                penaltyPresidentSpread[i] = h;
                t2 = t2 + h;
            }
            for(int i = 0; i < 9;i++)
            {
                if(i < 5)
                {
                    bonuses[i] = bonuses[i] + (bonusPresidentSpread[i]*totalPresidentBonus/t1);
                    counter ++;
                }
                else if(i == 5)
                {
                    bonuses[i] = bonuses[i] - (penaltyPresidentSpread[0]*totalPresidentPenalty/t2);
                }
                else if(i == 6)
                {
                    bonuses[i] = bonuses[i] - (penaltyPresidentSpread[1]*totalPresidentPenalty/t2);
                }
                else 
                {
                    bonuses[i] = bonuses[i] + (bonusPresidentSpread[counter]*totalPresidentBonus/t1);
                    counter ++;
                }
            }
        }
        else if(mode == 2)
        {
            double[] bonusPresidentSpread = new double[9];
            double[] penaltyPresidentSpread = new double[9];
            double h;
            double t1 = 0; 
            double t2 = 0; 
            int counter = 0;
            //int counter2 = 0;
            for (int i = 0; i < 9;i++)
            {
                h = Math.random();
                bonusPresidentSpread[i] = h;
                t1 = t1 + h;
            }
            for (int i = 0; i < 9;i++)
            {
                h = Math.random();
                penaltyPresidentSpread[i] = h;
                t2 = t2 + h;
            }
            for(int i = 0; i < 9;i++)
            {
                bonuses[i] = bonuses[i] + (bonusPresidentSpread[i]*totalPresidentBonus/t1);
                bonuses[i] = bonuses[i] - (penaltyPresidentSpread[i]*totalPresidentPenalty/t2);
            }
        }
        else
        {
            double[] penaltyPresidentSpread = new double[7];
            double[] bonusPresidentSpread = new double[2];
            double h;
            double t1 = 0; 
            double t2 = 0; 
            int counter = 0;
            //int counter2 = 0;
            for (int i = 0; i < 7;i++)
            {
                h = Math.random();
                penaltyPresidentSpread[i] = h;
                t1 = t1 + h;
            }
            for (int i = 0; i < 2;i++)
            {
                h = Math.random();
                bonusPresidentSpread[i] = h;
                t2 = t2 + h;
            }
            for(int i = 0; i < 9;i++)
            {
                if(i < 5)
                {
                    bonuses[i] = bonuses[i] + (penaltyPresidentSpread[i]*totalPresidentBonus/t1);
                    counter ++;
                }
                else if(i == 5)
                {
                    bonuses[i] = bonuses[i] - (bonusPresidentSpread[0]*totalPresidentPenalty/t2);
                }
                else if(i == 6)
                {
                    bonuses[i] = bonuses[i] - (bonusPresidentSpread[1]*totalPresidentPenalty/t2);
                }
                else 
                {
                    bonuses[i] = bonuses[i] + (penaltyPresidentSpread[counter]*totalPresidentBonus/t1);
                    counter ++;
                }
            }
        }
    }    
    
    
    public void setGrowthRate()
    {
        if (enoughFood() && food > getPopulation()*4)
        {
            growthRate = 3;
        }
        else if (enoughFood() && food > 750000)
        {
            growthRate = 2.5;
        }
        else if(enoughFood() && food > 250000)
        {
            growthRate = 1;
        }
        else if(enoughFood() && food > 100000)
        {
            growthRate = .05;
        }
        else if(food > 12500000)
        {
            growthRate = -.1;
        }
        else if(food > 10000000)
        {
            growthRate = -.25;
        }
        else if(food > 7500000)
        {
            growthRate = -.5;
        }
        else if(food > 5000000)
        {
            growthRate = -.75;
        }
        else if(food > 2500000)
        {
            growthRate = -1;
        }
        else if(food > 1000000)
        {
            growthRate = -2.5;
        }
        else if(food > 750000)
        {
            growthRate = -7.5;
        }
        else if(food > 0)
        {
            growthRate = -10;
        }
        else if(food > -100000)
        {
            growthRate = -25;
        }
        else if(food > -350000)
        {
            growthRate = -40;
        }
        else
        {
            growthRate = -75;
        }
    }
    
    
    public void getStuff()
    {
        double[] stuff = new double[7];
        double[] holder = new double[7];
        int population = 0;
        for(short i = 0; i < planets.size();i++)
        {
            population = population + planets.get(i).getPopulation();
            holder = planets.get(i).getStuff();
            for (short j = 0; j < holder.length; j++)
            {
                stuff[j] = stuff[j] + holder[j];
            }
        }
        double t = population*.1;            
        double[] resSpread = new double[3];           
        double h;        
        double ran = 0;
        int populationLeft = population;
        for(int i = 0; i < population; i++)
        {
            if(Math.random() < .0001)
            {
                populationLeft --;
                if (Math.random() < .334)
                {
                    stuff[4] = stuff[4] + .01;
                }
                else if(Math.random() < .5)
                {
                    stuff[5] = stuff[5] + .01;
                }
                else
                {
                    stuff[6] = stuff[6] + .01;
                }
            }
        }
        h = Math.random(); 
        if (enoughFood())
        {
            resSpread[0] = h + .03; 
            ran = ran + h + .03;   
        }
        else
        {
            resSpread[0] = h + .05;
            ran = ran + h + .05;
        }
             
            for (int i = 1; i < 3;i++)
            {
                h = Math.random();      
                resSpread[i] = h + .01;
                ran = ran + h + .01;           
            }            
            for(int i = 0; i < 3;i++)
            {
                stuff[i] = stuff[i] + populationLeft*.1*resSpread[i]/ran;            
            }
            stuff[3] = stuff[3] + t;
        food = food + (stuff[0]*Math.pow(1.1,foodTech)*1.05*(1+bonuses[0])*(1+bonuses[4])*getDifficultyEffect()) + 500;
        metal = metal + (stuff[1]*Math.pow(1.1,metalTech)*(1+bonuses[1])*(1+bonuses[4])*getDifficultyEffect()) + 500;       
        industry = industry + (stuff[2]*Math.pow(1.1,industryTech)*(1+bonuses[2])*(1+bonuses[4])*getDifficultyEffect()) + 500;
        money = money + (stuff[3]*Math.pow(1.1,moneyTech)*(1+bonuses[3])*(1+bonuses[4])*getDifficultyEffect()) + 500;
        uranium = uranium + (stuff[4]*Math.pow(1.05,metalTech)*(1+bonuses[1])*getDifficultyEffect());
        titanium = titanium + (stuff[5]*Math.pow(1.05,metalTech)*(1+bonuses[1])*getDifficultyEffect());
        promethium = promethium + (stuff[6]*Math.pow(1.05,metalTech)*(1+bonuses[1])*getDifficultyEffect());
    }
    
}
