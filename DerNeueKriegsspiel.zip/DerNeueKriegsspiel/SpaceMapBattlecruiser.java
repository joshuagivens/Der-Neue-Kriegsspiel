
/**
 * Write a description of class SpaceMapBattlecruiser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapBattlecruiser extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapBattlecruiser
     */
    public SpaceMapBattlecruiser()
    {
        this.size = 6;
        this.carrierCapacity = 8;
        this.moneyCost = 5000;
        this.metalCost = 4000;
        this.industryCost = 4000;
        this.baseHealth = 275;
        this.baseAttack = 100;
        this.baseDefense = 80;
    }

    
}
