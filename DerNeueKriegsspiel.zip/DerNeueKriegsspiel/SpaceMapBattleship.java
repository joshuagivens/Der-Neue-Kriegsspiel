
/**
 * Write a description of class SpaceMapBattleship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapBattleship extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapBattleship
     */
    public SpaceMapBattleship()
    {
        this.size = 7;
        this.carrierCapacity = 10;
        this.moneyCost = 6250;
        this.metalCost = 5000;
        this.industryCost = 5000;
        this.baseHealth = 350;
        this.baseAttack = 125;
        this.baseDefense = 100;
    }

    
}
