
/**
 * Write a description of class SpaceMapBuilding here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class SpaceMapBuilding
{
    private SpaceMapPlanet planet;
    public static int industryCost = 5000;
    public static int moneyCost = 5000;
    public static int metalCost = 5000;
    short upkeep;
    

    /**
     * Constructor for objects of class SpaceMapBuilding
     */
    public SpaceMapBuilding()
    {
        this.upkeep = 20;
    }
    
    public static double[] cost()
    {
        return new double[] {0, metalCost, industryCost, moneyCost};
    }

    public double[] getProduction()
    {
        return new double[]{0,0,0,0,0,0,0};
    }
    
    public short getUpkeep()
    {
        return upkeep;
    }
}
