
/**
 * Write a description of class SpaceMapBuilding here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class SpaceMapBuilding
{
    private SpaceMapPlanet planet;
    public static int industryCost = 5000;
    public static int moneyCost = 5000;
    public static int metalCost = 5000;
    double upkeep;
    

    /**
     * Constructor for objects of class SpaceMapBuilding
     */
    public SpaceMapBuilding()
    {
        this.upkeep = 25;
    }
    
    public static double[] cost()
    {
        return new double[] {0, metalCost, industryCost, moneyCost};
    }

    public double[] getProduction()
    {
        return new double[]{5,0,0,0,0,0,0};
    }
    
    public double getUpkeep()
    {
        return upkeep;
    }
}
