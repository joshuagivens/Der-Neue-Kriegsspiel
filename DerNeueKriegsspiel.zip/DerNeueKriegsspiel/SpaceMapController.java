import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import java.io.InputStream;

import java.io.IOException;

import java.net.URL;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;



import javafx.scene.control.CheckBox;

import javafx.scene.image.Image;

import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
/**
 * Write a description of class BoxCanyonController here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapController
{
    /*@FXML
    private Button planetButton1;
    @FXML
    private Button planetButton2;
    @FXML
    private Button planetButton3;*/
    
    @FXML
    private Label planetLabel;
    
    @FXML
    private Label label;
    
    @FXML
    private ImageView image;
    
    @FXML
    private ImageView victoryImage;
    
    private int turn = 0;
    
    private int input = 6;
    
    private int t1 = 0;
    
    private int t2 = 0;
    
    //BoxCanyonImportantStringHolder s = new BoxCanyonImportantStringHolder();
    
    private SpaceMap spaceMap = new SpaceMap();//BoxCanyon(s);
    
    private SpaceMapPlayer player;
    
    @FXML
    void button0()
    {
        spaceMap.selectPlanet(0);
        updatePlanetDescription();
    }
    @FXML
    void button1()
    {
        spaceMap.selectPlanet(1);
        updatePlanetDescription();
    }
    @FXML
    void button2()
    {
        spaceMap.selectPlanet(2);
        updatePlanetDescription();
    }
    @FXML
    void button3()
    {
        spaceMap.selectPlanet(3);
        updatePlanetDescription();
    }
    @FXML
    void button4()
    {
        spaceMap.selectPlanet(4);
        updatePlanetDescription();
    }
    @FXML
    void button5()
    {
        spaceMap.selectPlanet(5);
        updatePlanetDescription();
    }
    @FXML
    void button6()
    {
        spaceMap.selectPlanet(6);
        updatePlanetDescription();
    }
    @FXML
    void button7()
    {
        spaceMap.selectPlanet(7);
        updatePlanetDescription();
    }
    @FXML
    void button8()
    {
        spaceMap.selectPlanet(8);
        updatePlanetDescription();
    }
    @FXML
    void button9()
    {
        spaceMap.selectPlanet(9);
        updatePlanetDescription();
    }
    
    public int getInput()
    {
        return input;
    }
    
    void updatePlanetDescription()
    {
        planetLabel.setText(spaceMap.getPlanetDescription());
    }
    
    void writeNewText(String s)
    {
        label.setText(s);
    }
    
    
    
}
