import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JOptionPane;

//import javafx.scene.control.Alert;

import javafx.scene.control.*;

import java.io.InputStream;

import java.io.IOException;

import java.net.URL;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;


import javafx.scene.control.CheckBox;

import javafx.scene.image.Image;

import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
/**
 * Write a description of class BoxCanyonController here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapController
{
    /*@FXML
    private Button planetButton1;
    @FXML
    private Button planetButton2;
    @FXML
    private Button planetButton3;*/
    
    @FXML
    private Label queueLabel;
    
    @FXML
    private Label raresLabel;
    
    @FXML
    private Label playerResourceLabel;
    
    @FXML
    private TextField populationSelector;
    
    
    @FXML
    private TextField presidentSelector;
    
    @FXML
    private TextField vicePresidentSelector;
    
    @FXML
    private TextField commanderSelector;
    
    @FXML
    private TextField subCommanderSelector;
    
    @FXML
    private TextField treasurySelector;
    
    @FXML
    private TextField foreignSelector;
    
    @FXML
    private TextField councilSelector;
    
    @FXML
    private TextField scienceSelector;
       
    @FXML
    private Label presidentLabel;
    
    @FXML
    private Label vicePresidentLabel;
    
    @FXML
    private Label commanderLabel;
    
    @FXML
    private Label subCommanderLabel;
    
    @FXML
    private Label treasuryLabel;
    
    @FXML
    private Label foreignLabel;
    
    @FXML
    private Label councilLabel;
    
    @FXML
    private Label scienceLabel;
    
    
    @FXML
    private Label politicians;
    
    
    @FXML
    private TextField shipSelector;
    
    @FXML
    private TextField queueCanceler;
    
    @FXML
    private Label priceLabel;
    
    @FXML
    private Label planetLabel;
    
    @FXML
    private Label playerLabel;
    
    @FXML
    private Label playerLabel1;
    
    @FXML
    private Label foodTechLabel;
    
    @FXML
    private Label metalTechLabel;
    
    @FXML
    private Label industryTechLabel;
    
    @FXML
    private Label moneyTechLabel;
    
    @FXML
    private Label shieldsTechLabel;
    
    @FXML
    private Label weaponsTechLabel;
    
    @FXML
    private Label shipListLabel;
    
    @FXML
    private Label enemyShipListLabel;
    
    @FXML
    private Label shipDescriptionLabel;
    
    @FXML
    private TextField bulkBuyer;
    
    /*@FXML
    private Label label;
    
    @FXML
    private ImageView image;
    
    @FXML
    private ImageView victoryImage;*/
    
    private int turn = 0;
    
    private int input = 6;
    
    private int t1 = 0;
    
    private int t2 = 0;
    
    //BoxCanyonImportantStringHolder s = new BoxCanyonImportantStringHolder();
    
    private SpaceMap spaceMap = new SpaceMap();//BoxCanyon(s);
    
    private SpaceMapPlayer player;
    
    @FXML
    private void changeRate()
    {       
           
               try
               {
                   spaceMap.changeRate(Double.parseDouble(populationSelector.getText()));
                }
                catch(NumberFormatException e)
                {
                    //JOptionPane.showMessageDialog(null, "alert", "Please type a number", JOptionPane.ERROR_MESSAGE);
                    /*Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("");
                    alert.setContentText("You didn't put in a number.");
                    alert.showAndWait();*/
                }
            
           updateDetails();         
    }
    
    @FXML
    private void scrap()
    {
        spaceMap.scrap();
        updateDetails();
    }
    
    @FXML
    private void scrapAll()
    {
        spaceMap.scrapAll();
        updateDetails();
    }
    
    private void updateCostLabel()
    {
        priceLabel.setText("");
    }
    
    private void updatePoliticians()
    {
        presidentLabel.setText(spaceMap.getPresident());
        vicePresidentLabel.setText(spaceMap.getVicePresident());
        commanderLabel.setText(spaceMap.getCommander());
        subCommanderLabel.setText(spaceMap.getSubCommander());
        treasuryLabel.setText(spaceMap.getTreasury());
        foreignLabel.setText(spaceMap.getForeign());
        councilLabel.setText(spaceMap.getCouncil());
        scienceLabel.setText(spaceMap.getScience());
        politicians.setText(spaceMap.getParasites());
    }
    
    @FXML
    private void changePresident()
    {
        try
               {
                   spaceMap.changePresident((short)(Integer.parseInt(presidentSelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }
    
    @FXML
    private void changeVicePresident()
    {
        try
               {
                   spaceMap.changeVicePresident((short)(Integer.parseInt(vicePresidentSelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }
    
    @FXML
    private void changeCommander()
    {
        try
               {
                   spaceMap.changeCommander((short)(Integer.parseInt(commanderSelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }
    
    @FXML
    private void changeSubCommander()
    {
        try
               {
                   spaceMap.changeSubCommander((short)(Integer.parseInt(subCommanderSelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }    
        
    @FXML
    private void changeTreasury()
    {
        try
               {
                   spaceMap.changeTreasury((short)(Integer.parseInt(treasurySelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }
    
    @FXML
    private void changeForeign()
    {
        try
               {
                   spaceMap.changeForeign((short)(Integer.parseInt(foreignSelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }
    
    @FXML
    private void changeCouncil()
    {
        try
               {
                   spaceMap.changeCouncil((short)(Integer.parseInt(councilSelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }
    
    @FXML
    private void changeScience()
    {
        try
               {
                   spaceMap.changeScience((short)(Integer.parseInt(scienceSelector.getText())));
                }
                catch(NumberFormatException e)
                {
                    
                }
                updateDetails();  
    }
    
    @FXML
    private void autoUpgrade()
    {
        spaceMap.autoUpgrade();
        updateDetails();
    }  
    
    @FXML
    private void upgradeUranium()
    {
        spaceMap.upgradeUranium();
        updateDetails();
    }    
    
    @FXML
    private void upgradeTitanium()
    {
        spaceMap.upgradeTitanium();
        updateDetails();
    }
    
    @FXML
    private void upgradePromethium()
    {
        spaceMap.upgradePromethium();
        updateDetails();
    }
    
    @FXML
    private void selectAll()
    {
        spaceMap.selectAll();
        updateDetails();
    }
    
    @FXML
    private void researchFood()
    {
        spaceMap.researchFood();
        updateDetails();
    }
    
    @FXML
    private void researchMoney()
    {
        spaceMap.researchMoney();
        updateDetails();
    }
    
    @FXML
    private void researchMining()
    {
        spaceMap.researchMetal();
        updateDetails();
    }
    
    @FXML
    private void researchIndustry()
    {
        spaceMap.researchIndustry();
        updateDetails();
    }
    
    @FXML
    private void researchWeapons()
    {
        spaceMap.researchWeapons();
        updateDetails();
    }
    
    @FXML
    private void researchDefense()
    {
        spaceMap.researchDefense();
        updateDetails();
    }
    
    private void updateDetails()
    {
        updateQueue();
        updatePlanetDescription();
        updatePlayerDescription();
        updateShipLists();
        updateResearchCosts();
        updatePoliticians();
        updateCostLabel();
    }
    
    private void updateResearchCosts()
    {
        foodTechLabel.setText(spaceMap.getFoodResearchCost()+"");    
        metalTechLabel.setText(spaceMap.getMetalResearchCost()+"");    
        industryTechLabel.setText(spaceMap.getIndustryResearchCost()+"");    
        moneyTechLabel.setText(spaceMap.getMoneyResearchCost()+"");    
        shieldsTechLabel.setText(spaceMap.getShieldsResearchCost()+"");    
        weaponsTechLabel.setText(spaceMap.getWeaponsResearchCost()+"");
    }
    
    private void updateShipLists()
    {
        shipListLabel.setText(spaceMap.getShipList());
        enemyShipListLabel.setText(spaceMap.getEnemyShipList());
        shipDescriptionLabel.setText(spaceMap.selectedShip());
    }
    
    @FXML
    private void cancelQueue()
    {
        spaceMap.cancelQueue();
        updateDetails();
    }
    
    @FXML
    private void updateCancelQueue()
    {       
           /*if(/*shipSelector.getText().equals("")false)
           {
          
           }
           else
           {*/
               try
               {
                   spaceMap.cancelQueue((short)(Integer.parseInt(queueCanceler.getText())));
                }
                catch(NumberFormatException e)
                {
                    //JOptionPane.showMessageDialog(null, "alert", "Please type a number", JOptionPane.ERROR_MESSAGE);
                    /*Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("");
                    alert.setContentText("You didn't put in a number.");
                    alert.showAndWait();*/
                }
           //}    
           updateDetails();         
    }
    
    private void updateQueue()
    {
        queueLabel.setText(spaceMap.getQueue());
    }
    
    @FXML
    private void endTurn()
    {
        spaceMap.endTurn();
        updateDetails();
    }
    
    @FXML
    private void buy0()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(0));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(0));
                }
        
        
        updateDetails();
    }
    @FXML
    private void buy1()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(1));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(1));
                }
        updateDetails();
    }
    @FXML
    private void buy2()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(2));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(2));
                }
        updateDetails();
    }
    @FXML
    private void buy3()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(3));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(3));
                }
        updateDetails();
    }
    @FXML
    private void buy4()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(4));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(4));
                }
        updateDetails();
    }
    @FXML
    private void buy5()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(5));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(5));
                }
        updateDetails();
    }
    @FXML
    private void buy6()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(6));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(6));
                }
        updateDetails();
    }
    @FXML
    private void buy7()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(7));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(7));
                }
        updateDetails();
    }
    @FXML
    private void buy8()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(8));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(8));
                }
        updateDetails();
    }
    @FXML
    private void buy9()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(9));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(9));
                }
        updateDetails();
    }
    @FXML
    private void buy10()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(10));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(10));
                }
        updateDetails();
    }
    @FXML
    private void buy11()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(11));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(11));
                }
        updateDetails();
    }
    @FXML
    private void buy12()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(12));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(12));
                }
        updateDetails();
    }
    @FXML
    private void buy13()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(13));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(13));
                }
        updateDetails();
    }
    @FXML
    private void buy14()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(14));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(14));
                }
        updateDetails();
    }
    @FXML
    private void buy15()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(15));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(15));
                }
        updateDetails();
    }
    @FXML
    private void buy16()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(16));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(16));
                }
        updateDetails();
    }
    @FXML
    private void buy17()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(17));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(17));
                }
        updateDetails();
    }
    @FXML
    private void buy18()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(18));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(18));
                }
        updateDetails();
    }
    @FXML
    private void buy19()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(19));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(19));
                }
        updateDetails();
    }
    @FXML
    private void buy20()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(20));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(20));
                }
        updateDetails();
    }
    @FXML
    private void buy21()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(21));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(21));
                }
        updateDetails();
    }
    @FXML
    private void buy22()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(22));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(22));
                }
        updateDetails();
    }
    @FXML
    private void buy23()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(23));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(23));
                }
        updateDetails();
    }
    @FXML
    private void buy24()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(24));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(24));
                }
        updateDetails();
    }
    @FXML
    private void buy25()
    {
        try
               {
                   short i = (short)(Integer.parseInt(bulkBuyer.getText()));
                   if (i <= 0)
                   {
                       throw new NumberFormatException();
                   }
                   for (short j = 0; j < i; j++)
                   {
                       spaceMap.addQueueItem((short)(25));
                   }
                }
                catch(NumberFormatException e)
                {
                    spaceMap.addQueueItem((short)(25));
                }
        updateDetails();
    }
    
    @FXML
    private void cancel()
    {
        spaceMap.cancel();
        updateDetails();
    }
    
    
    @FXML
    private void updateSelectedVessel()
    {
        //selectVessel;
        //String text = ;
            /*if(shipSelector.getText().equals(""))
            {
            
            }
            else
            {*/
                try
               {
                   //spaceMap.cancelQueue((short)(Integer.parseInt(queueCanceler.getText())));
                   //shipDescriptionLabel.setText(spaceMap.selectShip((short)(Integer.parseInt(shipSelector.getText()))));
                   spaceMap.selectShip((short)(Integer.parseInt(shipSelector.getText())));
                   
                }
                catch(NumberFormatException e)
                {
                    //JOptionPane.showMessageDialog(null, "alert", "Please type a number", JOptionPane.ERROR_MESSAGE);
                    /*Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("");
                    alert.setContentText("You didn't put in a number.");
                    alert.showAndWait();*/
                }                
            //}    
            updateDetails();
            /*arrayLis1.add(-1, "should fail");
                fail("should have had exception here");*/
                /*try
                {
                    
                }
            catch (java.lang.reflect.InvocationTargetException e)
            {
                //assertTrue(true);
            }*/
    }
    
    @FXML
    void button0()
    {
        spaceMap.selectPlanet(0);
        updateDetails();
    }
    @FXML
    void button1()
    {
        spaceMap.selectPlanet(1);
        updateDetails();
    }
    @FXML
    void button2()
    {
        spaceMap.selectPlanet(2);
        updateDetails();
    }
    @FXML
    void button3()
    {
        spaceMap.selectPlanet(3);
        updateDetails();
    }
    @FXML
    void button4()
    {
        spaceMap.selectPlanet(4);
        updateDetails();
    }
    @FXML
    void button5()
    {
        spaceMap.selectPlanet(5);
        updateDetails();
    }
    @FXML
    void button6()
    {
        spaceMap.selectPlanet(6);
        updateDetails();
    }
    @FXML
    void button7()
    {
        spaceMap.selectPlanet(7);
        updateDetails();
    }
    @FXML
    void button8()
    {
        spaceMap.selectPlanet(8);
        updateDetails();
    }
    @FXML
    void button9()
    {
        spaceMap.selectPlanet(9);
        updateDetails();
    }    
    @FXML
    void button10()
    {
        spaceMap.selectPlanet(10);
        updateDetails();
    }    
    @FXML
    void button11()
    {
        spaceMap.selectPlanet(11);
        updateDetails();
    }    
    @FXML
    void button12()
    {
        spaceMap.selectPlanet(12);
        updateDetails();
    }    
    @FXML
    void button13()
    {
        spaceMap.selectPlanet(13);
        updateDetails();
    }    
    @FXML
    void button14()
    {
        spaceMap.selectPlanet(14);
        updateDetails();
    }   
    @FXML
    void button15()
    {
        spaceMap.selectPlanet(15);
        updateDetails();
    }    
    @FXML
    void button16()
    {
        spaceMap.selectPlanet(16);
        updateDetails();
    }    
    @FXML
    void button17()
    {
        spaceMap.selectPlanet(17);
        updateDetails();
    }    
    @FXML
    void button18()
    {
        spaceMap.selectPlanet(18);
        updateDetails();
    }   
    @FXML
    void button19()
    {
        spaceMap.selectPlanet(19);
        updateDetails();
    }   
    @FXML
    void button20()
    {
        spaceMap.selectPlanet(20);
        updateDetails();
    }    
    @FXML
    void button21()
    {
        spaceMap.selectPlanet(21);
        updateDetails();
    }   
    @FXML
    void button22()
    {
        spaceMap.selectPlanet(22);
        updateDetails();
    }   
        @FXML
    void button23()
    {
        spaceMap.selectPlanet(23);
        updateDetails();
    }    
    @FXML
    void button24()
    {
        spaceMap.selectPlanet(24);
        updateDetails();
    }    
    @FXML
    void button25()
    {
        spaceMap.selectPlanet(25);
        updateDetails();
    }    
    @FXML
    void button26()
    {
        spaceMap.selectPlanet(26);
        updateDetails();
    }    
    @FXML
    void button27()
    {
        spaceMap.selectPlanet(27);
        updateDetails();
    }    
    @FXML
    void button28()
    {
        spaceMap.selectPlanet(28);
        updateDetails();
    }   
    @FXML
    void button29()
    {
        spaceMap.selectPlanet(29);
        updateDetails();
    }    
    @FXML
    void button30()
    {
        spaceMap.selectPlanet(30);
        updateDetails();
    }    
    @FXML
    void button31()
    {
        spaceMap.selectPlanet(31);
        updateDetails();
    }    
    @FXML
    void button32()
    {
        spaceMap.selectPlanet(32);
        updateDetails();
    }   
    @FXML
    void button33()
    {
        spaceMap.selectPlanet(33);
        updateDetails();
    }   
    @FXML
    void button34()
    {
        spaceMap.selectPlanet(34);
        updateDetails();
    }    
    @FXML
    void button35()
    {
        spaceMap.selectPlanet(35);
        updateDetails();
    }   
    @FXML
    void button36()
    {
        spaceMap.selectPlanet(36);
        updateDetails();
    }
        @FXML
    void button37()
    {
        spaceMap.selectPlanet(37);
        updateDetails();
    }    
    @FXML
    void button38()
    {
        spaceMap.selectPlanet(38);
        updateDetails();
    }    
    @FXML
    void button39()
    {
        spaceMap.selectPlanet(39);
        updateDetails();
    }    
    @FXML
    void button40()
    {
        spaceMap.selectPlanet(40);
        updateDetails();
    }    
    @FXML
    void button41()
    {
        spaceMap.selectPlanet(41);
        updateDetails();
    }    
    @FXML
    void button42()
    {
        spaceMap.selectPlanet(42);
        updateDetails();
    }   
    @FXML
    void button43()
    {
        spaceMap.selectPlanet(43);
        updateDetails();
    }    
    @FXML
    void button44()
    {
        spaceMap.selectPlanet(44);
        updateDetails();
    }    
    @FXML
    void button45()
    {
        spaceMap.selectPlanet(45);
        updateDetails();
    }    
    @FXML
    void button46()
    {
        spaceMap.selectPlanet(46);
        updateDetails();
    }   
    @FXML
    void button47()
    {
        spaceMap.selectPlanet(47);
        updateDetails();
    }   
    @FXML
    void button48()
    {
        spaceMap.selectPlanet(48);
        updateDetails();
    }    
    @FXML
    void button49()
    {
        spaceMap.selectPlanet(49);
        updateDetails();
    }   
    @FXML
    void button50()
    {
        spaceMap.selectPlanet(50);
        updateDetails();
    }
        @FXML
    void button51()
    {
        spaceMap.selectPlanet(51);
        updateDetails();
    }    
    @FXML
    void button52()
    {
        spaceMap.selectPlanet(52);
        updateDetails();
    }    
    @FXML
    void button53()
    {
        spaceMap.selectPlanet(53);
        updateDetails();
    }    
    @FXML
    void button54()
    {
        spaceMap.selectPlanet(54);
        updateDetails();
    }    
    @FXML
    void button55()
    {
        spaceMap.selectPlanet(55);
        updateDetails();
    }    
    @FXML
    void button56()
    {
        spaceMap.selectPlanet(56);
        updateDetails();
    }   
    @FXML
    void button57()
    {
        spaceMap.selectPlanet(57);
        updateDetails();
    }    
    @FXML
    void button58()
    {
        spaceMap.selectPlanet(58);
        updateDetails();
    }    
    @FXML
    void button59()
    {
        spaceMap.selectPlanet(59);
        updateDetails();
    }    
    @FXML
    void button60()
    {
        spaceMap.selectPlanet(60);
        updateDetails();
    }   
    @FXML
    void button61()
    {
        spaceMap.selectPlanet(61);
        updateDetails();
    }   
    @FXML
    void button62()
    {
        spaceMap.selectPlanet(62);
        updateDetails();
    }    
    @FXML
    void button63()
    {
        spaceMap.selectPlanet(63);
        updateDetails();
    }   
    @FXML
    void button64()
    {
        spaceMap.selectPlanet(64);
        updateDetails();
    }
        @FXML
    void button65()
    {
        spaceMap.selectPlanet(65);
        updateDetails();
    }    
    @FXML
    void button66()
    {
        spaceMap.selectPlanet(66);
        updateDetails();
    }    
    @FXML
    void button67()
    {
        spaceMap.selectPlanet(67);
        updateDetails();
    }    
    @FXML
    void button68()
    {
        spaceMap.selectPlanet(68);
        updateDetails();
    }    
    @FXML
    void button69()
    {
        spaceMap.selectPlanet(69);
        updateDetails();
    }    
    @FXML
    void button70()
    {
        spaceMap.selectPlanet(70);
        updateDetails();
    }   
    @FXML
    void button71()
    {
        spaceMap.selectPlanet(71);
        updateDetails();
    }    
    @FXML
    void button72()
    {
        spaceMap.selectPlanet(72);
        updateDetails();
    }    
    @FXML
    void button73()
    {
        spaceMap.selectPlanet(73);
        updateDetails();
    }    
    @FXML
    void button74()
    {
        spaceMap.selectPlanet(74);
        updateDetails();
    }   
    @FXML
    void button75()
    {
        spaceMap.selectPlanet(75);
        updateDetails();
    }   
    @FXML
    void button76()
    {
        spaceMap.selectPlanet(76);
        updateDetails();
    }    
    @FXML
    void button77()
    {
        spaceMap.selectPlanet(77);
        updateDetails();
    }   
    @FXML
    void button78()
    {
        spaceMap.selectPlanet(78);
        updateDetails();
    }
    @FXML
    void button79()
    {
        spaceMap.selectPlanet(79);
        updateDetails();
    }
    @FXML
    void button80()
    {
        spaceMap.selectPlanet(80);
        updateDetails();
    }    
    @FXML
    void button81()
    {
        spaceMap.selectPlanet(81);
        updateDetails();
    }    
    @FXML
    void button82()
    {
        spaceMap.selectPlanet(82);
        updateDetails();
    }    
    @FXML
    void button83()
    {
        spaceMap.selectPlanet(83);
        updateDetails();
    }   
    @FXML
    void button84()
    {
        spaceMap.selectPlanet(84);
        updateDetails();
    }    
    @FXML
    void button85()
    {
        spaceMap.selectPlanet(85);
        updateDetails();
    }    
    @FXML
    void button86()
    {
        spaceMap.selectPlanet(86);
        updateDetails();
    }    
    @FXML
    void button87()
    {
        spaceMap.selectPlanet(87);
        updateDetails();
    }   
    @FXML
    void button88()
    {
        spaceMap.selectPlanet(88);
        updateDetails();
    }   
    @FXML
    void button89()
    {
        spaceMap.selectPlanet(89);
        updateDetails();
    }    
    @FXML
    void button90()
    {
        spaceMap.selectPlanet(90);
        updateDetails();
    }   
    @FXML
    void button91()
    {
        spaceMap.selectPlanet(91);
        updateDetails();
    }
        @FXML
    void button92()
    {
        spaceMap.selectPlanet(92);
        updateDetails();
    }    
    @FXML
    void button93()
    {
        spaceMap.selectPlanet(93);
        updateDetails();
    }    
    @FXML
    void button94()
    {
        spaceMap.selectPlanet(94);
        updateDetails();
    }    
    @FXML
    void button95()
    {
        spaceMap.selectPlanet(95);
        updateDetails();
    }    
    @FXML
    void button96()
    {
        spaceMap.selectPlanet(96);
        updateDetails();
    }    
    @FXML
    void button97()
    {
        spaceMap.selectPlanet(97);
        updateDetails();
    }   
    
    
    public int getInput()
    {
        return input;
    }
    
    void updatePlanetDescription()
    {
        planetLabel.setText(spaceMap.getPlanetDescription());
    }
    
    void updatePlayerDescription()
    {
        raresLabel.setText(spaceMap.getPlayerRares());
        playerLabel.setText(spaceMap.getPlayerDescription());
        playerLabel1.setText(spaceMap.getPlayerDescription());
        playerResourceLabel.setText(spaceMap.getPlayerResourceList());
    }
    
}
