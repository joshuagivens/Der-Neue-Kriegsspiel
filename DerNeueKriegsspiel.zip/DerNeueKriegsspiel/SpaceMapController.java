import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import java.io.InputStream;

import java.io.IOException;

import java.net.URL;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;


import javafx.scene.control.CheckBox;

import javafx.scene.image.Image;

import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
/**
 * Write a description of class BoxCanyonController here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapController
{
    /*@FXML
    private Button planetButton1;
    @FXML
    private Button planetButton2;
    @FXML
    private Button planetButton3;*/
    
    @FXML
    private Label queueLabel;
    
    @FXML
    private TextField shipSelector;
    
    @FXML
    private Label planetLabel;
    
    @FXML
    private Label playerLabel;
    
    @FXML
    private Label shipListLabel;
    
    @FXML
    private Label enemyShipListLabel;
    
    @FXML
    private Label shipDescriptionLabel;
    
    @FXML
    private Label label;
    
    @FXML
    private ImageView image;
    
    @FXML
    private ImageView victoryImage;
    
    private int turn = 0;
    
    private int input = 6;
    
    private int t1 = 0;
    
    private int t2 = 0;
    
    //BoxCanyonImportantStringHolder s = new BoxCanyonImportantStringHolder();
    
    private SpaceMap spaceMap = new SpaceMap();//BoxCanyon(s);
    
    private SpaceMapPlayer player;
    
    private void updateDetails()
    {
        updateQueue();
        updatePlanetDescription();
        updatePlayerDescription();
        updateShipLists();
    }
    
    private void updateShipLists()
    {
        shipListLabel.setText(spaceMap.getShipList());
        enemyShipListLabel.setText(spaceMap.getEnemyShipList());
    }
    
    private void updateQueue()
    {
        queueLabel.setText(spaceMap.getQueue());
    }
    
    @FXML
    private void endTurn()
    {
        spaceMap.endTurn();
        updateDetails();
    }
    
    @FXML
    private void buy0()
    {
        spaceMap.addQueueItem((short)(0));
        updateDetails();
    }
    @FXML
    private void buy1()
    {
        spaceMap.addQueueItem((short)(1));
        updateDetails();
    }
    @FXML
    private void buy2()
    {
        spaceMap.addQueueItem((short)(2));
        updateDetails();
    }
    @FXML
    private void buy3()
    {
        spaceMap.addQueueItem((short)(3));
        updateDetails();
    }
    @FXML
    private void buy4()
    {
        spaceMap.addQueueItem((short)(4));
        updateDetails();
    }
    @FXML
    private void buy5()
    {
        spaceMap.addQueueItem((short)(5));
        updateDetails();
    }
    @FXML
    private void buy6()
    {
        spaceMap.addQueueItem((short)(6));
        updateDetails();
    }
    @FXML
    private void buy7()
    {
        spaceMap.addQueueItem((short)(7));
        updateDetails();
    }
    @FXML
    private void buy8()
    {
        spaceMap.addQueueItem((short)(8));
        updateDetails();
    }
    @FXML
    private void buy9()
    {
        spaceMap.addQueueItem((short)(9));
        updateDetails();
    }
    @FXML
    private void buy10()
    {
        spaceMap.addQueueItem((short)(10));
        updateDetails();
    }
    @FXML
    private void buy11()
    {
        spaceMap.addQueueItem((short)(11));
        updateDetails();
    }
    
    @FXML
    private void cancel()
    {
        spaceMap.cancel();
        updateDetails();
    }
    
    
    @FXML
    private void updateSelectedVessel()
    {
        //selectVessel;
        //String text = ;
        
        
            if(shipSelector.getText().equals(""))
            {
            
            }
            else
            {
                shipDescriptionLabel.setText(spaceMap.selectShip((short)(Double.parseDouble(shipSelector.getText()))));
            }    
            updateDetails();
            /*arrayLis1.add(-1, "should fail");
                fail("should have had exception here");*/
                /*try
                {
                    
                }
            catch (java.lang.reflect.InvocationTargetException e)
            {
                //assertTrue(true);
            }*/
    }
    
    @FXML
    void button0()
    {
        spaceMap.selectPlanet(0);
        updateDetails();
    }
    @FXML
    void button1()
    {
        spaceMap.selectPlanet(1);
        updateDetails();
    }
    @FXML
    void button2()
    {
        spaceMap.selectPlanet(2);
        updateDetails();
    }
    @FXML
    void button3()
    {
        spaceMap.selectPlanet(3);
        updateDetails();
    }
    @FXML
    void button4()
    {
        spaceMap.selectPlanet(4);
        updateDetails();
    }
    @FXML
    void button5()
    {
        spaceMap.selectPlanet(5);
        updateDetails();
    }
    @FXML
    void button6()
    {
        spaceMap.selectPlanet(6);
        updateDetails();
    }
    @FXML
    void button7()
    {
        spaceMap.selectPlanet(7);
        updateDetails();
    }
    @FXML
    void button8()
    {
        spaceMap.selectPlanet(8);
        updateDetails();
    }
    @FXML
    void button9()
    {
        spaceMap.selectPlanet(9);
        updateDetails();
    }    
    @FXML
    void button10()
    {
        spaceMap.selectPlanet(10);
        updateDetails();
    }    
    @FXML
    void button11()
    {
        spaceMap.selectPlanet(11);
        updateDetails();
    }    
    @FXML
    void button12()
    {
        spaceMap.selectPlanet(12);
        updateDetails();
    }    
    @FXML
    void button13()
    {
        spaceMap.selectPlanet(13);
        updateDetails();
    }    
    @FXML
    void button14()
    {
        spaceMap.selectPlanet(14);
        updateDetails();
    }   
    @FXML
    void button15()
    {
        spaceMap.selectPlanet(15);
        updateDetails();
    }    
    @FXML
    void button16()
    {
        spaceMap.selectPlanet(16);
        updateDetails();
    }    
    @FXML
    void button17()
    {
        spaceMap.selectPlanet(17);
        updateDetails();
    }    
    @FXML
    void button18()
    {
        spaceMap.selectPlanet(18);
        updateDetails();
    }   
    @FXML
    void button19()
    {
        spaceMap.selectPlanet(19);
        updateDetails();
    }   
    @FXML
    void button20()
    {
        spaceMap.selectPlanet(20);
        updateDetails();
    }    
    @FXML
    void button21()
    {
        spaceMap.selectPlanet(21);
        updateDetails();
    }   
    @FXML
    void button22()
    {
        spaceMap.selectPlanet(22);
        updateDetails();
    }   
        @FXML
    void button23()
    {
        spaceMap.selectPlanet(23);
        updateDetails();
    }    
    @FXML
    void button24()
    {
        spaceMap.selectPlanet(24);
        updateDetails();
    }    
    @FXML
    void button25()
    {
        spaceMap.selectPlanet(25);
        updateDetails();
    }    
    @FXML
    void button26()
    {
        spaceMap.selectPlanet(26);
        updateDetails();
    }    
    @FXML
    void button27()
    {
        spaceMap.selectPlanet(27);
        updateDetails();
    }    
    @FXML
    void button28()
    {
        spaceMap.selectPlanet(28);
        updateDetails();
    }   
    @FXML
    void button29()
    {
        spaceMap.selectPlanet(29);
        updateDetails();
    }    
    @FXML
    void button30()
    {
        spaceMap.selectPlanet(30);
        updateDetails();
    }    
    @FXML
    void button31()
    {
        spaceMap.selectPlanet(31);
        updateDetails();
    }    
    @FXML
    void button32()
    {
        spaceMap.selectPlanet(32);
        updateDetails();
    }   
    @FXML
    void button33()
    {
        spaceMap.selectPlanet(33);
        updateDetails();
    }   
    @FXML
    void button34()
    {
        spaceMap.selectPlanet(34);
        updateDetails();
    }    
    @FXML
    void button35()
    {
        spaceMap.selectPlanet(35);
        updateDetails();
    }   
    @FXML
    void button36()
    {
        spaceMap.selectPlanet(36);
        updateDetails();
    }
        @FXML
    void button37()
    {
        spaceMap.selectPlanet(37);
        updateDetails();
    }    
    @FXML
    void button38()
    {
        spaceMap.selectPlanet(38);
        updateDetails();
    }    
    @FXML
    void button39()
    {
        spaceMap.selectPlanet(39);
        updateDetails();
    }    
    @FXML
    void button40()
    {
        spaceMap.selectPlanet(40);
        updateDetails();
    }    
    @FXML
    void button41()
    {
        spaceMap.selectPlanet(41);
        updateDetails();
    }    
    @FXML
    void button42()
    {
        spaceMap.selectPlanet(42);
        updateDetails();
    }   
    @FXML
    void button43()
    {
        spaceMap.selectPlanet(43);
        updateDetails();
    }    
    @FXML
    void button44()
    {
        spaceMap.selectPlanet(44);
        updateDetails();
    }    
    @FXML
    void button45()
    {
        spaceMap.selectPlanet(45);
        updateDetails();
    }    
    @FXML
    void button46()
    {
        spaceMap.selectPlanet(46);
        updateDetails();
    }   
    @FXML
    void button47()
    {
        spaceMap.selectPlanet(47);
        updateDetails();
    }   
    @FXML
    void button48()
    {
        spaceMap.selectPlanet(48);
        updateDetails();
    }    
    @FXML
    void button49()
    {
        spaceMap.selectPlanet(49);
        updateDetails();
    }   
    @FXML
    void button50()
    {
        spaceMap.selectPlanet(50);
        updateDetails();
    }
        @FXML
    void button51()
    {
        spaceMap.selectPlanet(51);
        updateDetails();
    }    
    @FXML
    void button52()
    {
        spaceMap.selectPlanet(52);
        updateDetails();
    }    
    @FXML
    void button53()
    {
        spaceMap.selectPlanet(53);
        updateDetails();
    }    
    @FXML
    void button54()
    {
        spaceMap.selectPlanet(54);
        updateDetails();
    }    
    @FXML
    void button55()
    {
        spaceMap.selectPlanet(55);
        updateDetails();
    }    
    @FXML
    void button56()
    {
        spaceMap.selectPlanet(56);
        updateDetails();
    }   
    @FXML
    void button57()
    {
        spaceMap.selectPlanet(57);
        updateDetails();
    }    
    @FXML
    void button58()
    {
        spaceMap.selectPlanet(58);
        updateDetails();
    }    
    @FXML
    void button59()
    {
        spaceMap.selectPlanet(59);
        updateDetails();
    }    
    @FXML
    void button60()
    {
        spaceMap.selectPlanet(60);
        updateDetails();
    }   
    @FXML
    void button61()
    {
        spaceMap.selectPlanet(61);
        updateDetails();
    }   
    @FXML
    void button62()
    {
        spaceMap.selectPlanet(62);
        updateDetails();
    }    
    @FXML
    void button63()
    {
        spaceMap.selectPlanet(63);
        updateDetails();
    }   
    @FXML
    void button64()
    {
        spaceMap.selectPlanet(64);
        updateDetails();
    }
        @FXML
    void button65()
    {
        spaceMap.selectPlanet(65);
        updateDetails();
    }    
    @FXML
    void button66()
    {
        spaceMap.selectPlanet(66);
        updateDetails();
    }    
    @FXML
    void button67()
    {
        spaceMap.selectPlanet(67);
        updateDetails();
    }    
    @FXML
    void button68()
    {
        spaceMap.selectPlanet(68);
        updateDetails();
    }    
    @FXML
    void button69()
    {
        spaceMap.selectPlanet(69);
        updateDetails();
    }    
    @FXML
    void button70()
    {
        spaceMap.selectPlanet(70);
        updateDetails();
    }   
    @FXML
    void button71()
    {
        spaceMap.selectPlanet(71);
        updateDetails();
    }    
    @FXML
    void button72()
    {
        spaceMap.selectPlanet(72);
        updateDetails();
    }    
    @FXML
    void button73()
    {
        spaceMap.selectPlanet(73);
        updateDetails();
    }    
    @FXML
    void button74()
    {
        spaceMap.selectPlanet(74);
        updateDetails();
    }   
    @FXML
    void button75()
    {
        spaceMap.selectPlanet(75);
        updateDetails();
    }   
    @FXML
    void button76()
    {
        spaceMap.selectPlanet(76);
        updateDetails();
    }    
    @FXML
    void button77()
    {
        spaceMap.selectPlanet(77);
        updateDetails();
    }   
    @FXML
    void button78()
    {
        spaceMap.selectPlanet(78);
        updateDetails();
    }
    @FXML
    void button79()
    {
        spaceMap.selectPlanet(79);
        updateDetails();
    }
    @FXML
    void button80()
    {
        spaceMap.selectPlanet(80);
        updateDetails();
    }    
    @FXML
    void button81()
    {
        spaceMap.selectPlanet(81);
        updateDetails();
    }    
    @FXML
    void button82()
    {
        spaceMap.selectPlanet(82);
        updateDetails();
    }    
    @FXML
    void button83()
    {
        spaceMap.selectPlanet(83);
        updateDetails();
    }   
    @FXML
    void button84()
    {
        spaceMap.selectPlanet(84);
        updateDetails();
    }    
    @FXML
    void button85()
    {
        spaceMap.selectPlanet(85);
        updateDetails();
    }    
    @FXML
    void button86()
    {
        spaceMap.selectPlanet(86);
        updateDetails();
    }    
    @FXML
    void button87()
    {
        spaceMap.selectPlanet(87);
        updateDetails();
    }   
    @FXML
    void button88()
    {
        spaceMap.selectPlanet(88);
        updateDetails();
    }   
    @FXML
    void button89()
    {
        spaceMap.selectPlanet(89);
        updateDetails();
    }    
    @FXML
    void button90()
    {
        spaceMap.selectPlanet(90);
        updateDetails();
    }   
    @FXML
    void button91()
    {
        spaceMap.selectPlanet(91);
        updateDetails();
    }
        @FXML
    void button92()
    {
        spaceMap.selectPlanet(92);
        updateDetails();
    }    
    @FXML
    void button93()
    {
        spaceMap.selectPlanet(93);
        updateDetails();
    }    
    @FXML
    void button94()
    {
        spaceMap.selectPlanet(94);
        updateDetails();
    }    
    @FXML
    void button95()
    {
        spaceMap.selectPlanet(95);
        updateDetails();
    }    
    @FXML
    void button96()
    {
        spaceMap.selectPlanet(96);
        updateDetails();
    }    
    @FXML
    void button97()
    {
        spaceMap.selectPlanet(97);
        updateDetails();
    }   
    @FXML
    void button98()
    {
        spaceMap.selectPlanet(98);
        updateDetails();
    }    
    @FXML
    void button99()
    {
        spaceMap.selectPlanet(99);
        updateDetails();
    }    
    @FXML
    void button100()
    {
        spaceMap.selectPlanet(100);
        updateDetails();
    }    
    @FXML
    void button101()
    {
        spaceMap.selectPlanet(101);
        updateDetails();
    }   
    @FXML
    void button102()
    {
        spaceMap.selectPlanet(102);
        updateDetails();
    }   
    @FXML
    void button103()
    {
        spaceMap.selectPlanet(103);
        updateDetails();
    }    
    @FXML
    void button104()
    {
        spaceMap.selectPlanet(104);
        updateDetails();
    }   
    @FXML
    void button105()
    {
        spaceMap.selectPlanet(105);
        updateDetails();
    }
        @FXML
    void button106()
    {
        spaceMap.selectPlanet(106);
        updateDetails();
    }    
    @FXML
    void button107()
    {
        spaceMap.selectPlanet(107);
        updateDetails();
    }    
    @FXML
    void button108()
    {
        spaceMap.selectPlanet(108);
        updateDetails();
    }    
    @FXML
    void button109()
    {
        spaceMap.selectPlanet(109);
        updateDetails();
    }    
    @FXML
    void button110()
    {
        spaceMap.selectPlanet(110);
        updateDetails();
    }    
    @FXML
    void button111()
    {
        spaceMap.selectPlanet(111);
        updateDetails();
    }   
    @FXML
    void button112()
    {
        spaceMap.selectPlanet(112);
        updateDetails();
    }    
    @FXML
    void button113()
    {
        spaceMap.selectPlanet(113);
        updateDetails();
    }    
    @FXML
    void button114()
    {
        spaceMap.selectPlanet(114);
        updateDetails();
    }    
    @FXML
    void button115()
    {
        spaceMap.selectPlanet(115);
        updateDetails();
    }   
    @FXML
    void button116()
    {
        spaceMap.selectPlanet(116);
        updateDetails();
    }   
    @FXML
    void button117()
    {
        spaceMap.selectPlanet(117);
        updateDetails();
    }    
    @FXML
    void button118()
    {
        spaceMap.selectPlanet(118);
        updateDetails();
    }   
    @FXML
    void button119()
    {
        spaceMap.selectPlanet(119);
        updateDetails();
    }   
    @FXML
    void button120()
    {
        spaceMap.selectPlanet(120);
        updateDetails();
    }
        @FXML
    void button121()
    {
        spaceMap.selectPlanet(121);
        updateDetails();
    }    
    @FXML
    void button122()
    {
        spaceMap.selectPlanet(122);
        updateDetails();
    }    
    @FXML
    void button123()
    {
        spaceMap.selectPlanet(123);
        updateDetails();
    }    
    @FXML
    void button124()
    {
        spaceMap.selectPlanet(124);
        updateDetails();
    }    
    @FXML
    void button125()
    {
        spaceMap.selectPlanet(125);
        updateDetails();
    }    
    @FXML
    void button126()
    {
        spaceMap.selectPlanet(126);
        updateDetails();
    }   
    @FXML
    void button127()
    {
        spaceMap.selectPlanet(127);
        updateDetails();
    }    
    @FXML
    void button128()
    {
        spaceMap.selectPlanet(128);
        updateDetails();
    }    
    @FXML
    void button129()
    {
        spaceMap.selectPlanet(129);
        updateDetails();
    }    
    @FXML
    void button130()
    {
        spaceMap.selectPlanet(130);
        updateDetails();
    }   
    @FXML
    void button131()
    {
        spaceMap.selectPlanet(131);
        updateDetails();
    }   
    @FXML
    void button132()
    {
        spaceMap.selectPlanet(132);
        updateDetails();
    }    
    @FXML
    void button133()
    {
        spaceMap.selectPlanet(133);
        updateDetails();
    }   
    @FXML
    void button134()
    {
        spaceMap.selectPlanet(134);
        updateDetails();
    }
        @FXML
    void button135()
    {
        spaceMap.selectPlanet(135);
        updateDetails();
    }    
    @FXML
    void button136()
    {
        spaceMap.selectPlanet(136);
        updateDetails();
    }    
    @FXML
    void button137()
    {
        spaceMap.selectPlanet(137);
        updateDetails();
    }    
    @FXML
    void button138()
    {
        spaceMap.selectPlanet(138);
        updateDetails();
    }    
    @FXML
    void button139()
    {
        spaceMap.selectPlanet(139);
        updateDetails();
    }    
    @FXML
    void button140()
    {
        spaceMap.selectPlanet(140);
        updateDetails();
    }   
    @FXML
    void button141()
    {
        spaceMap.selectPlanet(141);
        updateDetails();
    }    
    @FXML
    void button142()
    {
        spaceMap.selectPlanet(142);
        updateDetails();
    }    
    @FXML
    void button143()
    {
        spaceMap.selectPlanet(143);
        updateDetails();
    }    
    @FXML
    void button144()
    {
        spaceMap.selectPlanet(144);
        updateDetails();
    }   
    @FXML
    void button145()
    {
        spaceMap.selectPlanet(145);
        updateDetails();
    }   
    @FXML
    void button146()
    {
        spaceMap.selectPlanet(146);
        updateDetails();
    }    
    @FXML
    void button147()
    {
        spaceMap.selectPlanet(147);
        updateDetails();
    }   
    @FXML
    void button148()
    {
        spaceMap.selectPlanet(148);
        updateDetails();
    }
    @FXML
    void button149()
    {
        spaceMap.selectPlanet(149);
        updateDetails();
    }    
    @FXML
    void button150()
    {
        spaceMap.selectPlanet(150);
        updateDetails();
    }    
    @FXML
    void button151()
    {
        spaceMap.selectPlanet(151);
        updateDetails();
    }    
    @FXML
    void button152()
    {
        spaceMap.selectPlanet(152);
        updateDetails();
    }    
    @FXML
    void button153()
    {
        spaceMap.selectPlanet(153);
        updateDetails();
    }    
    @FXML
    void button154()
    {
        spaceMap.selectPlanet(154);
        updateDetails();
    }   
    @FXML
    void button155()
    {
        spaceMap.selectPlanet(155);
        updateDetails();
    }    
    @FXML
    void button156()
    {
        spaceMap.selectPlanet(156);
        updateDetails();
    }    
    @FXML
    void button157()
    {
        spaceMap.selectPlanet(157);
        updateDetails();
    }    
    @FXML
    void button158()
    {
        spaceMap.selectPlanet(158);
        updateDetails();
    }   
    @FXML
    void button159()
    {
        spaceMap.selectPlanet(159);
        updateDetails();
    }   
    @FXML
    void button160()
    {
        spaceMap.selectPlanet(160);
        updateDetails();
    }    
    @FXML
    void button161()
    {
        spaceMap.selectPlanet(161);
        updateDetails();
    }   
    @FXML
    void button162()
    {
        spaceMap.selectPlanet(162);
        updateDetails();
    }
        @FXML
    void button163()
    {
        spaceMap.selectPlanet(163);
        updateDetails();
    }    
    @FXML
    void button164()
    {
        spaceMap.selectPlanet(164);
        updateDetails();
    }    
    @FXML
    void button165()
    {
        spaceMap.selectPlanet(165);
        updateDetails();
    }    
    @FXML
    void button166()
    {
        spaceMap.selectPlanet(166);
        updateDetails();
    }    
    @FXML
    void button167()
    {
        spaceMap.selectPlanet(167);
        updateDetails();
    }    
    @FXML
    void button168()
    {
        spaceMap.selectPlanet(168);
        updateDetails();
    }   
    @FXML
    void button169()
    {
        spaceMap.selectPlanet(169);
        updateDetails();
    }    
    @FXML
    void button170()
    {
        spaceMap.selectPlanet(170);
        updateDetails();
    }    
    @FXML
    void button171()
    {
        spaceMap.selectPlanet(171);
        updateDetails();
    }    
    @FXML
    void button172()
    {
        spaceMap.selectPlanet(172);
        updateDetails();
    }   
    @FXML
    void button173()
    {
        spaceMap.selectPlanet(173);
        updateDetails();
    }   
    @FXML
    void button174()
    {
        spaceMap.selectPlanet(174);
        updateDetails();
    }    
    @FXML
    void button175()
    {
        spaceMap.selectPlanet(175);
        updateDetails();
    }   
    @FXML
    void button176()
    {
        spaceMap.selectPlanet(176);
        updateDetails();
    }
        @FXML
    void button177()
    {
        spaceMap.selectPlanet(177);
        updateDetails();
    }    
    @FXML
    void button178()
    {
        spaceMap.selectPlanet(178);
        updateDetails();
    }    
    @FXML
    void button179()
    {
        spaceMap.selectPlanet(179);
        updateDetails();
    }    
    @FXML
    void button180()
    {
        spaceMap.selectPlanet(180);
        updateDetails();
    }    
    @FXML
    void button181()
    {
        spaceMap.selectPlanet(181);
        updateDetails();
    }    
    @FXML
    void button182()
    {
        spaceMap.selectPlanet(182);
        updateDetails();
    }   
    @FXML
    void button183()
    {
        spaceMap.selectPlanet(183);
        updateDetails();
    }    
    @FXML
    void button184()
    {
        spaceMap.selectPlanet(184);
        updateDetails();
    }    
    @FXML
    void button185()
    {
        spaceMap.selectPlanet(185);
        updateDetails();
    }    
    @FXML
    void button186()
    {
        spaceMap.selectPlanet(186);
        updateDetails();
    }   
    @FXML
    void button187()
    {
        spaceMap.selectPlanet(187);
        updateDetails();
    }   
    @FXML
    void button188()
    {
        spaceMap.selectPlanet(188);
        updateDetails();
    }    
    @FXML
    void button189()
    {
        spaceMap.selectPlanet(189);
        updateDetails();
    }   
    @FXML
    void button190()
    {
        spaceMap.selectPlanet(190);
        updateDetails();
    }
        @FXML
    void button191()
    {
        spaceMap.selectPlanet(191);
        updateDetails();
    }    
    @FXML
    void button192()
    {
        spaceMap.selectPlanet(192);
        updateDetails();
    }    
    @FXML
    void button193()
    {
        spaceMap.selectPlanet(193);
        updateDetails();
    }    
    @FXML
    void button194()
    {
        spaceMap.selectPlanet(194);
        updateDetails();
    }    
    @FXML
    void button195()
    {
        spaceMap.selectPlanet(195);
        updateDetails();
    }    
    @FXML
    void button196()
    {
        spaceMap.selectPlanet(196);
        updateDetails();
    }   
    @FXML
    void button197()
    {
        spaceMap.selectPlanet(197);
        updateDetails();
    }    
    @FXML
    void button198()
    {
        spaceMap.selectPlanet(198);
        updateDetails();
    }    
    @FXML
    void button199()
    {
        spaceMap.selectPlanet(199);
        updateDetails();
    }    
    @FXML
    void button200()
    {
        spaceMap.selectPlanet(200);
        updateDetails();
    }   
    @FXML
    void button201()
    {
        spaceMap.selectPlanet(201);
        updateDetails();
    }   
    @FXML
    void button202()
    {
        spaceMap.selectPlanet(202);
        updateDetails();
    }    
    @FXML
    void button203()
    {
        spaceMap.selectPlanet(203);
        updateDetails();
    }   
    @FXML
    void button204()
    {
        spaceMap.selectPlanet(204);
        updateDetails();
    }
        @FXML
    void button205()
    {
        spaceMap.selectPlanet(205);
        updateDetails();
    }    
    @FXML
    void button206()
    {
        spaceMap.selectPlanet(206);
        updateDetails();
    }    
    @FXML
    void button207()
    {
        spaceMap.selectPlanet(207);
        updateDetails();
    }    
    @FXML
    void button208()
    {
        spaceMap.selectPlanet(208);
        updateDetails();
    }    
    @FXML
    void button209()
    {
        spaceMap.selectPlanet(209);
        updateDetails();
    }    
    @FXML
    void button210()
    {
        spaceMap.selectPlanet(210);
        updateDetails();
    }   
    @FXML
    void button211()
    {
        spaceMap.selectPlanet(211);
        updateDetails();
    }    
    @FXML
    void button212()
    {
        spaceMap.selectPlanet(212);
        updateDetails();
    }    
    @FXML
    void button213()
    {
        spaceMap.selectPlanet(213);
        updateDetails();
    }    
    @FXML
    void button214()
    {
        spaceMap.selectPlanet(214);
        updateDetails();
    }   
    @FXML
    void button215()
    {
        spaceMap.selectPlanet(215);
        updateDetails();
    }   
    @FXML
    void button216()
    {
        spaceMap.selectPlanet(216);
        updateDetails();
    }    
    @FXML
    void button217()
    {
        spaceMap.selectPlanet(217);
        updateDetails();
    }   
    @FXML
    void button218()
    {
        spaceMap.selectPlanet(218);
        updateDetails();
    }
        @FXML
    void button219()
    {
        spaceMap.selectPlanet(219);
        updateDetails();
    }    
    @FXML
    void button220()
    {
        spaceMap.selectPlanet(220);
        updateDetails();
    }    
    @FXML
    void button221()
    {
        spaceMap.selectPlanet(221);
        updateDetails();
    }    
    @FXML
    void button222()
    {
        spaceMap.selectPlanet(222);
        updateDetails();
    }    
    @FXML
    void button223()
    {
        spaceMap.selectPlanet(223);
        updateDetails();
    }    
    @FXML
    void button224()
    {
        spaceMap.selectPlanet(224);
        updateDetails();
    }   
    @FXML
    void button225()
    {
        spaceMap.selectPlanet(225);
        updateDetails();
    }    
    @FXML
    void button226()
    {
        spaceMap.selectPlanet(226);
        updateDetails();
    }    
    @FXML
    void button227()
    {
        spaceMap.selectPlanet(227);
        updateDetails();
    }    
    @FXML
    void button228()
    {
        spaceMap.selectPlanet(228);
        updateDetails();
    }   
    @FXML
    void button229()
    {
        spaceMap.selectPlanet(229);
        updateDetails();
    }   
    @FXML
    void button230()
    {
        spaceMap.selectPlanet(230);
        updateDetails();
    }    
    @FXML
    void button231()
    {
        spaceMap.selectPlanet(231);
        updateDetails();
    }   
    @FXML
    void button232()
    {
        spaceMap.selectPlanet(232);
        updateDetails();
    }
        @FXML
    void button233()
    {
        spaceMap.selectPlanet(233);
        updateDetails();
    }    
    @FXML
    void button234()
    {
        spaceMap.selectPlanet(234);
        updateDetails();
    }    
    @FXML
    void button235()
    {
        spaceMap.selectPlanet(235);
        updateDetails();
    }    
    @FXML
    void button236()
    {
        spaceMap.selectPlanet(236);
        updateDetails();
    }    
    @FXML
    void button237()
    {
        spaceMap.selectPlanet(237);
        updateDetails();
    }    
    @FXML
    void button238()
    {
        spaceMap.selectPlanet(238);
        updateDetails();
    }   
    @FXML
    void button239()
    {
        spaceMap.selectPlanet(239);
        updateDetails();
    }  
    @FXML
    void button240()
    {
        spaceMap.selectPlanet(240);
        updateDetails();
    }    
    @FXML
    void button241()
    {
        spaceMap.selectPlanet(241);
        updateDetails();
    }    
    @FXML
    void button242()
    {
        spaceMap.selectPlanet(242);
        updateDetails();
    }    
    @FXML
    void button243()
    {
        spaceMap.selectPlanet(243);
        updateDetails();
    }   
    @FXML
    void button244()
    {
        spaceMap.selectPlanet(244);
        updateDetails();
    }   
    @FXML
    void button245()
    {
        spaceMap.selectPlanet(245);
        updateDetails();
    }    
    @FXML
    void button246()
    {
        spaceMap.selectPlanet(246);
        updateDetails();
    }   
    @FXML
    void button247()
    {
        spaceMap.selectPlanet(247);
        updateDetails();
    }
        @FXML
    void button248()
    {
        spaceMap.selectPlanet(248);
        updateDetails();
    }    
    @FXML
    void button249()
    {
        spaceMap.selectPlanet(249);
        updateDetails();
    }    
    @FXML
    void button250()
    {
        spaceMap.selectPlanet(250);
        updateDetails();
    }    
    @FXML
    void button251()
    {
        spaceMap.selectPlanet(251);
        updateDetails();
    }    
    @FXML
    void button252()
    {
        spaceMap.selectPlanet(252);
        updateDetails();
    }    
    @FXML
    void button253()
    {
        spaceMap.selectPlanet(253);
        updateDetails();
    }   
    @FXML
    void button254()
    {
        spaceMap.selectPlanet(254);
        updateDetails();
    }    
    @FXML
    void button255()
    {
        spaceMap.selectPlanet(255);
        updateDetails();
    }    
    @FXML
    void button256()
    {
        spaceMap.selectPlanet(256);
        updateDetails();
    }    
    @FXML
    void button257()
    {
        spaceMap.selectPlanet(257);
        updateDetails();
    }   
    @FXML
    void button258()
    {
        spaceMap.selectPlanet(258);
        updateDetails();
    }   
    @FXML
    void button259()
    {
        spaceMap.selectPlanet(259);
        updateDetails();
    }    
    @FXML
    void button260()
    {
        spaceMap.selectPlanet(260);
        updateDetails();
    }   
    @FXML
    void button261()
    {
        spaceMap.selectPlanet(261);
        updateDetails();
    }
        @FXML
    void button262()
    {
        spaceMap.selectPlanet(262);
        updateDetails();
    }    
    @FXML
    void button263()
    {
        spaceMap.selectPlanet(263);
        updateDetails();
    }    
    @FXML
    void button264()
    {
        spaceMap.selectPlanet(264);
        updateDetails();
    }    
    @FXML
    void button265()
    {
        spaceMap.selectPlanet(265);
        updateDetails();
    }    
    @FXML
    void button266()
    {
        spaceMap.selectPlanet(266);
        updateDetails();
    }    
    @FXML
    void button267()
    {
        spaceMap.selectPlanet(267);
        updateDetails();
    }   
    @FXML
    void button268()
    {
        spaceMap.selectPlanet(268);
        updateDetails();
    }    
    @FXML
    void button269()
    {
        spaceMap.selectPlanet(269);
        updateDetails();
    }    
    @FXML
    void button270()
    {
        spaceMap.selectPlanet(270);
        updateDetails();
    }    
    @FXML
    void button271()
    {
        spaceMap.selectPlanet(271);
        updateDetails();
    }   
    @FXML
    void button272()
    {
        spaceMap.selectPlanet(272);
        updateDetails();
    }   
    @FXML
    void button273()
    {
        spaceMap.selectPlanet(273);
        updateDetails();
    }    
    @FXML
    void button274()
    {
        spaceMap.selectPlanet(274);
        updateDetails();
    }   
    @FXML
    void button275()
    {
        spaceMap.selectPlanet(275);
        updateDetails();
    }
        @FXML
    void button276()
    {
        spaceMap.selectPlanet(276);
        updateDetails();
    }    
    @FXML
    void button277()
    {
        spaceMap.selectPlanet(277);
        updateDetails();
    }    
    @FXML
    void button278()
    {
        spaceMap.selectPlanet(278);
        updateDetails();
    }    
    @FXML
    void button279()
    {
        spaceMap.selectPlanet(279);
        updateDetails();
    }    
    @FXML
    void button280()
    {
        spaceMap.selectPlanet(280);
        updateDetails();
    }    
    @FXML
    void button281()
    {
        spaceMap.selectPlanet(281);
        updateDetails();
    }   
    @FXML
    void button282()
    {
        spaceMap.selectPlanet(282);
        updateDetails();
    }    
    @FXML
    void button283()
    {
        spaceMap.selectPlanet(283);
        updateDetails();
    }    
    @FXML
    void button284()
    {
        spaceMap.selectPlanet(284);
        updateDetails();
    }    
    @FXML
    void button285()
    {
        spaceMap.selectPlanet(285);
        updateDetails();
    }   
    @FXML
    void button286()
    {
        spaceMap.selectPlanet(286);
        updateDetails();
    }   
    @FXML
    void button287()
    {
        spaceMap.selectPlanet(287);
        updateDetails();
    }    
    @FXML
    void button288()
    {
        spaceMap.selectPlanet(288);
        updateDetails();
    }   
    @FXML
    void button289()
    {
        spaceMap.selectPlanet(289);
        updateDetails();
    }
        @FXML
    void button290()
    {
        spaceMap.selectPlanet(290);
        updateDetails();
    }    
    @FXML
    void button291()
    {
        spaceMap.selectPlanet(291);
        updateDetails();
    }    
    @FXML
    void button292()
    {
        spaceMap.selectPlanet(292);
        updateDetails();
    }    
    @FXML
    void button293()
    {
        spaceMap.selectPlanet(293);
        updateDetails();
    }    
    @FXML
    void button294()
    {
        spaceMap.selectPlanet(294);
        updateDetails();
    }    
    @FXML
    void button295()
    {
        spaceMap.selectPlanet(295);
        updateDetails();
    }   
    @FXML
    void button296()
    {
        spaceMap.selectPlanet(296);
        updateDetails();
    }    
    @FXML
    void button297()
    {
        spaceMap.selectPlanet(297);
        updateDetails();
    }    
    @FXML
    void button298()
    {
        spaceMap.selectPlanet(298);
        updateDetails();
    }    
    @FXML
    void button299()
    {
        spaceMap.selectPlanet(299);
        updateDetails();
    }    
    @FXML
    void button300()
    {
        spaceMap.selectPlanet(300);
        updateDetails();
    }   
    @FXML
    void button301()
    {
        spaceMap.selectPlanet(301);
        updateDetails();
    }    
    @FXML
    void button302()
    {
        spaceMap.selectPlanet(302);
        updateDetails();
    }   
    @FXML
    void button303()
    {
        spaceMap.selectPlanet(303);
        updateDetails();
    }   
    @FXML
    void button304()
    {
        spaceMap.selectPlanet(304);
        updateDetails();
    }    
    @FXML
    void button305()
    {
        spaceMap.selectPlanet(305);
        updateDetails();
    }   
    @FXML
    void button306()
    {
        spaceMap.selectPlanet(306);
        updateDetails();
    }
    
    public int getInput()
    {
        return input;
    }
    
    void updatePlanetDescription()
    {
        planetLabel.setText(spaceMap.getPlanetDescription());
    }
    
    void updatePlayerDescription()
    {
        playerLabel.setText(spaceMap.getPlayerDescription());
    }
    
    void writeNewText(String s)
    {
        label.setText(s);
    }
    
    
    
}
