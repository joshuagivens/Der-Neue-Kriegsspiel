import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;

import java.io.InputStream;

import java.io.IOException;

import java.net.URL;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;



import javafx.scene.control.CheckBox;

import javafx.scene.image.Image;

import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
/**
 * Write a description of class BoxCanyonController here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapController
{
    /*@FXML
    private Button planetButton1;
    @FXML
    private Button planetButton2;
    @FXML
    private Button planetButton3;*/
    
    @FXML
    private Label planetLabel;
    
    @FXML
    private Label playerLabel;
    
    @FXML
    private Label label;
    
    @FXML
    private ImageView image;
    
    @FXML
    private ImageView victoryImage;
    
    private int turn = 0;
    
    private int input = 6;
    
    private int t1 = 0;
    
    private int t2 = 0;
    
    //BoxCanyonImportantStringHolder s = new BoxCanyonImportantStringHolder();
    
    private SpaceMap spaceMap = new SpaceMap();//BoxCanyon(s);
    
    private SpaceMapPlayer player;
    
    /*@FXML
    void button0()
    {
        spaceMap.selectPlanet(0);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button1()
    {
        spaceMap.selectPlanet(1);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button2()
    {
        spaceMap.selectPlanet(2);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button3()
    {
        spaceMap.selectPlanet(3);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button4()
    {
        spaceMap.selectPlanet(4);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button5()
    {
        spaceMap.selectPlanet(5);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button6()
    {
        spaceMap.selectPlanet(6);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button7()
    {
        spaceMap.selectPlanet(7);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button8()
    {
        spaceMap.selectPlanet(8);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button9()
    {
        spaceMap.selectPlanet(9);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button10()
    {
        spaceMap.selectPlanet(10);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button11()
    {
        spaceMap.selectPlanet(11);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button12()
    {
        spaceMap.selectPlanet(12);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button13()
    {
        spaceMap.selectPlanet(13);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button14()
    {
        spaceMap.selectPlanet(14);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button15()
    {
        spaceMap.selectPlanet(15);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button16()
    {
        spaceMap.selectPlanet(16);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button17()
    {
        spaceMap.selectPlanet(17);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button18()
    {
        spaceMap.selectPlanet(18);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button19()
    {
        spaceMap.selectPlanet(19);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button20()
    {
        spaceMap.selectPlanet(20);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button21()
    {
        spaceMap.selectPlanet(21);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button22()
    {
        spaceMap.selectPlanet(22);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
        @FXML
    void button23()
    {
        spaceMap.selectPlanet(23);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button24()
    {
        spaceMap.selectPlanet(24);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button25()
    {
        spaceMap.selectPlanet(25);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button26()
    {
        spaceMap.selectPlanet(26);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button27()
    {
        spaceMap.selectPlanet(27);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button28()
    {
        spaceMap.selectPlanet(28);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button29()
    {
        spaceMap.selectPlanet(29);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button30()
    {
        spaceMap.selectPlanet(30);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button31()
    {
        spaceMap.selectPlanet(31);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button32()
    {
        spaceMap.selectPlanet(32);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button33()
    {
        spaceMap.selectPlanet(33);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button34()
    {
        spaceMap.selectPlanet(34);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button35()
    {
        spaceMap.selectPlanet(35);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button36()
    {
        spaceMap.selectPlanet(36);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button37()
    {
        spaceMap.selectPlanet(37);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button38()
    {
        spaceMap.selectPlanet(38);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button39()
    {
        spaceMap.selectPlanet(39);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button40()
    {
        spaceMap.selectPlanet(40);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button41()
    {
        spaceMap.selectPlanet(41);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button42()
    {
        spaceMap.selectPlanet(42);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button43()
    {
        spaceMap.selectPlanet(43);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button44()
    {
        spaceMap.selectPlanet(44);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button45()
    {
        spaceMap.selectPlanet(45);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button46()
    {
        spaceMap.selectPlanet(46);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button47()
    {
        spaceMap.selectPlanet(47);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button48()
    {
        spaceMap.selectPlanet(48);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button49()
    {
        spaceMap.selectPlanet(49);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button50()
    {
        spaceMap.selectPlanet(50);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button51()
    {
        spaceMap.selectPlanet(51);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button52()
    {
        spaceMap.selectPlanet(52);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button53()
    {
        spaceMap.selectPlanet(53);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button54()
    {
        spaceMap.selectPlanet(54);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button55()
    {
        spaceMap.selectPlanet(55);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button56()
    {
        spaceMap.selectPlanet(56);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button57()
    {
        spaceMap.selectPlanet(57);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button58()
    {
        spaceMap.selectPlanet(58);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button59()
    {
        spaceMap.selectPlanet(59);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button60()
    {
        spaceMap.selectPlanet(60);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button61()
    {
        spaceMap.selectPlanet(61);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button62()
    {
        spaceMap.selectPlanet(62);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button63()
    {
        spaceMap.selectPlanet(63);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button64()
    {
        spaceMap.selectPlanet(64);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button65()
    {
        spaceMap.selectPlanet(65);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button66()
    {
        spaceMap.selectPlanet(66);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button67()
    {
        spaceMap.selectPlanet(67);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button68()
    {
        spaceMap.selectPlanet(68);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button69()
    {
        spaceMap.selectPlanet(69);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button70()
    {
        spaceMap.selectPlanet(70);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button71()
    {
        spaceMap.selectPlanet(71);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button72()
    {
        spaceMap.selectPlanet(72);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button73()
    {
        spaceMap.selectPlanet(73);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button74()
    {
        spaceMap.selectPlanet(74);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button75()
    {
        spaceMap.selectPlanet(75);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button76()
    {
        spaceMap.selectPlanet(76);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button77()
    {
        spaceMap.selectPlanet(77);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button78()
    {
        spaceMap.selectPlanet(78);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button79()
    {
        spaceMap.selectPlanet(79);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button80()
    {
        spaceMap.selectPlanet(80);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button81()
    {
        spaceMap.selectPlanet(81);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button82()
    {
        spaceMap.selectPlanet(82);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button83()
    {
        spaceMap.selectPlanet(83);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button84()
    {
        spaceMap.selectPlanet(84);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button85()
    {
        spaceMap.selectPlanet(85);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button86()
    {
        spaceMap.selectPlanet(86);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button87()
    {
        spaceMap.selectPlanet(87);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button88()
    {
        spaceMap.selectPlanet(88);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button89()
    {
        spaceMap.selectPlanet(89);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button90()
    {
        spaceMap.selectPlanet(90);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button91()
    {
        spaceMap.selectPlanet(91);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button92()
    {
        spaceMap.selectPlanet(92);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button93()
    {
        spaceMap.selectPlanet(93);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button94()
    {
        spaceMap.selectPlanet(94);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button95()
    {
        spaceMap.selectPlanet(95);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button96()
    {
        spaceMap.selectPlanet(96);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button97()
    {
        spaceMap.selectPlanet(97);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button98()
    {
        spaceMap.selectPlanet(98);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button99()
    {
        spaceMap.selectPlanet(99);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button100()
    {
        spaceMap.selectPlanet(100);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button101()
    {
        spaceMap.selectPlanet(101);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button102()
    {
        spaceMap.selectPlanet(102);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button103()
    {
        spaceMap.selectPlanet(103);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button104()
    {
        spaceMap.selectPlanet(104);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button105()
    {
        spaceMap.selectPlanet(105);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button106()
    {
        spaceMap.selectPlanet(106);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button107()
    {
        spaceMap.selectPlanet(107);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button108()
    {
        spaceMap.selectPlanet(108);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button109()
    {
        spaceMap.selectPlanet(109);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button110()
    {
        spaceMap.selectPlanet(110);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button111()
    {
        spaceMap.selectPlanet(111);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button112()
    {
        spaceMap.selectPlanet(112);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button113()
    {
        spaceMap.selectPlanet(113);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button114()
    {
        spaceMap.selectPlanet(114);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button115()
    {
        spaceMap.selectPlanet(115);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button116()
    {
        spaceMap.selectPlanet(116);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button117()
    {
        spaceMap.selectPlanet(117);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button118()
    {
        spaceMap.selectPlanet(118);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button119()
    {
        spaceMap.selectPlanet(119);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button120()
    {
        spaceMap.selectPlanet(120);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button121()
    {
        spaceMap.selectPlanet(121);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button122()
    {
        spaceMap.selectPlanet(122);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button123()
    {
        spaceMap.selectPlanet(123);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button124()
    {
        spaceMap.selectPlanet(124);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button125()
    {
        spaceMap.selectPlanet(125);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button126()
    {
        spaceMap.selectPlanet(126);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button127()
    {
        spaceMap.selectPlanet(127);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button128()
    {
        spaceMap.selectPlanet(128);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button129()
    {
        spaceMap.selectPlanet(129);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button130()
    {
        spaceMap.selectPlanet(130);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button131()
    {
        spaceMap.selectPlanet(131);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button132()
    {
        spaceMap.selectPlanet(132);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button133()
    {
        spaceMap.selectPlanet(133);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button134()
    {
        spaceMap.selectPlanet(134);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button135()
    {
        spaceMap.selectPlanet(135);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button136()
    {
        spaceMap.selectPlanet(136);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button137()
    {
        spaceMap.selectPlanet(137);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button138()
    {
        spaceMap.selectPlanet(138);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button139()
    {
        spaceMap.selectPlanet(139);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button140()
    {
        spaceMap.selectPlanet(140);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button141()
    {
        spaceMap.selectPlanet(141);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button142()
    {
        spaceMap.selectPlanet(142);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button143()
    {
        spaceMap.selectPlanet(143);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button144()
    {
        spaceMap.selectPlanet(144);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button145()
    {
        spaceMap.selectPlanet(145);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button146()
    {
        spaceMap.selectPlanet(146);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button147()
    {
        spaceMap.selectPlanet(147);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button148()
    {
        spaceMap.selectPlanet(148);
        updatePlanetDescription();
        updatePlayerDescription();
    }
    @FXML
    void button149()
    {
        spaceMap.selectPlanet(149);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button150()
    {
        spaceMap.selectPlanet(150);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button151()
    {
        spaceMap.selectPlanet(151);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button152()
    {
        spaceMap.selectPlanet(152);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button153()
    {
        spaceMap.selectPlanet(153);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button154()
    {
        spaceMap.selectPlanet(154);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button155()
    {
        spaceMap.selectPlanet(155);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button156()
    {
        spaceMap.selectPlanet(156);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button157()
    {
        spaceMap.selectPlanet(157);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button158()
    {
        spaceMap.selectPlanet(158);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button159()
    {
        spaceMap.selectPlanet(159);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button160()
    {
        spaceMap.selectPlanet(160);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button161()
    {
        spaceMap.selectPlanet(161);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button162()
    {
        spaceMap.selectPlanet(162);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button163()
    {
        spaceMap.selectPlanet(163);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button164()
    {
        spaceMap.selectPlanet(164);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button165()
    {
        spaceMap.selectPlanet(165);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button166()
    {
        spaceMap.selectPlanet(166);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button167()
    {
        spaceMap.selectPlanet(167);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button168()
    {
        spaceMap.selectPlanet(168);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button169()
    {
        spaceMap.selectPlanet(169);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button170()
    {
        spaceMap.selectPlanet(170);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button171()
    {
        spaceMap.selectPlanet(171);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button172()
    {
        spaceMap.selectPlanet(172);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button173()
    {
        spaceMap.selectPlanet(173);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button174()
    {
        spaceMap.selectPlanet(174);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button175()
    {
        spaceMap.selectPlanet(175);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button176()
    {
        spaceMap.selectPlanet(176);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button177()
    {
        spaceMap.selectPlanet(177);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button178()
    {
        spaceMap.selectPlanet(178);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button179()
    {
        spaceMap.selectPlanet(179);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button180()
    {
        spaceMap.selectPlanet(180);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button181()
    {
        spaceMap.selectPlanet(181);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button182()
    {
        spaceMap.selectPlanet(182);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button183()
    {
        spaceMap.selectPlanet(183);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button184()
    {
        spaceMap.selectPlanet(184);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button185()
    {
        spaceMap.selectPlanet(185);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button186()
    {
        spaceMap.selectPlanet(186);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button187()
    {
        spaceMap.selectPlanet(187);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button188()
    {
        spaceMap.selectPlanet(188);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button189()
    {
        spaceMap.selectPlanet(189);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button190()
    {
        spaceMap.selectPlanet(190);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button191()
    {
        spaceMap.selectPlanet(191);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button192()
    {
        spaceMap.selectPlanet(192);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button193()
    {
        spaceMap.selectPlanet(193);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button194()
    {
        spaceMap.selectPlanet(194);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button195()
    {
        spaceMap.selectPlanet(195);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button196()
    {
        spaceMap.selectPlanet(196);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button197()
    {
        spaceMap.selectPlanet(197);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button198()
    {
        spaceMap.selectPlanet(198);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button199()
    {
        spaceMap.selectPlanet(199);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button200()
    {
        spaceMap.selectPlanet(200);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button201()
    {
        spaceMap.selectPlanet(201);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button202()
    {
        spaceMap.selectPlanet(202);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button203()
    {
        spaceMap.selectPlanet(203);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button204()
    {
        spaceMap.selectPlanet(204);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button205()
    {
        spaceMap.selectPlanet(205);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button206()
    {
        spaceMap.selectPlanet(206);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button207()
    {
        spaceMap.selectPlanet(207);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button208()
    {
        spaceMap.selectPlanet(208);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button209()
    {
        spaceMap.selectPlanet(209);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button210()
    {
        spaceMap.selectPlanet(210);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button211()
    {
        spaceMap.selectPlanet(211);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button212()
    {
        spaceMap.selectPlanet(212);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button213()
    {
        spaceMap.selectPlanet(213);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button214()
    {
        spaceMap.selectPlanet(214);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button215()
    {
        spaceMap.selectPlanet(215);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button216()
    {
        spaceMap.selectPlanet(216);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button217()
    {
        spaceMap.selectPlanet(217);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button218()
    {
        spaceMap.selectPlanet(218);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button219()
    {
        spaceMap.selectPlanet(219);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button220()
    {
        spaceMap.selectPlanet(220);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button221()
    {
        spaceMap.selectPlanet(221);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button222()
    {
        spaceMap.selectPlanet(222);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button223()
    {
        spaceMap.selectPlanet(223);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button224()
    {
        spaceMap.selectPlanet(224);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button225()
    {
        spaceMap.selectPlanet(225);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button226()
    {
        spaceMap.selectPlanet(226);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button227()
    {
        spaceMap.selectPlanet(227);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button228()
    {
        spaceMap.selectPlanet(228);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button229()
    {
        spaceMap.selectPlanet(229);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button230()
    {
        spaceMap.selectPlanet(230);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button231()
    {
        spaceMap.selectPlanet(231);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button232()
    {
        spaceMap.selectPlanet(232);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button233()
    {
        spaceMap.selectPlanet(233);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button234()
    {
        spaceMap.selectPlanet(234);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button235()
    {
        spaceMap.selectPlanet(235);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button236()
    {
        spaceMap.selectPlanet(236);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button237()
    {
        spaceMap.selectPlanet(237);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button238()
    {
        spaceMap.selectPlanet(238);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button239()
    {
        spaceMap.selectPlanet(239);
        updatePlanetDescription();
        updatePlayerDescription();
    }  
    @FXML
    void button240()
    {
        spaceMap.selectPlanet(240);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button241()
    {
        spaceMap.selectPlanet(241);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button242()
    {
        spaceMap.selectPlanet(242);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button243()
    {
        spaceMap.selectPlanet(243);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button244()
    {
        spaceMap.selectPlanet(244);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button245()
    {
        spaceMap.selectPlanet(245);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button246()
    {
        spaceMap.selectPlanet(246);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button247()
    {
        spaceMap.selectPlanet(247);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button248()
    {
        spaceMap.selectPlanet(248);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button249()
    {
        spaceMap.selectPlanet(249);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button250()
    {
        spaceMap.selectPlanet(250);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button251()
    {
        spaceMap.selectPlanet(251);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button252()
    {
        spaceMap.selectPlanet(252);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button253()
    {
        spaceMap.selectPlanet(253);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button254()
    {
        spaceMap.selectPlanet(254);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button255()
    {
        spaceMap.selectPlanet(255);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button256()
    {
        spaceMap.selectPlanet(256);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button257()
    {
        spaceMap.selectPlanet(257);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button258()
    {
        spaceMap.selectPlanet(258);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button259()
    {
        spaceMap.selectPlanet(259);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button260()
    {
        spaceMap.selectPlanet(260);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button261()
    {
        spaceMap.selectPlanet(261);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button262()
    {
        spaceMap.selectPlanet(262);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button263()
    {
        spaceMap.selectPlanet(263);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button264()
    {
        spaceMap.selectPlanet(264);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button265()
    {
        spaceMap.selectPlanet(265);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button266()
    {
        spaceMap.selectPlanet(266);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button267()
    {
        spaceMap.selectPlanet(267);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button268()
    {
        spaceMap.selectPlanet(268);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button269()
    {
        spaceMap.selectPlanet(269);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button270()
    {
        spaceMap.selectPlanet(270);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button271()
    {
        spaceMap.selectPlanet(271);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button272()
    {
        spaceMap.selectPlanet(272);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button273()
    {
        spaceMap.selectPlanet(273);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button274()
    {
        spaceMap.selectPlanet(274);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button275()
    {
        spaceMap.selectPlanet(275);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button276()
    {
        spaceMap.selectPlanet(276);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button277()
    {
        spaceMap.selectPlanet(277);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button278()
    {
        spaceMap.selectPlanet(278);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button279()
    {
        spaceMap.selectPlanet(279);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button280()
    {
        spaceMap.selectPlanet(280);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button281()
    {
        spaceMap.selectPlanet(281);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button282()
    {
        spaceMap.selectPlanet(282);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button283()
    {
        spaceMap.selectPlanet(283);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button284()
    {
        spaceMap.selectPlanet(284);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button285()
    {
        spaceMap.selectPlanet(285);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button286()
    {
        spaceMap.selectPlanet(286);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button287()
    {
        spaceMap.selectPlanet(287);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button288()
    {
        spaceMap.selectPlanet(288);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button289()
    {
        spaceMap.selectPlanet(289);
        updatePlanetDescription();
        updatePlayerDescription();
    }
        @FXML
    void button290()
    {
        spaceMap.selectPlanet(290);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button291()
    {
        spaceMap.selectPlanet(291);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button292()
    {
        spaceMap.selectPlanet(292);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button293()
    {
        spaceMap.selectPlanet(293);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button294()
    {
        spaceMap.selectPlanet(294);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button295()
    {
        spaceMap.selectPlanet(295);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button296()
    {
        spaceMap.selectPlanet(296);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button297()
    {
        spaceMap.selectPlanet(297);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button298()
    {
        spaceMap.selectPlanet(298);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button299()
    {
        spaceMap.selectPlanet(299);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button300()
    {
        spaceMap.selectPlanet(300);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button301()
    {
        spaceMap.selectPlanet(301);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button302()
    {
        spaceMap.selectPlanet(302);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button303()
    {
        spaceMap.selectPlanet(303);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button304()
    {
        spaceMap.selectPlanet(304);
        updatePlanetDescription();
        updatePlayerDescription();
    }    
    @FXML
    void button305()
    {
        spaceMap.selectPlanet(305);
        updatePlanetDescription();
        updatePlayerDescription();
    }   
    @FXML
    void button306()
    {
        spaceMap.selectPlanet(306);
        updatePlanetDescription();
        updatePlayerDescription();
    }*/
    
    public int getInput()
    {
        return input;
    }
    
    void updatePlanetDescription()
    {
        planetLabel.setText(spaceMap.getPlanetDescription());
    }
    
    void updatePlayerDescription()
    {
        playerLabel.setText(spaceMap.getPlayerDescription());
    }
    
    void writeNewText(String s)
    {
        label.setText(s);
    }
    
    
    
}
