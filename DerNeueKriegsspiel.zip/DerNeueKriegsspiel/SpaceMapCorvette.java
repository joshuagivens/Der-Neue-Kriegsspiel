
/**
 * Write a description of class SpaceMapCorvette here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapCorvette extends SpaceMapShip
{
    //public static int moneyCost = 1000;

    /**
     * Constructor for objects of class SpaceMapCorvette
     */
    public SpaceMapCorvette()
    {     
        this.shipType = "Corvette";
        this.size = 1;
        this.carrierCapacity = 0;
        this.moneyCost = 1000;
        this.metalCost = 800;
        this.industryCost = 800;
        this.baseHealth = 40;
        this.baseAttack = 15;
        this.baseDefense = 20;       
        this.health = baseHealth;
    }

    
}
