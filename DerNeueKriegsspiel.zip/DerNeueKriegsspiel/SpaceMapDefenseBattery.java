
/**
 * Write a description of class SpaceMapDefenseBattery here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapDefenseBattery extends SpaceMapBuilding
{
    private double health;
    private int maxHealth;
    private int attack;
    
    /**
     * Constructor for objects of class SpaceMapDefenseBattery
     */
    public SpaceMapDefenseBattery()
    {
        this.maxHealth = 325;
        this.health = maxHealth;
        this.attack = 140;
        this.upkeep = 40;
    }
    
    
    public int getAttack()
    {
        return attack;
    }
    
    public void damage(double d)
    {
        health = health - d;
    }
    
    public void repair()
    {
        health = maxHealth;
    }
    
    public double[] getRepairCost()
    {
        return new double[] {0, 5000*.95*health/maxHealth, 5000*.95*health/maxHealth, 5000*1.05*health/maxHealth};
    }
    
    public double getHealth()
    {
        return health;
    }
}
