
/**
 * Write a description of class SpaceMapDefenseBattery here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapDefenseBattery extends SpaceMapBuilding
{
    private double health;
    private int maxHealth;
    private int attack;
    
    /**
     * Constructor for objects of class SpaceMapDefenseBattery
     */
    public SpaceMapDefenseBattery()
    {
        this.maxHealth = 350;
        this.health = maxHealth;
        this.attack = 150;
        this.upkeep = 50;
    }
    
    public int getAttack()
    {
        return attack;
    }
    
    public void damage(double d)
    {
        health = health - d;
    }
    
    public void repair()
    {
        health = maxHealth;
    }
    
    public double getHealth()
    {
        return health;
    }
}
