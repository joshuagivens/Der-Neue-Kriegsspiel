
/**
 * Write a description of class SpaceMapDefenseBattery here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapDefenseBattery extends SpaceMapBuilding
{
    private double health;
    private int maxHealth;
    private int attack;
    private int defense;
    
    /**
     * Constructor for objects of class SpaceMapDefenseBattery
     */
    public SpaceMapDefenseBattery()
    {
        this.maxHealth = 350;
        this.health = maxHealth;
        this.attack = 150;
        this.upkeep = 35;
        this.defense = 50;
    }
    
    
    public int getAttack()
    {
        return attack;
    }
    
    public void damage(double d)
    {
        d = d*Math.pow(.99,50);
        health = health - d;
    }
    
    public void repair()
    {
        health = maxHealth;
    }
    
    public double[] getRepairCost()
    {
        return new double[] {0, 5000*.95*health/maxHealth, 5000*.95*health/maxHealth, 5000*1.05*health/maxHealth};
    }
    
    public double getHealth()
    {
        return health;
    }
}
