
/**
 * Write a description of class SpaceMapDestroyer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapDestroyer extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapDestroyer
     */
    public SpaceMapDestroyer()
    {
        this.shipType = "Destroyer";
        this.size = 3;
        this.carrierCapacity = 2;
        this.moneyCost = 2500;
        this.metalCost = 1700;
        this.industryCost = 1700;
        this.baseHealth = 125;
        this.baseAttack = 40;
        this.baseDefense = 50;
        this.health = baseHealth;
    }

    
}
