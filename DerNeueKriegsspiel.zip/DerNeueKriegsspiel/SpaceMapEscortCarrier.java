
/**
 * Write a description of class SpaceMapEscortCarrier here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapEscortCarrier extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapEscortCarrier
     */
    public SpaceMapEscortCarrier()
    {
        this.shipType = "Escort Carrier";
        this.size = 3;
        this.carrierCapacity = 30;
        this.moneyCost = 3100;
        this.metalCost = 2500;
        this.industryCost = 2500;
        this.baseHealth = 85;
        this.baseAttack = 10;
        this.baseDefense = 30;
        this.health = baseHealth;
    }

    
    
}
