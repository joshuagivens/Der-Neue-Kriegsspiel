
/**
 * Write a description of class SpaceMapFactory here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapFactory extends SpaceMapBuilding
{
    

    /**
     * Constructor for objects of class SpaceMapFactory
     */
    public SpaceMapFactory()
    {
        
    }

    public double[] getProduction()
    {
        return new double[]{0,0,1025,0,0,0,0};
    }
}
