
/**
 * Write a description of class SpaceMapFarm here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapFarm extends SpaceMapBuilding
{
    

    /**
     * Constructor for objects of class SpaceMapFarm
     */
    public SpaceMapFarm()
    {
        
    }

    public double[] getProduction()
    {
        return new double[]{3500,0,0,0,0,0,0};
    }
}
