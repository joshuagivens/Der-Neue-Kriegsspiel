import java.util.ArrayList;
/**
 * Write a description of class SpaceMapFleet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapFleet
{
    boolean orbiting;
    public int fighters;
    ArrayList <SpaceMapShip> ships;
    
    SpaceMapShip selectedVessel;
    ArrayList <SpaceMapShip> selectedShips;
    ArrayList <SpaceMapShip> movedShips;
    SpaceMapPlanet planet;
    SpaceMapPlayer owner;
    double damage;
    
    
    /**
     * Constructor for objects of class SpaceMapFleet
     */
    public SpaceMapFleet(SpaceMapPlayer owner)
    {
        
        this.owner = owner;
        this.ships = new ArrayList <SpaceMapShip> ();
        this.movedShips = new ArrayList <SpaceMapShip> ();
        this.selectedShips = new ArrayList <SpaceMapShip> ();
        this.fighters = 0;
        this.orbiting = true;
        
    }
    
    public void setLocation(SpaceMapPlanet p)
    {
        planet = p;
    }
    
    public SpaceMapShip getSelected()
    {
        return selectedVessel;
    }
    
    public void resetDamage()
    {
        damage = 0;
    }
    
    public void setPlanet(SpaceMapPlanet p)
    {
        planet = p;
    }
    
    public void setOwner(SpaceMapPlayer o)
    {
        owner = o;
    }

    public SpaceMapPlayer getOwner()
    {
        return owner;
    }
    
    public void addCorvette()
    {
        ships.add(new SpaceMapCorvette());
    }
    
    public void addFrigate()
    {
        ships.add(new SpaceMapFrigate());
    }
    
    public void addDestroyer()
    {
        ships.add(new SpaceMapDestroyer());
    }
    
    public void addLightCruiser()
    {
        ships.add(new SpaceMapLightCruiser());
    }
    
    public void addMediumCruiser()
    {
        ships.add(new SpaceMapMediumCruiser());
    }
    
    public void addHeavyCruiser()
    {
        ships.add(new SpaceMapHeavyCruiser());
    }
    
    public void addBattlecruiser()
    {
        ships.add(new SpaceMapBattlecruiser());
    }
    
    public void addBattleship()
    {
        ships.add(new SpaceMapBattleship());
    }
    
    public void addHeavyBattleship()
    {
        ships.add(new SpaceMapHeavyBattleship());
    }
    
    public void addEscortCarrier()
    {
        ships.add(new SpaceMapEscortCarrier());
    }
    
    public void addLightCarrier()
    {
        ships.add(new SpaceMapLightCarrier());
    }
    
    public void addMediumCarrier()
    {
        ships.add(new SpaceMapMediumCarrier());
    }
    
    public void addHeavyCarrier()
    {
        ships.add(new SpaceMapHeavyCarrier());
    }
    
    public void addLightCapitalShip()
    {
        ships.add(new SpaceMapLightCapitolShip());
    }
    
    public void addMediumCapitalShip()
    {
        ships.add(new SpaceMapMediumCapitolShip());
    }
    
    public void addHeavyCapitalShip()
    {
        ships.add(new SpaceMapHeavyCapitolShip());
    }
    
    public void addSectorDominanceShip()
    {
        ships.add(new SpaceMapSectorDominanceShip());
    }
    
    public void addShip(SpaceMapShip s)
    {
        ships.add(s);
    }
    
    public void upgradeUranium()
    {
        if(selectedVessel != null)
        {
            if(!selectedVessel.checkUpgrades()[2])
            {
                if(selectedVessel.getUpgradeCosts()[2] <= owner.getUranium())
                {
                    owner.spendRares(new double[] {selectedVessel.getUpgradeCosts()[2],0,0});
                    selectedVessel.upgradeUranium();
                }
            }
        }
    }
    
    public void repair()
    {
        for(short i = 0; i < ships.size(); i++)
        {
            ships.get(i).repair();
            ships.get(i).addFighters(ships.get(i).getOpenCarrierSpace());
        }
        
    }
    
    public void autoUpgrade()
    {
        for(short i = 0; i < ships.size();i++)
        {
            if(!ships.get(i).checkUpgrades()[0])
            {
                if(ships.get(i).getUpgradeCosts()[0] <= owner.getTitanium())
                {
                    owner.spendRares(new double[] {0,ships.get(i).getUpgradeCosts()[0], 0});
                    ships.get(i).upgradeTitanium();
                }
            }
            if(!ships.get(i).checkUpgrades()[1])
            {
                if(ships.get(i).getUpgradeCosts()[1] <= owner.getPromethium())
                {
                    owner.spendRares(new double[] {0,0,ships.get(i).getUpgradeCosts()[1]});
                    ships.get(i).upgradePromethium();
                }
            }
            if(!ships.get(i).checkUpgrades()[2])
            {
                if(ships.get(i).getUpgradeCosts()[2] <= owner.getUranium())
                {
                    owner.spendRares(new double[] {ships.get(i).getUpgradeCosts()[2],0,0});
                    ships.get(i).upgradeUranium();
                }
            }
        }
        for(short i = 0; i < selectedShips.size();i++)
        {
            if(!selectedShips.get(i).checkUpgrades()[0])
            {
                if(selectedShips.get(i).getUpgradeCosts()[0] <= owner.getTitanium())
                {
                    owner.spendRares(new double[] {0,selectedShips.get(i).getUpgradeCosts()[0], 0});
                    selectedShips.get(i).upgradeTitanium();
                }
            }
            if(!selectedShips.get(i).checkUpgrades()[1])
            {
                if(selectedShips.get(i).getUpgradeCosts()[1] <= owner.getPromethium())
                {
                    owner.spendRares(new double[] {0,0,selectedShips.get(i).getUpgradeCosts()[1]});
                    selectedShips.get(i).upgradePromethium();
                }
            }
            if(!selectedShips.get(i).checkUpgrades()[2])
            {
                if(selectedShips.get(i).getUpgradeCosts()[2] <= owner.getUranium())
                {
                    owner.spendRares(new double[] {selectedShips.get(i).getUpgradeCosts()[2],0,0});
                    selectedShips.get(i).upgradeUranium();
                }
            }
        }
    }
    
    public void upgradeTitanium()
    {
        if(selectedVessel != null)
        {
            if(!selectedVessel.checkUpgrades()[0])
            {
                if(selectedVessel.getUpgradeCosts()[0] <= owner.getTitanium())
                {
                    owner.spendRares(new double[] {0,selectedVessel.getUpgradeCosts()[0], 0});
                    selectedVessel.upgradeTitanium();
                }
            }
        }
    }
    
    public void upgradePromethium()
    {
        if(selectedVessel != null)
        {
            if(!selectedVessel.checkUpgrades()[1])
            {
                if(selectedVessel.getUpgradeCosts()[1] <= owner.getPromethium())
                {
                    owner.spendRares(new double[] {0,0,selectedVessel.getUpgradeCosts()[1]});
                    selectedVessel.upgradePromethium();
                }
            }
        }
    }
    
    public double[] getCost()
    {
        double[] cost = new double[4];
        /*for(int i = 0; i <  corvettes.size(); i++)
        {
            cost = cost + corvettes.get(i).getUpkeep();
        }*/
        for(int i = 0; i < ships.size(); i++)
        {
            for(int j = 0; j < 4;j++)
            {
                cost[j] = cost[j] + ships.get(i).getUpkeepTotal()[j];
            }
        }
        ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
        if(planet.getOwner().getName().equals(owner.getName()))
        {
            defenseBattery = planet.getDefenseBattery();
        }
        for(int i = 0; i < defenseBattery.size(); i++)
        {
            for(int j = 0; j < 4;j++)
            {
                cost[j] = cost[j] + defenseBattery.get(i).getRepairCost()[j];
            }
        }
        ArrayList <SpaceMapHangar> hangar = new ArrayList <SpaceMapHangar> ();
        if(planet.getOwner().getName().equals(owner.getName()))
        {
            hangar = planet.getHangar();
        }
        for(int i = 0; i < hangar.size(); i++)
        {
            for(int j = 0; j < 4;j++)
            {
                cost[j] = cost[j] + hangar.get(i).getRepairCost()[j];
            }
        }
        return cost;
    }
    
    public int fleetSize()
    {
        ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
        if (orbiting)
        {   
            if(planet.getOwner().getName().equals(owner.getName()))
            {
                defenseBattery = planet.getDefenseBattery();
            }
        }
        deployFighters();
        
        
        int fleetSize = (fighters/2) + (fighters%2) + (defenseBattery.size()*6);
        for(int i = 0; i < ships.size();i++)
        {
            fleetSize = fleetSize + ships.get(i).size();
        }
        for(int i = 0; i < selectedShips.size();i++)
        {
            fleetSize = fleetSize + selectedShips.get(i).size();
        }
        reintegrateFighters();
        return fleetSize;
    }
    
    public void reintegrateFighters()
    {
        for(int i = 0; i <  selectedShips.size(); i++)
        {
            if (fighters > selectedShips.get(i).getOpenCarrierSpace())
            {
                fighters = fighters - ships.get(i).getOpenCarrierSpace();
                ships.get(i).addFighters(ships.get(i).getOpenCarrierSpace());
            }
            else if(fighters > 0)
            {
                ships.get(i).addFighters((short)fighters);
                fighters = 0;             
            }
        }
        for(int i = 0; i <  ships.size(); i++)
        {
            if (fighters > ships.get(i).getOpenCarrierSpace())
            {
                fighters = fighters - ships.get(i).getOpenCarrierSpace();
                ships.get(i).addFighters(ships.get(i).getOpenCarrierSpace());
            }
            else if(fighters > 0)
            {
                ships.get(i).addFighters((short)fighters);
                fighters = 0;             
            }
        }       
        ArrayList <SpaceMapHangar> hangar = new ArrayList <SpaceMapHangar> ();
        if(planet.getOwner().getName().equals(owner.getName()))
        {
            hangar = planet.getHangar();
        }
        for(int i = 0; i <  hangar.size(); i++)
        {
            if (fighters > hangar.get(i).getOpenCarrierSpace())
            {
                fighters = fighters - hangar.get(i).getOpenCarrierSpace();
                hangar.get(i).addFighters(hangar.get(i).getOpenCarrierSpace());
            }
            else if(fighters > 0)
            {
                hangar.get(i).addFighters((short)fighters);
                fighters = 0;             
            }
        }
        fighters = 0;
    }
    
    public void selectAll()
    {
        while(ships.size() > 0)
        {
            selectedShips.add(ships.remove(0));
        }
    }
    
    public void cancel()
    {
        selectedVessel = null;
        for(int i = selectedShips.size()-1; i >= 0;i--)
        {
            addShip(selectedShips.remove(i));
        }
    }
    
    public String listFleet()
    {
        String theString = "The ships are:\n";
        for (short i = 0; i < ships.size(); i++)
        {
            theString = theString + "At index " + i + " we have a " + ships.get(i).getType()+ "\n";
        }
        theString = theString + "The selected ships are:\n";
        for(short i = 0; i < selectedShips.size(); i++)
        {
            theString = theString + "At index " + (i+ships.size()) + " we have a " +  selectedShips.get(i).getType()+ "\n";
        }
        return theString;
    }
         
    public void deployFighters()
    {
        
        for(int i = 0; i <  ships.size(); i++)
        {
            fighters = fighters + ships.get(i).deployFighters();
        } 
        ArrayList <SpaceMapHangar> hangar = new ArrayList <SpaceMapHangar> ();
        if(planet.getOwner().getName().equals(owner.getName()))
        {
            hangar = planet.getHangar();
        }
        for(int i = 0; i <  hangar.size(); i++)
        {
            fighters = fighters + hangar.get(i).deployFighters();
        }
    }
    
    public double openFire()
    {
        double power = 0;
        
        for(int i = 0; i <  ships.size(); i++)
        {
            power = power + ships.get(i).getAttack();
        }
            ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
            if(planet.getOwner().getName().equals(owner.getName()))
            {
                defenseBattery = planet.getDefenseBattery();
            }
            for(int i = 0; i <  defenseBattery.size(); i++)
            {             
                power = power + defenseBattery.get(i).getAttack();
            }
        
        deployFighters();       
        power = power + fighters*3;           
        power = power*Math.pow(1.05,owner.getAttackTech());
        if (owner.getGov() == 6)
        {
           power = power*1.05;
        }
        if (owner.getForGov() == 1)
        {
            power = power*1.05;
        }
        if (owner.getCulture() == 2)
        {
            power = power*1.05;
        }
        else if (owner.getCulture() == 4)
        {
            power = power*.95;
        }
        power = power*(1+owner.getBonuses()[5]);
        if (owner instanceof SpaceMapAIPlayer)
        {
            power = power*((SpaceMapAIPlayer)(owner)).getDifficultyEffect();
        }
        reintegrateFighters();
        return power;
    }
    
    public void damageFleet(double damage)
    {
        if (owner.getGov() == 6)
        {
           damage = damage*.95;
        }
        if (owner.getForGov() == 1)
        {
            damage = damage*.95;
        }
        if (owner.getCulture() == 2)
        {
            damage = damage*.95;
        }
        else if (owner.getCulture() == 4)
        {
            damage = damage*1.05;
        }
        
        if (owner instanceof SpaceMapAIPlayer)
        {
            damage = damage/((SpaceMapAIPlayer)(owner)).getDifficultyEffect();
        }
        
        damage = damage*Math.pow(.95,owner.getDefenseTech());
        damage = damage*(1-owner.getBonuses()[6]);
        ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
        if(planet.getOwner().getName().equals(owner.getName()))
        {
            defenseBattery = planet.getDefenseBattery();
        }
        
        /*int fleetSize = corvettes.size() + frigates.size() + destroyers.size()  + lightCruisers.size()  + mediumCruisers .size() + heavyCruisers.size() + battlecruisers.size() + battleships.size() +
        heavyBattleships.size() + escortCarriers.size() + lightCarriers.size() + mediumCarriers.size() + heavyCarriers.size() + lightCapitolShips.size() + mediumCapitolShips.size() +
        heavyCapitolShips.size() + sectorDominanceShips.size() + defenseBattery.size();*/
        int fleetCount = ships.size() + defenseBattery.size();
        int fleetSize = fleetSize();
        deployFighters();
        int fighterCount = fighters;
        for (int i = 0; i < fighterCount;i++)
        {
            if(Math.random() > .9 && damage > 1)
            {              
                fighters--;
                damage--;
            }
        }
        double[] damSpread = new double[fleetCount]; 
        double h;        
        double ran = 0;
        for (int i = 0; i < ships.size(); i++)
        {
            h = Math.random();
            damSpread[i] = h*ships.get(i).size() + ships.get(i).size() + .5;
            ran = ran + h*ships.get(i).size() + ships.get(i).size() + .5;
        }
        for (int i = /*ships.size()*/0; i < /*ships.size()+*/defenseBattery.size();i++)
        {
            h = Math.random();
            damSpread[i+ships.size()] = h*6 + 6 + .5;
            ran = ran + h*6 + 6 + .5;
        }
        for(int i = 0; i < ships.size(); i++)
        {
            ships.get(i).damage(damSpread[i]*damage/ran);
        }
        for(int i = 0; i < defenseBattery.size(); i++)
        {
            defenseBattery.get(i).damage(damSpread[i+ships.size()]*damage/ran);
        }
        boolean[] removeShips = new boolean[ships.size()];       
        for(int i = 0; i < ships.size(); i++)
        {
            if (ships.get(i).getHealth() < 0)
            {
                removeShips[i] = true;
            }
            else
            {
                removeShips[i] = false;
            }
        }
        for (int i = ships.size()-1; i >= 0; i--)
        {
            if(removeShips[i])
            {
                ships.remove(i);
            }
        }
        planet.checkDefenseBattery();
        reintegrateFighters();
    }
    
    public double getUpkeep()
    {
        double cost = 0;
        
        for (int i = 0; i < ships.size();i++)
        {
            cost = cost + ships.get(i).getUpkeep();
        }
        return cost;
    }
    
    public void selectShip(int i)
    {
        
        
        if(ships.size() > i)
        {
            selectedVessel = ships.get(i);
            selectedShips.add(ships.remove(i));
        }    
        else if(ships.size() + selectedShips.size() > i)
        {
            selectedVessel = selectedShips.get(i-ships.size());            
        }
        
    }
    
    public void reintegrateShips()
    {
        for(int i = movedShips.size()-1; i >= 0; i--)
        {
            ships.add(movedShips.remove(i));
        }
        for(int i = selectedShips.size()-1; i >= 0; i--)
        {
            ships.add(selectedShips.remove(i));
        }
    }
    
    public void moveShip(SpaceMapPlanet planet)
    {
        /*int index = -1;
        for (int i = 0; i < ships.size(); i++)
        {
            if (selectedVessel == ships.get(i))
            {
                index = i;
            }
        }
        if(index != -1)
        {
            planet.getFleet(owner).addShip(ships.remove(index));
        }*/
        reintegrateFighters();
        for(int i = selectedShips.size()-1; i >= 0;i--)
        {
            planet.getFleet(owner).addShip(selectedShips.remove(i));
        }
        
    }
}
