import java.util.ArrayList;
/**
 * Write a description of class SpaceMapFleet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapFleet
{
    boolean orbiting;
    public int fighters;
    ArrayList <SpaceMapCorvette> corvettes;
    ArrayList <SpaceMapFrigate> frigates;
    ArrayList <SpaceMapDestroyer> destroyers;
    ArrayList <SpaceMapLightCruiser> lightCruisers;
    ArrayList <SpaceMapMediumCruiser> mediumCruisers;
    ArrayList <SpaceMapHeavyCruiser> heavyCruisers;
    ArrayList <SpaceMapBattlecruiser> battlecruisers;
    ArrayList <SpaceMapBattleship> battleships;
    ArrayList <SpaceMapHeavyBattleship> heavyBattleships;
    ArrayList <SpaceMapEscortCarrier> escortCarriers;
    ArrayList <SpaceMapLightCarrier> lightCarriers;
    ArrayList <SpaceMapMediumCarrier> mediumCarriers;
    ArrayList <SpaceMapHeavyCarrier> heavyCarriers;
    ArrayList <SpaceMapLightCapitolShip> lightCapitolShips;
    ArrayList <SpaceMapMediumCapitolShip> mediumCapitolShips;
    ArrayList <SpaceMapHeavyCapitolShip> heavyCapitolShips;
    ArrayList <SpaceMapSectorDominanceShip> sectorDominanceShips;
    SpaceMapPlanet planet;
    SpaceMapPlayer owner;
    int damageHolder;
    double damage;
    
    
    /**
     * Constructor for objects of class SpaceMapFleet
     */
    public SpaceMapFleet()
    {
        
        this.fighters = 0;
        this.orbiting = true;
    }
    
    public void resetDamage()
    {
        damageHolder = 0;
        damage = 0;
    }
    
    public void setPlanet(SpaceMapPlanet p)
    {
        planet = p;
    }
    
    public void setOwner(SpaceMapPlayer o)
    {
        owner = o;
    }

    public SpaceMapPlayer getOwner()
    {
        return owner;
    }
    
    public double getCost()
    {
        double cost = 0;
        for(int i = 0; i <  corvettes.size(); i++)
        {
            cost = cost + corvettes.get(i).getUpkeep();
        }
        return cost;
    }
    
    public int fleetSize()
    {
        ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
        if (orbiting)
        {   
            if(planet.getOwner().getName().equals(owner.getName()))
            {
                defenseBattery = planet.getDefenseBattery();
            }
        }
        deployFighters();
        int fleetSize = corvettes.size() + frigates.size() + destroyers.size()  + lightCruisers.size()  + mediumCruisers .size() + heavyCruisers.size() + battlecruisers.size() + battleships.size() +
        heavyBattleships.size() + escortCarriers.size() + lightCarriers.size() + mediumCarriers.size() + heavyCarriers.size() + lightCapitolShips.size() + mediumCapitolShips.size() +
        heavyCapitolShips.size() + sectorDominanceShips.size() + defenseBattery.size();
        return fleetSize;
    }
         
    public void deployFighters()
    {
        for(int i = 0; i <  corvettes.size(); i++)
        {
            fighters = fighters + corvettes.get(i).deployFighters();
        }
        for(int i = 0; i <  frigates.size(); i++)
        {
            fighters = fighters + frigates.get(i).deployFighters();
        }
        for(int i = 0; i <  destroyers.size(); i++)
        {
            fighters = fighters + destroyers.get(i).deployFighters();
        }
        for(int i = 0; i <  lightCruisers.size(); i++)
        {
            fighters = fighters + lightCruisers.get(i).deployFighters();
        }
        for(int i = 0; i <  mediumCruisers.size(); i++)
        {
            fighters = fighters + mediumCruisers.get(i).deployFighters();
        }
        for(int i = 0; i <  heavyCruisers.size(); i++)
        {
            fighters = fighters + heavyCruisers.get(i).deployFighters();
        }
        for(int i = 0; i <  battlecruisers.size(); i++)
        {
            fighters = fighters + battlecruisers.get(i).deployFighters();
        }
        for(int i = 0; i <  battleships.size(); i++)
        {
            fighters = fighters + battleships.get(i).deployFighters();
        }
        for(int i = 0; i <  heavyBattleships.size(); i++)
        {
            fighters = fighters + heavyBattleships.get(i).deployFighters();
        }
        for(int i = 0; i <  escortCarriers.size(); i++)
        {
            fighters = fighters + escortCarriers.get(i).deployFighters();
        }
        for(int i = 0; i <  lightCarriers.size(); i++)
        {
            fighters = fighters + lightCarriers.get(i).deployFighters();
        }
        for(int i = 0; i <  mediumCarriers.size(); i++)
        {
            fighters = fighters + mediumCarriers.get(i).deployFighters();
        }
        for(int i = 0; i <  heavyCarriers.size(); i++)
        {
            fighters = fighters + heavyCarriers.get(i).deployFighters();
        }
        for(int i = 0; i <  lightCapitolShips.size(); i++)
        {
            fighters = fighters + lightCapitolShips.get(i).deployFighters();
        }
        for(int i = 0; i <  mediumCapitolShips.size(); i++)
        {
            fighters = fighters + mediumCapitolShips.get(i).deployFighters();
        }
        for(int i = 0; i <  heavyCapitolShips.size(); i++)
        {
            fighters = fighters + heavyCapitolShips.get(i).deployFighters();
        }
        for(int i = 0; i <  sectorDominanceShips.size(); i++)
        {
            fighters = fighters + sectorDominanceShips.get(i).deployFighters();
        }
        ArrayList <SpaceMapHangar> hangar = new ArrayList <SpaceMapHangar> ();
        if(planet.getOwner().getName().equals(owner.getName()))
        {
            hangar = planet.getHangar();
        }
        for(int i = 0; i <  hangar.size(); i++)
        {
            fighters = fighters + hangar.get(i).deployFighters();
        }
    }
    
    public double openFire()
    {
        double power = 0;
        for(int i = 0; i <  corvettes.size(); i++)
        {
            power = power + corvettes.get(i).getAttack();
        }
        for(int i = 0; i <  frigates.size(); i++)
        {
            power = power + frigates.get(i).getAttack();
        }
        for(int i = 0; i <  destroyers.size(); i++)
        {
            power = power + destroyers.get(i).getAttack();
        }
        for(int i = 0; i <  lightCruisers.size(); i++)
        {
            power = power + lightCruisers.get(i).getAttack();
        }
        for(int i = 0; i <  mediumCruisers.size(); i++)
        {
            power = power + mediumCruisers.get(i).getAttack();
        }
        for(int i = 0; i <  heavyCruisers.size(); i++)
        {
            power = power + heavyCruisers.get(i).getAttack();
        }
        for(int i = 0; i <  battlecruisers.size(); i++)
        {
            power = power + battlecruisers.get(i).getAttack();
        }
        for(int i = 0; i <  battleships.size(); i++)
        {
            power = power + battleships.get(i).getAttack();
        }
        for(int i = 0; i <  heavyBattleships.size(); i++)
        {
            power = power + heavyBattleships.get(i).getAttack();
        }
        for(int i = 0; i <  escortCarriers.size(); i++)
        {
            power = power + escortCarriers.get(i).getAttack();
        }
        for(int i = 0; i <  lightCarriers.size(); i++)
        {
            power = power + lightCarriers.get(i).getAttack();
        }
        for(int i = 0; i <  mediumCarriers.size(); i++)
        {
            power = power + mediumCarriers.get(i).getAttack();
        }       
        for(int i = 0; i <  heavyCarriers.size(); i++)
        {
            power = power + heavyCarriers.get(i).getAttack();
        }
        for(int i = 0; i <  lightCapitolShips.size(); i++)
        {
            power = power + lightCapitolShips.get(i).getAttack();
        }
        for(int i = 0; i <  mediumCapitolShips.size(); i++)
        {
            power = power + mediumCapitolShips.get(i).getAttack();
        }
        for(int i = 0; i <  heavyCapitolShips.size(); i++)
        {
            power = power + heavyCapitolShips.get(i).getAttack();
        }
        for(int i = 0; i <  sectorDominanceShips.size(); i++)
        {
            power = power + sectorDominanceShips.get(i).getAttack();
        }
        if (orbiting)
        {
            ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
            if(planet.getOwner().getName().equals(owner.getName()))
            {
                defenseBattery = planet.getDefenseBattery();
            }
            for(int i = 0; i <  defenseBattery.size(); i++)
            {             
                power = power + defenseBattery.get(i).getAttack();
            }
        }
        deployFighters();       
        power = power + fighters*3;           
        power = power*Math.pow(1.1,owner.getAttackTech());
        if (owner.getGov() == 6)
        {
           power = power*1.05;
        }
        if (owner.getForGov() == 1)
        {
            power = power*1.05;
        }
        if (owner.getCulture() == 2)
        {
            power = power*1.05;
        }
        else if (owner.getCulture() == 4)
        {
            power = power*.95;
        }
        return power;
    }
    
    public void damageFleet(double damage)
    {
        if (owner.getGov() == 6)
        {
           damage = damage*.95;
        }
        if (owner.getForGov() == 1)
        {
            damage = damage*.95;
        }
        if (owner.getCulture() == 2)
        {
            damage = damage*.95;
        }
        else if (owner.getCulture() == 4)
        {
            damage = damage*1.05;
        }
        ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
        if(planet.getOwner().getName().equals(owner.getName()))
        {
            defenseBattery = planet.getDefenseBattery();
        }
        deployFighters();
        int fleetSize = corvettes.size() + frigates.size() + destroyers.size()  + lightCruisers.size()  + mediumCruisers .size() + heavyCruisers.size() + battlecruisers.size() + battleships.size() +
        heavyBattleships.size() + escortCarriers.size() + lightCarriers.size() + mediumCarriers.size() + heavyCarriers.size() + lightCapitolShips.size() + mediumCapitolShips.size() +
        heavyCapitolShips.size() + sectorDominanceShips.size() + defenseBattery.size();
        int fighterCount = fighters;
        for (int i = 0; i < fighterCount;i++)
        {
            if(Math.random() > .1 && damage > 1)
            {              
                fighters--;
                damage--;
            }
        }
        double[] damSpread = new double[fleetSize]; 
        double h;        
        double ran = 0;
        int c = corvettes.size();
        int f = c + frigates.size();
        
        for (int i = 0; i < c;i++)
        {
            h = Math.random();                    
            damSpread[i] = (h*.9);
            ran = ran +(h*.9);         
        } 
        for (int i = corvettes.size(); i < f;i++)
        {
            h = Math.random();                    
            damSpread[i] = (h*.91);
            ran = ran + (h*.91);         
        }
        for (int i = corvettes.size() + frigates.size(); i < corvettes.size() + frigates.size() + destroyers.size();i++)
        {
            h = Math.random();                    
            damSpread[i] = (h*.91);
            ran = ran + (h*.91);         
        }
        for (int i = corvettes.size() + frigates.size() + destroyers.size(); i < corvettes.size() + frigates.size() + destroyers.size() + lightCruisers.size();i++)
        {
            h = Math.random();                    
            damSpread[i] = (h*.91);
            ran = ran + (h*.91);         
        }
        for (int i = corvettes.size() + frigates.size() + destroyers.size() + lightCruisers.size(); i < corvettes.size() + frigates.size() + destroyers.size() + lightCruisers.size() + mediumCruisers.size();i++)
        {
            h = Math.random();                    
            damSpread[i] = (h*.91);
            ran = ran + (h*.91);         
        }
                
        for(int i = 0; i < corvettes.size();i++)
        {           
            corvettes.get(i).damage(damSpread[i]*damage/ran);
        }
        for(int i = corvettes.size(); i < corvettes.size() + frigates.size();i++)
        {           
            frigates.get(i).damage(damSpread[i]*damage/ran);
        }
        for(int i = corvettes.size() + frigates.size(); i < corvettes.size() + frigates.size() + destroyers.size();i++)
        {           
            frigates.get(i).damage(damSpread[i]*damage/ran);
        }
        
        double excessDamage = 0;
        for(int i = 0; i < corvettes.size();i++)
        {           
            if (corvettes.get(i).getHealth() < 0)
            {
                excessDamage = excessDamage + corvettes.get(i).getHealth();
            }
        }
        for(int i = 0; i < frigates.size();i++)
        {           
            if (frigates.get(i).getHealth() < 0)
            {
                excessDamage = excessDamage + frigates.get(i).getHealth();
            }
        }
        int newFighterCount = fighters;
        for (int i = 0; i < newFighterCount;i++)
        {
            if(excessDamage > 1 && fighters > 0)
            {              
                fighters--;
                damage--;
            }
        } 
    }
    
    public double getUpkeep()
    {
        double cost = 0;
        for (int i = 0; i < corvettes.size();i++)
        {
            cost = cost + corvettes.get(i).getUpkeep();
        }
        for (int i = 0; i < frigates.size();i++)
        {
            cost = cost + frigates.get(i).getUpkeep();
        }
        for (int i = 0; i < destroyers.size();i++)
        {
            cost = cost + destroyers.get(i).getUpkeep();
        }
        for (int i = 0; i < lightCruisers.size();i++)
        {
            cost = cost + lightCruisers.get(i).getUpkeep();
        }
        for (int i = 0; i < mediumCruisers.size();i++)
        {
            cost = cost + mediumCruisers.get(i).getUpkeep();
        }
        for (int i = 0; i < heavyCruisers.size();i++)
        {
            cost = cost + heavyCruisers.get(i).getUpkeep();
        }
        for (int i = 0; i < battlecruisers.size();i++)
        {
            cost = cost + battlecruisers.get(i).getUpkeep();
        }
        for (int i = 0; i < battleships.size();i++)
        {
            cost = cost + battleships.get(i).getUpkeep();
        }
        for (int i = 0; i < heavyBattleships.size();i++)
        {
            cost = cost + heavyBattleships.get(i).getUpkeep();
        }
        for (int i = 0; i < escortCarriers.size();i++)
        {
            cost = cost + escortCarriers.get(i).getUpkeep();
        }
        for (int i = 0; i < lightCarriers.size();i++)
        {
            cost = cost + lightCarriers.get(i).getUpkeep();
        }
        for (int i = 0; i < mediumCarriers.size();i++)
        {
            cost = cost + mediumCarriers.get(i).getUpkeep();
        }
        for (int i = 0; i < heavyCarriers.size();i++)
        {
            cost = cost + heavyCarriers.get(i).getUpkeep();
        }
        for (int i = 0; i < lightCapitolShips.size();i++)
        {
            cost = cost + lightCapitolShips.get(i).getUpkeep();
        }
        for (int i = 0; i < mediumCapitolShips.size();i++)
        {
            cost = cost + mediumCapitolShips.get(i).getUpkeep();
        }
        for (int i = 0; i < heavyCapitolShips.size();i++)
        {
            cost = cost + heavyCapitolShips.get(i).getUpkeep();
        }
        for (int i = 0; i < sectorDominanceShips.size();i++)
        {
            cost = cost + sectorDominanceShips.get(i).getUpkeep();
        }
        return cost;
    }
    
    /*public SpaceMapShip selectShip()
    {
        
    }*/
}
