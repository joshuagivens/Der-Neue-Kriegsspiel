
/**
 * Write a description of class SpaceMapFrigate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapFrigate extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapFrigate
     */
    public SpaceMapFrigate()
    {
        this.shipType = "Frigate";
        this.size = 2;
        this.carrierCapacity = 0;
        this.moneyCost = 1300;
        this.metalCost = 1000;
        this.industryCost = 1000;
        this.baseHealth = 75;
        this.baseAttack = 25;
        this.baseDefense = 30;
        this.health = baseHealth;
    }

    
}
