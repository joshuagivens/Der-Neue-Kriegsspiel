import java.util.ArrayList;
/**
 * Write a description of class FunStringGenerator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapFunStringGenerator
{
    SpaceMapPlayer owner;
    String battleReport;
    ArrayList <String> names;
    /**
     * Constructor for objects of class FunStringGenerator
     */
    public SpaceMapFunStringGenerator()
    {
        this.names = new ArrayList <String> ();
        names.add("Joseph Stalin");
        names.add("Taylor Swift");
        names.add("Helena of Troy");
        names.add("George Washington");
        names.add("Mr. Schreiber");
        names.add("Larry the Cucumber");
        names.add("Donald Trump");
        names.add("Neville Chamberlain");
        names.add("Julius Caesar");
        names.add("Lawrence of Arabia");
        names.add("Joan of Arc");
        names.add("Captian Picard");
        names.add("Bob the Tomato");
        names.add("King Solomon");
        names.add("Luke Skywalker");
        names.add("Mahatma Gandhi");
        names.add("Abraham Lincoln");
        names.add("Claus von Stauffenberg");
        names.add("Sun Tzu");
        names.add("Benjamin Franklin");
        names.add("Nelson Mandela");
        names.add("Leonardo da Vinci");
        names.add("Harrison Ford");
        names.add("Mr. T");
        names.add("K.I.T.T.");
        names.add("Genghis Khan");
        names.add("Montezuma");
        names.add("Arnold Schwarzenegger");
        names.add("Queen Isabela");
        names.add("President Snow");
        names.add("Gandalf the Grey");
        names.add("Louix the Fourteenth");
        names.add("Giuseppe Garibaldi");
        names.add("William of Orange");
        names.add("Mr. Potatohead");
        names.add("Karl Marx");
        names.add("Steve Jobs");
        names.add("Kermit the Frog");
        names.add("Jar Jar Binks");
        names.add("Wesley Crusher");
        names.add("Master Chief");
        names.add("John Wayne");
        names.add("Edward Snowden");
        names.add("Alexander the Great");
        names.add("Archduke Franz Ferdinand");
        names.add("Thor");
        names.add("Joshua Givens");
        names.add("Jack Givens");
    }

    public void preBattleReport()
    {
        
    }
    
    public String getTheRandomAction(String factionName, String[] locations, boolean[] victory)
    {
        ArrayList <String> actionDescriptions = new ArrayList <String> ();
        actionDescriptions.add(" was watching Netflix, ");
        actionDescriptions.add(" was taking a nap, ");
        actionDescriptions.add(" was playing Minecraft, ");
        actionDescriptions.add(" was daydreaming, ");
        actionDescriptions.add(" was feeding a cat, ");
        actionDescriptions.add(" was doing physics homework, ");
        actionDescriptions.add(" was , ");
        
        return "While " + names.get((int)(Math.random()*names.size())) + ", commander of all military forces of " + factionName + actionDescriptions.get((int)(Math.random()*actionDescriptions.size()));
    }
}
