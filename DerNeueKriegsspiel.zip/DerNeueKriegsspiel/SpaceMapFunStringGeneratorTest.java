

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SpaceMapFunStringGeneratorTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SpaceMapFunStringGeneratorTest
{
    /**
     * Default constructor for test class SpaceMapFunStringGeneratorTest
     */
    public SpaceMapFunStringGeneratorTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    @Test
    public void testDet()
    {
        SpaceMapFunStringGenerator a = new SpaceMapFunStringGenerator();
        String[] funArray = new String[25];
        for (int i = 0; i < funArray.length; i++)
        {
            funArray[i] = a.getTheRandomAction();
        } 
        String puppy = "";
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
