
/**
 * Write a description of class SpaceMapHangar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapHangar extends SpaceMapBuilding
{
    private short fighters;
    private short fighterCapacity;
    /**
     * Constructor for objects of class SpaceMapHangar
     */
    public SpaceMapHangar()
    {
        this.fighters = 0;
        this.fighterCapacity = 80;
    }

    public int deployFighters()
    {
        int holder = fighters;
        fighters = 0;
        return holder;
    }
    
    public void addFighters(short i)
    {
        if(fighters + i > fighterCapacity + fighters)
        {
            fighters = fighterCapacity;
        }
        else
        {
            fighters = (short)(fighters + i);
        }       
    }
    
    public void repair()
    {
        fighters = fighterCapacity;
    }
    
    public double[] getRepairCost()
    {
        return new double[] {0, 30*getOpenCarrierSpace(), 30*getOpenCarrierSpace(), 35*getOpenCarrierSpace()};
    }
    
    public short getOpenCarrierSpace()
    {
        return (short)(fighterCapacity - fighters);
    }
    
    public double getUpkeep()
    {
        return upkeep + fighters*10;
    }
}
