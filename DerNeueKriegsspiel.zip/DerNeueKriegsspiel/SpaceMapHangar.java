
/**
 * Write a description of class SpaceMapHangar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapHangar extends SpaceMapBuilding
{
    private int fighters;
    private int fighterCapacity;
    /**
     * Constructor for objects of class SpaceMapHangar
     */
    public SpaceMapHangar()
    {
        this.fighters = 0;
        this.fighterCapacity = 80;
    }

    public int deployFighters()
    {
        int holder = fighters;
        fighters = 0;
        return holder;
    }
    
    public double getUpkeep()
    {
        return upkeep + fighters*10;
    }
}
