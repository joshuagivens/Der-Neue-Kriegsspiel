
/**
 * Write a description of class SpaceMapHeavyBattleship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapHeavyBattleship extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapHeavyBattleship
     */
    public SpaceMapHeavyBattleship()
    {
        this.shipType = "Heavy Battleship";
        this.size = 8;
        this.carrierCapacity = 12;
        this.moneyCost = 7200;
        this.metalCost = 5600;
        this.industryCost = 5600;
        this.baseHealth = 400;
        this.baseAttack = 165;
        this.baseDefense = 120;
        this.health = baseHealth;
    }

    
}
