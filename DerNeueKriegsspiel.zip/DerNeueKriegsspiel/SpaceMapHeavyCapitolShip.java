
/**
 * Write a description of class SpaceMapHeavyCapitolShip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapHeavyCapitolShip extends SpaceMapShip
{
    
    /**
     * Constructor for objects of class SpaceMapHeavyCapitolShip
     */
    public SpaceMapHeavyCapitolShip()
    {
        this.shipType = "Heavy Capital Ship";
        this.size = 11;
        this.carrierCapacity = 210;
        this.moneyCost = 22500;
        this.metalCost = 18000;
        this.industryCost = 18000;
        this.baseHealth = 610;
        this.baseAttack = 265;
        this.baseDefense = 160;
        this.health = baseHealth;
    }
    
}
