
/**
 * Write a description of class SpaceMapHeavyCarrier here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapHeavyCarrier extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapHeavyCarrier
     */
    public SpaceMapHeavyCarrier()
    {
        this.shipType = "Heavy Carrier";
        this.size = 6;
        this.carrierCapacity = 150;
        this.moneyCost = 14500;
        this.metalCost = 11500;
        this.industryCost = 11500;
        this.baseHealth = 240;
        this.baseAttack = 35;
        this.baseDefense = 100;
        this.health = baseHealth;
    }

    
}
