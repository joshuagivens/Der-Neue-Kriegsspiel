
/**
 * Write a description of class SpaceMapHeavyCruiser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapHeavyCruiser extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapHeavyCruiser
     */
    public SpaceMapHeavyCruiser()
    {
        this.size = 5;
        this.carrierCapacity = 6;
        this.moneyCost = 4500;
        this.metalCost = 3600;
        this.industryCost = 3600;
        this.baseHealth = 250;
        this.baseAttack = 85;
        this.baseDefense = 75;
    }

    
}
