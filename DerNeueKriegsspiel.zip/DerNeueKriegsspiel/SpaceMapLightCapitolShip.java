
/**
 * Write a description of class SpaceMapLightCapitolShip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapLightCapitolShip extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapLightCapitolShip
     */
    public SpaceMapLightCapitolShip()
    {
        this.shipType = "Light Capital Ship";
        this.size = 9;
        this.carrierCapacity = 160;
        this.moneyCost = 18000;
        this.metalCost = 14500;
        this.industryCost = 14500;
        this.baseHealth = 500;
        this.baseAttack = 180;
        this.baseDefense = 130;
        this.health = baseHealth;
    }

    
}
