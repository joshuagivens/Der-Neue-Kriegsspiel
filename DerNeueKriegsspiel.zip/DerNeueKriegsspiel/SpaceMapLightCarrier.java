
/**
 * Write a description of class SpaceMapLightCarrier here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapLightCarrier extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapLightCarrier
     */
    public SpaceMapLightCarrier()
    {
        this.size = 4;
        this.carrierCapacity = 60;
        this.moneyCost = 6100;
        this.metalCost = 4900;
        this.industryCost = 4900;
        this.baseHealth = 115;
        this.baseAttack = 15;
        this.baseDefense = 45;
    }

    
}
