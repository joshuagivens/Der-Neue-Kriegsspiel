
/**
 * Write a description of class SpaceMapLightCruiser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapLightCruiser extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapLightCruiser
     */
    public SpaceMapLightCruiser()
    {
        this.size = 4;
        this.carrierCapacity = 4;
        this.moneyCost = 3500;
        this.metalCost = 2750;
        this.industryCost = 2750;
        this.baseHealth = 175;
        this.baseAttack = 60;
        this.baseDefense = 60;
    }

    
}
