
/**
 * Write a description of class SpaceMapMediumCapitolShip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapMediumCapitolShip extends SpaceMapShip
{    

    /**
     * Constructor for objects of class SpaceMapMediumCapitolShip
     */
    public SpaceMapMediumCapitolShip()
    {
        this.size = 10;
        this.carrierCapacity = 180;
        this.moneyCost = 20000;
        this.metalCost = 16000;
        this.industryCost = 16000;
        this.baseHealth = 560;
        this.baseAttack = 210;
        this.baseDefense = 145;
    }
    
}
