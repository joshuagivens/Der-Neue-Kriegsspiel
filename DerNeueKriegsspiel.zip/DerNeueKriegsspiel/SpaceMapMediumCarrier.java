
/**
 * Write a description of class SpaceMapMediumCarrier here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapMediumCarrier extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapMediumCarrier
     */
    public SpaceMapMediumCarrier()
    {
        this.shipType = "Medium Carrier";
        this.size = 6;
        this.carrierCapacity = 100;
        this.moneyCost = 10000;
        this.metalCost = 8000;
        this.industryCost = 8000;
        this.baseHealth = 150;
        this.baseAttack = 20;
        this.baseDefense = 60;
        this.health = baseHealth;
    }

    
}
