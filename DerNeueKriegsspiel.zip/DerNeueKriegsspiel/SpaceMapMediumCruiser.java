
/**
 * Write a description of class SpaceMapMediumCruiser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapMediumCruiser extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapMediumCruiser
     */
    public SpaceMapMediumCruiser()
    {
        this.size = 4;
        this.carrierCapacity = 5;
        this.moneyCost = 4000;
        this.metalCost = 3200;
        this.industryCost = 3200;
        this.baseHealth = 200;
        this.baseAttack = 70;
        this.baseDefense = 65;
    }

    
}
