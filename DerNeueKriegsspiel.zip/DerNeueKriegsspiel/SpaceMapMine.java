
/**
 * Write a description of class SpaceMapMine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapMine extends SpaceMapBuilding
{
    

    /**
     * Constructor for objects of class SpaceMapMine
     */
    public SpaceMapMine()
    {
        
    }

    public double[] getProduction()
    {
        return new double[]{0,800,0,0,0,0,0};
    }
}
