import java.util.ArrayList;
/**
 * Write a description of class SpaceMapPlanet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPlanet
{
    private String name;
    private int population;
    private int fullSize;
    private int currentSize;
    private ArrayList <SpaceMapBuilding> buildings;
    private SpaceMapFleet[] fleets;
    private SpaceMapPlayer owner;    
    public double foodTotal;
    public double metalTotal;
    public double industryTotal;
    public double moneyTotal;
    public int newPeople;

    /**
     * Constructor for objects of class SpaceMapPlanet
     */
    public SpaceMapPlanet(String name, int planetType, SpaceMapPlayer owner)
    {
        this.name = name;
        if (planetType == 0)
        {
            this.population = 10000;
            this.fullSize = 10000;
            this.currentSize = 1000;
        }
        else if (planetType == 1 || planetType == 2)
        {
            this.population = 5000;
            this.fullSize = 5000;
            this.currentSize = 500;
        }
        else if (planetType == 3 || planetType == 4 || planetType == 5)
        {
            this.population = 2500;
            this.fullSize = 2500;
            this.currentSize = 250;
        }
        else
        {
            this.population = 1000;
            this.fullSize = 1000;
            this.currentSize = 100;
        }
        this.owner = owner;
        
        
        this.buildings = new ArrayList <SpaceMapBuilding> ();
        //this.fleets =  new SpaceMapFleet[];
           
        this.foodTotal = 0;
        this.metalTotal = 0;
        this.industryTotal = 0;
        this.moneyTotal = 0;
        this.newPeople = 0;
    }
    
    public String getDescription()
    {
        return "Name: " + name + ", Owner: " + owner.getName() + ", Population: " + population + ", Current Space: " + currentSize + ", Potential Space: " + fullSize + ", Total Buildings: " + buildings.size();
    }
    
    public void setOwner(SpaceMapPlayer newOwner)
    {
        owner = newOwner;
    }
    
    public void resetStuff()
    {
        newPeople = 0;
    }

    public SpaceMapPlayer getOwner()
    {
        return owner;
    }
    
    public ArrayList <SpaceMapHangar> getHangar()
    {
        ArrayList <SpaceMapHangar> hangar = new ArrayList <SpaceMapHangar> ();
        for (int i = 0; i < buildings.size(); i++)
        {
            if (buildings.get(i) instanceof SpaceMapHangar)
            {
                hangar.add((SpaceMapHangar)buildings.get(i));
            }
        }
        return hangar;
    }
    
    public ArrayList <SpaceMapDefenseBattery> getDefenseBattery()
    {
        ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
        for (int i = 0; i < buildings.size(); i++)
        {
            if (buildings.get(i) instanceof SpaceMapDefenseBattery)
            {
                defenseBattery.add((SpaceMapDefenseBattery)buildings.get(i));
            }
        }
        return defenseBattery;
    }
    
    public void getStuff()
    {
        double[] stuff = new double[4];
        double[] holder = new double[4];
        if (owner.getEconGov() == 3)
        {
            double t = population*.1;            
            double[] resSpread = new double[3];           
            double h;        
            double ran = 0;
            for (int i = 0; i < 3;i++)
            {
                h = Math.random();      
                resSpread[i] = h;
                ran = ran + h;           
            }            
            for(int i = 0; i < 3;i++)
            {
                stuff[i] = stuff[i] + t*resSpread[i]/ran;            
            }
            stuff[3] = stuff[3] + t;
        }
        else if (owner.getEconGov() == 2)
        {
            
        }
        else
        {
            
        }
        for (int i = 0; i < buildings.size(); i++)
        {
            holder = buildings.get(i).getProduction();
            for(int k = 0; k < stuff.length; k++)
            {
                stuff[k] = stuff[k] + holder[k];
            }
            foodTotal = foodTotal + stuff[0];
            metalTotal = metalTotal + stuff[1];
            industryTotal = industryTotal + stuff[2];
            moneyTotal = moneyTotal + stuff[3];
        }
    }
    
    public void buyMine()
    {
        if(owner.checkResources(SpaceMapBuilding.cost()))
        {
            owner.spendResources(SpaceMapBuilding.cost());
            buildings.add(new SpaceMapMine());
        }
        
    }
    
    public void buyFarm()
    {
        if(owner.checkResources(SpaceMapBuilding.cost()))
        {
            owner.spendResources(SpaceMapBuilding.cost());
            buildings.add(new SpaceMapFarm());
        }       
    }
    
    public void buyHangar()
    {
        if(owner.checkResources(SpaceMapBuilding.cost()))
        {
            owner.spendResources(SpaceMapBuilding.cost());
            buildings.add(new SpaceMapHangar());
        }        
    }
    
    public void buyDefenseBattery()
    {
        if(owner.checkResources(SpaceMapBuilding.cost()))
        {
            owner.spendResources(SpaceMapBuilding.cost());
            buildings.add(new SpaceMapDefenseBattery());
        }       
    }
    
    public void buyFactory()
    {
        if(owner.checkResources(SpaceMapBuilding.cost()))
        {
            owner.spendResources(SpaceMapBuilding.cost());
            buildings.add(new SpaceMapFactory());
        }      
    }
    
    public void buyTradeCenter()
    {
        if(owner.checkResources(SpaceMapBuilding.cost()))
        {
            owner.spendResources(SpaceMapBuilding.cost());
            buildings.add(new SpaceMapTradeCenter());
        }      
    }
    
    public void adjustPopulation(double percentRate)
    {
        if (percentRate > 1)
        {
            newPeople = (int)(population*.01);
            population = (int)(population*1.01);
        }
        else if(owner.getGov() == 0 && percentRate < 0)
        {
            population = (int)(population*(1+(percentRate/100)));
            if (population < 0)
            {
                population = 0;
            }
        }
        else if(percentRate < -1)
        {
            population = (int)(population*.99);
            if (population < 0)
            {
                population = 0;
            }
        }
        else
        {
            if (percentRate > 0)
            {
                newPeople = (int)(population*(percentRate/100));
            }
            population = (int)(population*(1+(percentRate/100)));
            if (population < 0)
            {
                population = 0;
            }
        }
    } 
    
    public double[] getCost()
    {
        double moneyCost = 0;
        for (int i = 0; i < buildings.size(); i++)
        {
            moneyCost = moneyCost + buildings.get(i).getUpkeep();
        }       
        for (int i = 0; i < fleets.length; i++)
        {
            if (fleets[i].getOwner().getName().equals(owner.getName()))
            {
                moneyCost = moneyCost + fleets[i].getUpkeep();
            }
        }
        return new double[] {population + newPeople, 0, 0, moneyCost};
    }
    
    public void engageFleets()
    {
        if(owner.getEnemies().size() > 0)
        {
            int enemySize = 0;
            int friendlySize = 0;            
            ArrayList <SpaceMapPlayer> enemies = owner.getEnemies();
            ArrayList <SpaceMapPlayer> allies = owner.getAllies();
            ArrayList <SpaceMapFleet> alliedFleet = new ArrayList <SpaceMapFleet> ();
            ArrayList <SpaceMapFleet> enemyFleet = new ArrayList <SpaceMapFleet> ();
            for (int i = 0; i < fleets.length;i++)
            {
                if (fleets[i].getOwner() == owner && fleets[i].fleetSize() > 0)
                {
                    friendlySize = friendlySize + fleets[i].fleetSize();
                    alliedFleet.add(fleets[i]);
                    break;
                }
            }
            for(int i = 0; i < fleets.length;i++)
            {
                for (int q = 0; q < enemies.size();q++)
                {
                    if (fleets[i].getOwner() == enemies.get(q) && fleets[i].fleetSize() > 0)
                    {
                        enemySize = enemySize + fleets[i].fleetSize();
                        enemyFleet.add(fleets[i]);
                    }
                }
                for (int q = 0; q < allies.size();q++)
                {
                    if (fleets[i].getOwner() == allies.get(q) && fleets[i].fleetSize() > 0)
                    {
                        friendlySize = friendlySize + fleets[i].fleetSize();
                        alliedFleet.add(fleets[i]);
                    }
                }
            }
            if (!(enemySize > 0))
            {
                return;
            }
            else if(!(friendlySize > 0))
            {
                
            }
            else
            {             
                double alliedDamage = 0;               
                double enemyDamage = 0;
                for (int i = 0; i < alliedFleet.size(); i++)
                {
                    alliedDamage = alliedDamage + alliedFleet.get(i).openFire();
                }
                for (int i = 0; i < enemyFleet.size(); i++)
                {
                    enemyDamage = enemyDamage + enemyFleet.get(i).openFire();
                }
                double[] damSpreadAllied = new double[alliedFleet.size()]; 
                double hA;        
                double ranA = 0;
                for (int i = 0; i < alliedFleet.size();i++)
                {
                    hA = Math.random();                    
                    damSpreadAllied[i] = hA + 2;
                    ranA = ranA + hA + 2;         
                } 
                for (int i = 0; i < alliedFleet.size();)
                {
                    alliedFleet.get(i).damageFleet((enemyDamage*damSpreadAllied[i]*alliedFleet.get(i).fleetSize())/(ranA*friendlySize));
                }
                
                double[] damSpreadEnemy = new double[enemyFleet.size()]; 
                double hE;        
                double ranE = 0;
                for (int i = 0; i < enemyFleet.size();i++)
                {
                    hE = Math.random();                    
                    damSpreadEnemy[i] = hE + 2;
                    ranE = ranE + hE + 2;         
                } 
                for (int i = 0; i < enemyFleet.size();)
                {
                    enemyFleet.get(i).damageFleet((alliedDamage*damSpreadEnemy[i]*enemyFleet.get(i).fleetSize())/(ranE*enemySize));
                }
            }
            
        }        
    }
    
    public String getName()
    {
        return name;
    }
    
    public boolean equals(SpaceMapPlanet p)
    {
        if (p.getName().equals(name))
        {
            return true;
        }
        return false;
    }
}
