import java.util.ArrayList;
/**
 * Write a description of class SpaceMapPlanet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPlanet
{
    private String name;
    public int population;
    //private short fullSize;
    private short currentSize;
    private ArrayList <SpaceMapBuilding> buildings;
    private SpaceMapFleet[] fleets;
    private SpaceMapPlayer owner;    
    /*public double foodTotal;
    public double metalTotal;
    public double industryTotal;
    public double moneyTotal;*/
    public int newPeople;
    private ArrayList <SpaceMapPlanet> adjecents;
    private short planetDesignation;
    /**
     * Constructor for objects of class SpaceMapPlanet
     */
    public SpaceMapPlanet(String name, short planetType, SpaceMapPlayer owner, SpaceMapPlayer[] players, short planetDesignation)
    {
        this.planetDesignation = planetDesignation;
        this.name = name;
        if (planetType == 0)
        {
            this.population = 5000;
            //this.fullSize = 5000;
            this.currentSize = 100;
        }
        else if (planetType == 1 || planetType == 2)
        {
            this.population = 7500;
            //this.fullSize = 7500;
            this.currentSize = 250;
        }
        else if (planetType == 3 || planetType == 4 || planetType == 5)
        {
            this.population = 10000;
            //this.fullSize = 10000;
            this.currentSize = 500;
        }
        else
        {
            this.population = 25000;
            //this.fullSize = 25000;
            this.currentSize = 750;
        }
        this.owner = owner;

        this.buildings = new ArrayList <SpaceMapBuilding> ();
        this.fleets =  new SpaceMapFleet[players.length];

        for(short i = 0; i < players.length; i++)
        {
            this.fleets[i] = new SpaceMapFleet(players[i]);
        }

        /*this.foodTotal = 0;
        this.metalTotal = 0;
        this.industryTotal = 0;
        this.moneyTotal = 0;*/
        this.newPeople = 0;
        this.adjecents = new ArrayList <SpaceMapPlanet> ();
    }

    public void fixFleetsLocation(SpaceMapPlanet p)
    {
        for(short i = 0; i < fleets.length; i++)
        {
            fleets[i].setLocation(p);
        }        
    }

    public void checkDefenseBattery()
    {
        //ArrayList <SpaceMapHangar> hangar = new ArrayList <SpaceMapHangar> ();
        boolean[] removes = new boolean[buildings.size()];
        for (int i = 0; i < buildings.size(); i++)
        {
            if (buildings.get(i) instanceof SpaceMapDefenseBattery)
            {
                //hangar.add((SpaceMapHangar)buildings.get(i));
                if (((SpaceMapDefenseBattery)(buildings.get(i))).getHealth() < 0)
                {
                    removes[i] = true;
                }
                else
                {
                    removes[i] = false;
                }
            }
            else
            {
                removes[i] = false;
            }
        }
        //return hangar;
        for(int i = buildings.size()-1;i>=0;i--)
        {
            if(removes[i])
            {
                buildings.remove(i);
            }
        }
    }

    public String getDescription()
    {
        short farms = 0;
        short factories = 0;
        short mines = 0;
        short tradeCenters = 0;
        short uraniumMines= 0;
        short titaniumMines = 0;
        short promethiumMines = 0;
        short defenseBatteries = 0;
        short hangars = 0;
        for (short i = 0; i < buildings.size();i++)
        {
            if (buildings.get(i) instanceof SpaceMapFarm)
            {
                farms ++;
            }
            else if (buildings.get(i) instanceof SpaceMapFactory)
            {
                factories ++;
            }
            else if (buildings.get(i) instanceof SpaceMapMine)
            {
                mines ++;
            }
            else if (buildings.get(i) instanceof SpaceMapTradeCenter)
            {
                tradeCenters ++;
            }
            else if (buildings.get(i) instanceof SpaceMapUraniumMine)
            {
                uraniumMines ++;
            }
            else if (buildings.get(i) instanceof SpaceMapTitaniumMine)
            {
                titaniumMines ++;
            }
            else if (buildings.get(i) instanceof SpaceMapPromethiumMine)
            {
                promethiumMines ++;
            }
            else if (buildings.get(i) instanceof SpaceMapDefenseBattery)
            {
                defenseBatteries ++;
            }
            else if (buildings.get(i) instanceof SpaceMapHangar)
            {
                hangars ++;
            }
        }

        return "Location ID: " + getID() + ", Name: " + name + ", Owner: " + owner.getName() + ", Population: " + population + ", Building Space: " + currentSize + /*", Potential Space: " + fullSize +*/ ", Total Buildings: " + buildings.size()
        + ",\nFarms: " + farms + ", Factories: " + factories + ", Mines: " + mines + ", Trade Centers: " + tradeCenters + ", Uranium Mines: " + uraniumMines + ", Titanium Mines: " + titaniumMines + 
        ", Promethium Mines: " + promethiumMines + ", Defense Batteries: " + defenseBatteries + ", Hangars: " + hangars;
    }

    public String getID()
    {
        String designation = "";
        if(planetDesignation < 10)
        {
            designation = designation + "0";
        }
        return designation + planetDesignation;
    }

    public void setOwner(SpaceMapPlayer newOwner)
    {
        owner = newOwner;
    }

    public void resetStuff()
    {
        newPeople = 0;
    }

    public SpaceMapPlayer getOwner()
    {
        return owner;
    }

    public void reintegrateShips()
    {
        fleets[0].reintegrateShips();
        fleets[1].reintegrateShips();
    }

    public SpaceMapFleet getFleet(SpaceMapPlayer p)
    {
        for (int i = 0; i < fleets.length; i++)
        {
            if(fleets[i].getOwner().getName().equals(p.getName()))
            {
                return fleets[i];
            }
        }
        return null;
    }        

    public ArrayList <SpaceMapHangar> getHangar()
    {
        ArrayList <SpaceMapHangar> hangar = new ArrayList <SpaceMapHangar> ();
        for (int i = 0; i < buildings.size(); i++)
        {
            if (buildings.get(i) instanceof SpaceMapHangar)
            {
                hangar.add((SpaceMapHangar)buildings.get(i));
            }
        }
        return hangar;
    }

    public ArrayList <SpaceMapDefenseBattery> getDefenseBattery()
    {
        ArrayList <SpaceMapDefenseBattery> defenseBattery = new ArrayList <SpaceMapDefenseBattery> ();
        for (int i = 0; i < buildings.size(); i++)
        {
            if (buildings.get(i) instanceof SpaceMapDefenseBattery)
            {
                defenseBattery.add((SpaceMapDefenseBattery)buildings.get(i));
            }
        }
        return defenseBattery;
    }

    public int getPopulation()
    {
        return population;
    }

    public double[] getStuff()
    {
        double[] stuff = new double[7];
        double[] holder = new double[7];
        for (short i = 0; i < buildings.size(); i++)
        {
            holder = buildings.get(i).getProduction();
            for(short k = 0; k < stuff.length; k++)
            {
                stuff[k] = stuff[k] + holder[k];
            }
            /*foodTotal = foodTotal + stuff[0];
            metalTotal = metalTotal + stuff[1];
            industryTotal = industryTotal + stuff[2];
            moneyTotal = moneyTotal + stuff[3];*/
        }
        return stuff;
        /*double[] stuff = new double[4];
        double[] holder = new double[7];
        double[] rares = new double[3];
        if (owner.getEconGov() == 3)
        {
        double t = population*.1;            
        double[] resSpread = new double[3];           
        double h;        
        double ran = 0;
        int populationLeft = population;
        for(int i = 0; i < population; i++)
        {
        if(Math.random() < .000001)
        {
        populationLeft --;
        if (Math.random() < (1/3))
        {
        rares[0] = rares[0] + .01;
        }
        else if(Math.random() < .5)
        {
        rares[1] = rares[1] + .01;
        }
        else
        {
        rares[2] = rares[2] + .01;
        }
        }
        }
        h = Math.random(); 
        if (owner.enoughFood())
        {
        resSpread[0] = h + .02;
        ran = ran + h + .02;   
        }
        else
        {
        resSpread[0] = h + .03;
        ran = ran + h + .03;
        }

        for (int i = 1; i < 3;i++)
        {
        h = Math.random();      
        resSpread[i] = h + .01;
        ran = ran + h + .01;           
        }            
        for(int i = 0; i < 3;i++)
        {
        stuff[i] = stuff[i] + populationLeft*.1*resSpread[i]/ran;            
        }
        stuff[3] = stuff[3] + t;
        }
        else if (owner.getEconGov() == 2)
        {
        double[] weights = new double[6];
        weights = owner.getWeights();
        double[] resSpread = new double[6];           
        double h;
        double ran = 0;
        h = Math.random(); 
        if (owner.enoughFood())
        {
        resSpread[0] = h + .02 + weights[0];
        ran = ran + h + .02 + weights[0];   
        }
        else
        {
        resSpread[0] = h + .03 + weights[0]; 
        ran = ran + h + .03 + weights[0]; 
        }
        for (int i = 1; i < weights.length; i++)
        {
        h = Math.random();      
        resSpread[i] = h + .01 + weights[i];
        ran = ran + h + .01 + weights[i];
        }
        for(int i = 0; i < 3;i++)
        {
        stuff[i] = stuff[i] + population*.1*resSpread[i]/ran;            
        }
        stuff[3] = population*.1;
        for(int i = 0; i < 3;i++)
        {
        rares[i] = rares[i] + population*.01*resSpread[i+4]/ran;            
        }
        }
        else
        {
        double[] weights = new double[6];
        weights = owner.getWeights();
        double totalWeight = 0;
        for (int i = 0; i < 6; i++)
        {
        totalWeight = totalWeight + weights[i];
        }

        for(int i = 0; i < 3;i++)
        {
        stuff[i] = stuff[i] + population*.1*weights[i]/totalWeight;            
        }
        stuff[3] = population*.1;
        for(int i = 0; i < 3;i++)
        {
        rares[i] = rares[i] + population*.01*weights[i+4]/totalWeight;            
        }
        }
        for (int i = 0; i < buildings.size(); i++)
        {
        holder = buildings.get(i).getProduction();
        for(int k = 0; k < stuff.length; k++)
        {
        stuff[k] = stuff[k] + holder[k];
        }
        foodTotal = foodTotal + stuff[0];
        metalTotal = metalTotal + stuff[1];
        industryTotal = industryTotal + stuff[2];
        moneyTotal = moneyTotal + stuff[3];
        }

        return new double[] {stuff[0]+holder[0],stuff[1]+holder[1],stuff[2]+holder[2],stuff[3]+holder[3],rares[0]+holder[4],rares[1]+holder[5],rares[2]+holder[6]};
         */
    }

    public SpaceMapFleet selectFleet(SpaceMapPlayer p)
    {
        int i = 0;       
        while(true)
        {     
            if(fleets[i].getOwner() == p)
            {
                return fleets[i];
            }
            else
            {

            }
            i++;
        }
    }

    public int getEnemyFleetSize()
    {
        int q = 0;
        for(short i = 0; i < owner.getEnemies().size(); i++)
        {
            q = q + getFleetStrength(owner.getEnemies().get(i));
        }
        return q;
    }

    public int getFleetStrength()
    {
        return selectFleet(owner).fleetSize();
    }

    public int getFleetStrength(SpaceMapPlayer p)
    {
        return selectFleet(p).fleetSize();
    }

    public double[] getBuildingCost()
    {
        return SpaceMapBuilding.cost();
    }

    public void buyMine()
    {
        /*if(owner.checkResources(SpaceMapBuilding.cost()))
        {
        owner.spendResources(SpaceMapBuilding.cost());
        buildings.add(new SpaceMapMine());
        }*/
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapMine());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyFarm()
    {
        /*if(owner.checkResources(SpaceMapBuilding.cost()))
        {
        owner.spendResources(SpaceMapBuilding.cost());
        buildings.add(new SpaceMapFarm());
        } */     
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapFarm());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyHangar()
    {
        /*if(owner.checkResources(SpaceMapBuilding.cost()))
        {
        owner.spendResources(SpaceMapBuilding.cost());
        buildings.add(new SpaceMapHangar());
        }*/       
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapHangar());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyDefenseBattery()
    {
        /*if(owner.checkResources(SpaceMapBuilding.cost()))
        {
        owner.spendResources(SpaceMapBuilding.cost());
        buildings.add(new SpaceMapDefenseBattery());
        }   */    
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapDefenseBattery());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyFactory()
    {
        /*if(owner.checkResources(SpaceMapBuilding.cost()))
        {
        owner.spendResources(SpaceMapBuilding.cost());
        buildings.add(new SpaceMapFactory());
        } */   
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapFactory());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyTradeCenter()
    {
        /*if(owner.checkResources(SpaceMapBuilding.cost()))
        {
        owner.spendResources(SpaceMapBuilding.cost());
        buildings.add(new SpaceMapTradeCenter());
        }  */    
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapTradeCenter());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyUraniumMine()
    {
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapUraniumMine());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyPromethiumMine()
    {
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapPromethiumMine());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void buyTitaniumMine()
    {
        if(buildings.size() < currentSize)
        {
            buildings.add(new SpaceMapTitaniumMine());
        }
        else
        {
            throw new IndexOutOfBoundsException("");
        }
    }

    public void addCorvette()
    {
        getOwnerFleet().addCorvette();
    }

    public void addFrigate()
    {
        getOwnerFleet().addFrigate();
    }

    public void addDestroyer()
    {
        getOwnerFleet().addDestroyer();
    }

    public void addLightCruiser()
    {
        getOwnerFleet().addLightCruiser();
    }

    public void addMediumCruiser()
    {
        getOwnerFleet().addMediumCruiser();
    }

    public void addHeavyCruiser()
    {
        getOwnerFleet().addHeavyCruiser();
    }

    public void addBattlecruiser()
    {
        getOwnerFleet().addBattlecruiser();
    }

    public void addBattleship()
    {
        getOwnerFleet().addBattleship();
    }

    public void addHeavyBattleship()
    {
        getOwnerFleet().addHeavyBattleship();
    }

    public void addEscortCarrier()
    {
        getOwnerFleet().addEscortCarrier();
    }

    public void addLightCarrier()
    {
        getOwnerFleet().addLightCarrier();
    }

    public void addMediumCarrier()
    {
        getOwnerFleet().addMediumCarrier();
    }

    public void addHeavyCarrier()
    {
        getOwnerFleet().addHeavyCarrier();
    }

    public void addLightCapitalShip()
    {
        getOwnerFleet().addLightCapitalShip();
    }

    public void addMediumCapitalShip()
    {
        getOwnerFleet().addMediumCapitalShip();
    }

    public void addHeavyCapitalShip()
    {
        getOwnerFleet().addHeavyCapitalShip();
    }

    public void addSectorDominanceShip()
    {
        getOwnerFleet().addSectorDominanceShip();
    }

    public SpaceMapFleet getOwnerFleet()
    {
        for (short i = 0; i < fleets.length; i++)
        {
            if (fleets[i].getOwner() == owner)
            {
                return fleets[i];
            }
        }
        return null;
    }

    public void adjustPopulation(double percentRate)
    {
        if(percentRate != 0)
        {
            newPeople = (int)(population*(percentRate/100));
            population = (int)(population*(1+(percentRate/100)));
            if (percentRate > 0)
            {
                newPeople = newPeople + 1; 
                population = population + 1;
            }
        }
        /*if (percentRate > 1)
        {
        newPeople = (int)(population*.01);
        population = (int)(population*1.01);
        }
        else if(owner.getGov() == 0 && percentRate < 0)
        {
        population = (int)(population*(1+(percentRate/100)));
        if (population < 0)
        {
        population = 0;
        }
        }
        else if(percentRate < -1)
        {
        population = (int)(population*.99);
        if (population < 0)
        {
        population = 0;
        }
        }
        else
        {
        if (percentRate > 0)
        {
        newPeople = (int)(population*(percentRate/100));
        }
        population = (int)(population*(1+(percentRate/100)));
        if (population < 0)
        {
        population = 0;
        }
        }*/
    } 

    public double[] getCost()
    {
        double moneyCost = 0;
        double[] d = new double[4];
        for (short i = 0; i < buildings.size(); i++)
        {
            moneyCost = moneyCost + buildings.get(i).getUpkeep();
        }       
        for (short i = 0; i < fleets.length; i++)
        {
            if (fleets[i].getOwner().getName().equals(owner.getName()))
            {
                d = fleets[i].getCost();
            }
        }
        return new double[] {population + newPeople, d[1], d[2], moneyCost+ d[3]};
    }

    public void repairs()
    {
        for (short i = 0; i < fleets.length; i++)
        {
            if (fleets[i].getOwner().getName().equals(owner.getName()))
            {
                fleets[i].repair();
            }
        }

        for (int i = 0; i < buildings.size(); i++)
        {
            if (buildings.get(i) instanceof SpaceMapDefenseBattery)
            {
                ((SpaceMapDefenseBattery)(buildings.get(i))).repair();
            }
            if (buildings.get(i) instanceof SpaceMapHangar)
            {
                ((SpaceMapHangar)(buildings.get(i))).repair();
            }
        }

    }

    public boolean getEnemy()
    {
        if(owner.getEnemies().size() > 0)
        {
            for(int i = 0; i < fleets.length;i++)
            {
                for (int q = 0; q < owner.getEnemies().size();q++)
                {
                    if (fleets[i].getOwner() == owner.getEnemies().get(q) && fleets[i].fleetSize() > 0)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void engageFleets()
    {
        if(owner.getEnemies().size() > 0)
        {
            int enemySize = 0;
            int friendlySize = 0;            
            ArrayList <SpaceMapPlayer> enemies = owner.getEnemies();
            ArrayList <SpaceMapPlayer> allies = owner.getAllies();
            ArrayList <SpaceMapFleet> alliedFleet = new ArrayList <SpaceMapFleet> ();
            ArrayList <SpaceMapFleet> enemyFleet = new ArrayList <SpaceMapFleet> ();
            for (int i = 0; i < fleets.length;i++)
            {
                if (fleets[i].getOwner() == owner && fleets[i].fleetSize() > 0)
                {
                    friendlySize = friendlySize + fleets[i].fleetSize();
                    alliedFleet.add(fleets[i]);
                    fleets[i].reintegrateShips();
                    break;
                }
            }
            for(int i = 0; i < fleets.length;i++)
            {
                for (int q = 0; q < enemies.size();q++)
                {
                    if (fleets[i].getOwner() == enemies.get(q) && fleets[i].fleetSize() > 0)
                    {
                        enemySize = enemySize + fleets[i].fleetSize();
                        enemyFleet.add(fleets[i]);
                        fleets[i].reintegrateShips();
                    }
                }
                for (int q = 0; q < allies.size();q++)
                {
                    if (fleets[i].getOwner() == allies.get(q) && fleets[i].fleetSize() > 0)
                    {
                        friendlySize = friendlySize + fleets[i].fleetSize();
                        alliedFleet.add(fleets[i]);
                        fleets[i].reintegrateShips();
                    }
                }
            }
            if (!(enemySize > 0))
            {
                return;
            }
            else if(!(friendlySize > 0))
            {          
                for(short q = 0; q < owner.enemies.size(); q++)
                {
                    if(getFleetStrength(owner.enemies.get(q)) > 0)
                    {
                        owner.enemies.get(q).addPlanet(owner.removePlanet(name));
                        owner = owner.enemies.get(q);
                    }                   
                }
            }
            else
            {             
                while(enemySize > 0 && friendlySize > 0)
                {        
                    double alliedDamage = 0;               
                    double enemyDamage = 0;
                    for (int i = 0; i < alliedFleet.size(); i++)
                    {
                        alliedDamage = alliedDamage + alliedFleet.get(i).openFire();
                    }
                    for (int i = 0; i < enemyFleet.size(); i++)
                    {
                        enemyDamage = enemyDamage + enemyFleet.get(i).openFire();
                    }
                    double[] damSpreadAllied = new double[alliedFleet.size()]; 
                    double hA;        
                    double ranA = 0;
                    for (int i = 0; i < alliedFleet.size();i++)
                    {
                        hA = Math.random();                    
                        damSpreadAllied[i] = hA + 2;
                        ranA = ranA + hA + 2;         
                    } 
                    for (int i = 0; i < alliedFleet.size();i++)
                    {
                        alliedFleet.get(i).damageFleet((enemyDamage*damSpreadAllied[i]*alliedFleet.get(i).fleetSize())/(ranA*friendlySize));
                    }

                    double[] damSpreadEnemy = new double[enemyFleet.size()]; 
                    double hE;        
                    double ranE = 0;
                    for (int i = 0; i < enemyFleet.size();i++)
                    {
                        hE = Math.random();                    
                        damSpreadEnemy[i] = hE + 2;
                        ranE = ranE + hE + 2;         
                    } 
                    for (int i = 0; i < enemyFleet.size();i++)
                    {
                        enemyFleet.get(i).damageFleet((alliedDamage*damSpreadEnemy[i]*enemyFleet.get(i).fleetSize())/(ranE*enemySize));
                    }

                    enemySize = 0;
                    friendlySize = 0;         
                    alliedFleet = new ArrayList <SpaceMapFleet> ();
                    enemyFleet = new ArrayList <SpaceMapFleet> ();
                    for (int i = 0; i < fleets.length;i++)
                    {
                        if (fleets[i].getOwner() == owner && fleets[i].fleetSize() > 0)
                        {
                            friendlySize = friendlySize + fleets[i].fleetSize();
                            alliedFleet.add(fleets[i]);
                            break;
                        }
                    }
                    for(int i = 0; i < fleets.length;i++)
                    {
                        for (int q = 0; q < enemies.size();q++)
                        {
                            if (fleets[i].getOwner() == enemies.get(q) && fleets[i].fleetSize() > 0)
                            {
                                enemySize = enemySize + fleets[i].fleetSize();
                                enemyFleet.add(fleets[i]);
                            }
                        }
                        for (int q = 0; q < allies.size();q++)
                        {
                            if (fleets[i].getOwner() == allies.get(q) && fleets[i].fleetSize() > 0)
                            {
                                friendlySize = friendlySize + fleets[i].fleetSize();
                                alliedFleet.add(fleets[i]);
                            }
                        }
                    }
                }
                if (!(enemySize > 0))
                {
                    return;
                }
                else if(!(friendlySize > 0))
                {          
                    for(short q = 0; q < owner.enemies.size(); q++)
                    {
                        if(getFleetStrength(owner.enemies.get(q)) > 0)
                        {
                            owner.enemies.get(q).addPlanet(owner.removePlanet(name));
                            owner = owner.enemies.get(q);
                        }                   
                    }
                }
            }

        }        
    }

    public String getName()
    {
        return name;
    }

    public boolean equals(SpaceMapPlanet p)
    {
        if (p.getName().equals(name))
        {
            return true;
        }
        return false;
    }

    public void setAdjecent(SpaceMapPlanet p)
    {
        boolean contains = false;
        for (short i = 0; i < adjecents.size(); i++)
        {
            if (adjecents.get(i) == p)
            {
                contains = true;
            }
        }
        if(!contains && p != null)
        {
            adjecents.add(p);
            //adjecents.get(adjecents.size()-1).setAdjecent(this.SpaceMapPlanet);
        }
    }

    public boolean checkAdjecent(SpaceMapPlanet p)
    {
        boolean contains = false;
        for (short i = 0; i < adjecents.size(); i++)
        {
            if (adjecents.get(i) == p)
            {
                contains = true;
                break;
            }
        }
        return contains;
    }

    public boolean checkAdjecentOwner(SpaceMapPlayer p)
    {
        boolean contains = false;
        for (short i = 0; i < adjecents.size(); i++)
        {
            if (adjecents.get(i).getOwner() == p)
            {
                contains = true;
                break;
            }
        }
        return contains;
    }
}
