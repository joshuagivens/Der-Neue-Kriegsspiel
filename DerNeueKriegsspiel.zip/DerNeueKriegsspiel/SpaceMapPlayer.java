import java.util.ArrayList;
/**
 * Write a description of class SpaceMapPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPlayer
{
    private ArrayList <SpaceMapQueueItem> queue;
    private String name;
    public short culture; 
    private short gov;
    private short econGov;
    private short forGov;
    private short foodTech;
    private short moneyTech;
    private short industryTech;
    private short metalTech;
    private short spaceTech;
    private short attackTech;
    private short defenseTech;
    private double food;
    private double money;
    private double metal;
    private double industry;
    private double titanium;
    private double promethium;
    private double uranium;
    private ArrayList <SpaceMapPlanet> planets;
    private ArrayList <SpaceMapPlayer> freePassages;
    public ArrayList <SpaceMapPlayer> enemies;
    private ArrayList <SpaceMapPlayer> vassals;
    private ArrayList <SpaceMapPlayer> puppets;
    private ArrayList <SpaceMapPlayer> allies;
    private SpaceMapPlayer vassalLord;
    private SpaceMapPlayer puppetMaster;
    private SpaceMapPlanet capital;
    private SpaceMapPlanet alternateCapital;
    private boolean usesBothCapitals;
    private boolean enoughFood;
    private double foodWeight; 
    private double metalWeight;
    private double industryWeight; 
    private double uraniumWeight; 
    private double titaniumWeight;
    private double promethiumWeight;

    /**
     * Constructor for objects of class SpaceMapPlayer
     */
    public SpaceMapPlayer(String name, short culture, short gov, short econGov, short forGov, boolean usesBothCapitals)
    {
        this.name = name;
        this.culture = culture;
        this.gov = gov;
        this.econGov = econGov;
        this.forGov = forGov;
        this.usesBothCapitals = usesBothCapitals;
        this.planets = new ArrayList <SpaceMapPlanet> ();
        this.freePassages = new ArrayList <SpaceMapPlayer> ();
        this.enemies = new ArrayList <SpaceMapPlayer> ();
        this.vassals = new ArrayList <SpaceMapPlayer> ();
        this.puppets = new ArrayList <SpaceMapPlayer> ();
        this.allies = new ArrayList <SpaceMapPlayer> ();
        this.food = 500000000;
        this.money = 1000000000;
        this.metal = 10000;
        this.industry = 10000;
        this.titanium = 10;
        this.promethium = 10;
        this.uranium = 10;
        this.enoughFood = true;
        this.queue = new ArrayList <SpaceMapQueueItem> ();
    }
    
    public void addEnemy(SpaceMapPlayer p)
    {
        enemies.add(p);
    }
    
    public SpaceMapPlanet removePlanet(String name)
    {
        for (short i = 0; i < planets.size(); i++)
        {
            if(planets.get(i).getName().equals(name))
            {
                return planets.remove(i);
            }
        }
        return null;
    }
    
    public void addPlanet(SpaceMapPlanet p)
    {
        if (p == null)
        {
            
        }
        else
        {
            planets.add(p);
        }
        
    }
    
    public double[] getWeights()
    {
        return new double[] {foodWeight, metalWeight, industryWeight, uraniumWeight, titaniumWeight, promethiumWeight};
    }
    
    public boolean enoughFood()
    {
        return enoughFood;
    }
    
    public String getDescription()
    {
        String govType = "";
        String forGovType = "";
        String econGovType = "";
        if (gov == 1)
        {
            govType = "Communist";
        }
        else if(gov == 2)
        {
            govType = "Federal Republic";
        }
        else if(gov == 3)
        {
            govType = "Monarchy";
        }
        else if(gov == 4)
        {
            govType = "Confederation";
        }
        else if(gov == 5)
        {
            govType = "Fascist";
        }
        else
        {
            govType = "Oligarchy";
        }
        if (econGov == 1)
        {
            econGovType = "Government Control of Industry";
        }
        else if(econGov == 2)
        {
            econGovType = "Government and Private Cooperative Control of Industry";
        }
        else
        {
            econGovType = "Private Control of Industry";
        }
        if (forGov == 1)
        {
            forGovType = "Expansive";
        }
        else if(forGov == 2)
        {
            forGovType = "Defensive";
        }
        else if(forGov == 3)
        {
            forGovType = "Trade Oriented";
        }
        else if(forGov == 4)
        {
            forGovType = "Peaceful Coexistence Oriented";
        }
        else
        {
            forGovType = "Colony Focused";
        }
        return name + "'s turn:\n" + "Government Type: " + govType + "\nEconomic Policy: " + 
        econGovType + "\nForeign Policy: " +  forGovType + "\nCurrent Food: " + Math.round(food) + 
        "\nCurrent Money: " + Math.round(money) + "\nCurrent Metal: " + Math.round(metal) + 
        "\nCurrent Industry: " + Math.round(industry);            
    }
    
    public boolean usesBothCapitals()
    {
        return usesBothCapitals;
    }
    
    
    public SpaceMapPlanet getCapital()
    {
        return capital;
    }
    
    public SpaceMapPlanet getAlternateCapital()
    {
        return alternateCapital;
    }
    
    public void setCapital(SpaceMapPlanet p)
    {
        capital = p;
    }
    
    public boolean capitalCheck()
    {
        if (capital == alternateCapital)
        {
            return true;
        }
        return false;
    }
    
    public void setAlternateCapital(SpaceMapPlanet p)
    {
        alternateCapital = p;
    }
    
    public ArrayList <SpaceMapPlanet> getPlanets()
    {
        return planets;
    }
    
    public ArrayList <SpaceMapPlayer> getEnemies()
    {
        return enemies;
    }
    
    public ArrayList <SpaceMapPlayer> getAllies()
    {
        return allies;
    }
    
    public ArrayList <SpaceMapPlayer> getFreePassages()
    {
        return freePassages;
    }
    
    public ArrayList <SpaceMapPlayer> getVassals()
    {
        return vassals;
    }
    
    public ArrayList <SpaceMapPlayer> getPuppets()
    {
        return puppets;
    }

    public String getName()
    {
        return name;
    }
    
    
    
    public boolean checkResources(double[] foodIndustryMetalMoney)
    {
        if(food > foodIndustryMetalMoney[0] && industry > foodIndustryMetalMoney[1] && metal > foodIndustryMetalMoney[2]&& money > foodIndustryMetalMoney[3])
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void spendResources(double[] foodIndustryMetalMoney)
    {
        food = food - foodIndustryMetalMoney[0];
        industry = industry - foodIndustryMetalMoney[1];
        metal = metal - foodIndustryMetalMoney[2];
        money = money - foodIndustryMetalMoney[3];        
    }
    
    public int getAttackTech()
    {
        return attackTech;
    }
    
    public int getCulture()
    {
        return culture;
    }
    
    public int getGov()
    {
        return gov;
    }
    
    public int getEconGov()
    {
        return econGov;
    }
    
    public int getForGov()
    {
        return forGov;
    }
    
    public void runThroughQueue()
    {
        while(true)
        {
            if (queue.size() < 1)
            {
                break;
            }
            else if(checkResources(queue.get(0).cost()))
            {
                spendResources(queue.get(0).cost());
                queue.remove(0).complete();
            }
            else
            {
                break;
            }
        }
    }
    
    public void addQueueItem(SpaceMapPlanet p, short actionType)
    {
        if(actionType < 9)
        {
            queue.add(new SpaceMapQueueItem(p.getBuildingCost(),p,actionType));
        }
        else if (actionType == 9)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,800,800,1000},p,actionType));
        }
        else if (actionType == 10)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,1000,1000,1300},p,actionType));
        }
        else if (actionType == 11)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,1700,1700,2500},p,actionType));
        }
    }
    
    public void endTurnStuff()
    {
        double foodHolder = food;
        getStuff();
        doUpkeep();
        repairs();
        runThroughQueue();
        engageFleets();
        if(foodHolder > food)
        {
            enoughFood = false;
        }
        else
        {
            enoughFood = true;
        }
    }
    
    public void repairs()
    {
        
    }
    
    public void doUpkeep()
    {
        double[] stuff = new double[4];
        double[] holder = new double[4];
        for(short i = 0; i < planets.size();i++)
        {
            holder = planets.get(i).getCost();
            for (short j = 0; j < holder.length; j++)
            {
                stuff[j] = stuff[j] + holder[j];
            }
        }
        food = food - stuff[0];
        money = money - stuff[3];
    }
    
    public void reintegrateShips()
    {
        for(short i = 0; i < planets.size();i++)
        {
            planets.get(i).reintegrateShips();
        }
    }
    
    public void getStuff()
    {
        double[] stuff = new double[7];
        double[] holder = new double[7];
        int population = 0;
        for(short i = 0; i < planets.size();i++)
        {
            population = population + planets.get(i).getPopulation();
            holder = planets.get(i).getStuff();
            for (short j = 0; j < holder.length; j++)
            {
                stuff[j] = stuff[j] + holder[j];
            }
        }
        double t = population*.1;            
        double[] resSpread = new double[3];           
        double h;        
        double ran = 0;
        int populationLeft = population;
        for(int i = 0; i < population; i++)
        {
            if(Math.random() < .000001)
            {
                populationLeft --;
                if (Math.random() < (1/3))
                {
                    stuff[4] = stuff[4] + .01;
                }
                else if(Math.random() < .5)
                {
                    stuff[5] = stuff[5] + .01;
                }
                else
                {
                    stuff[6] = stuff[6] + .01;
                }
            }
        }
        h = Math.random(); 
        if (enoughFood())
        {
            resSpread[0] = h + .02; 
            ran = ran + h + .02;   
        }
        else
        {
            resSpread[0] = h + .03;
            ran = ran + h + .03;
        }
             
            for (int i = 1; i < 3;i++)
            {
                h = Math.random();      
                resSpread[i] = h + .01;
                ran = ran + h + .01;           
            }            
            for(int i = 0; i < 3;i++)
            {
                stuff[i] = stuff[i] + populationLeft*.1*resSpread[i]/ran;            
            }
            stuff[3] = stuff[3] + t;
        food = food + stuff[0];
        industry = industry + stuff[1];
        metal = metal + stuff[2];
        money = money + stuff[3];
        uranium = uranium + stuff[4];
        titanium = titanium + stuff[5];
        promethium = promethium + stuff[6];
    }
    
    public void engageFleets()
    {
        for(short i = (short)(planets.size()-1);i >= 0; i--)
        {
            planets.get(i).engageFleets();
        }        
    }
    
    public String getQueue()
    {
        String string = "";
        for (short i = 0; i < queue.size(); i++)
        {
            string = string + queue.get(i).toString() +"\n";
        }
        return string;
    }
}
