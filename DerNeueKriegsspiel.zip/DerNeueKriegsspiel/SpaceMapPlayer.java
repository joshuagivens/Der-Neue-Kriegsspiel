import java.util.ArrayList;
/**
 * Write a description of class SpaceMapPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPlayer
{
    private ArrayList <SpaceMapQueueItem> queue;
    private String name;
    public short culture; 
    private short gov;
    private short econGov;
    private short forGov;
    private short foodTech;
    private short moneyTech;
    private short industryTech;
    private short metalTech;
    private short spaceTech;
    private short attackTech;
    private short defenseTech;
    private double food;
    private double money;
    private double metal;
    private double industry;
    private double titanium;
    private double promethium;
    private double uranium;
    private ArrayList <SpaceMapPlanet> planets;
    private ArrayList <SpaceMapPlayer> freePassages;
    public ArrayList <SpaceMapPlayer> enemies;
    private ArrayList <SpaceMapPlayer> vassals;
    private ArrayList <SpaceMapPlayer> puppets;
    private ArrayList <SpaceMapPlayer> allies;
    private SpaceMapPlayer vassalLord;
    private SpaceMapPlayer puppetMaster;
    private SpaceMapPlanet capital;
    private SpaceMapPlanet alternateCapital;
    private boolean usesBothCapitals;
    private boolean enoughFood;
    private double foodWeight; 
    private double metalWeight;
    private double industryWeight; 
    private double uraniumWeight; 
    private double titaniumWeight;
    private double promethiumWeight;
    private double growthRate;
    private ArrayList<SpaceMapPolitician> leaders;
    private double[] bonuses;
    private SpaceMapPolitician president;
    private SpaceMapPolitician vicePresident;
    private SpaceMapPolitician commander;
    private SpaceMapPolitician subCommander;
    private SpaceMapPolitician treasury;
    private SpaceMapPolitician foreign;
    private SpaceMapPolitician council;
    private SpaceMapPolitician science;
    /**
     * Constructor for objects of class SpaceMapPlayer
     */
    public SpaceMapPlayer(String name, short culture, short gov, short econGov, short forGov, boolean usesBothCapitals, ArrayList<String> leaderNames)
    {
        this.name = name;
        this.culture = culture;
        this.gov = gov;
        this.econGov = econGov;
        this.forGov = forGov;
        this.usesBothCapitals = usesBothCapitals;
        this.planets = new ArrayList <SpaceMapPlanet> ();
        this.freePassages = new ArrayList <SpaceMapPlayer> ();
        this.enemies = new ArrayList <SpaceMapPlayer> ();
        this.vassals = new ArrayList <SpaceMapPlayer> ();
        this.puppets = new ArrayList <SpaceMapPlayer> ();
        this.allies = new ArrayList <SpaceMapPlayer> ();
        this.food = 12000000;
        this.money = 1250000;
        this.metal = 100000;
        this.industry = 100000;
        this.titanium = 10;
        this.promethium = 10;
        this.uranium = 10;
        this.enoughFood = true;
        this.queue = new ArrayList <SpaceMapQueueItem> ();
        this.foodTech = 0;
        this.moneyTech = 0;
        this.industryTech = 0;
        this.metalTech = 0;
        this.spaceTech = 0;
        this.attackTech = 0;
        this.defenseTech = 0;
        this.growthRate = 0;
        this.leaders = new ArrayList<SpaceMapPolitician> ();
        
        this.bonuses = new double[10];
        for (short i = 0; i < 16; i++)
        {
            this.leaders.add(new SpaceMapPolitician(leaderNames.remove((short)(Math.random()*leaderNames.size()))));
        }
        this.president = this.leaders.remove(0);
        this.vicePresident = this.leaders.remove(0);
        this.commander = this.leaders.remove(0);
        this.subCommander = this.leaders.remove(0);
        this.treasury = this.leaders.remove(0);
        this.foreign = this.leaders.remove(0);
        this.council = this.leaders.remove(0);
        this.science = this.leaders.remove(0);
    }
    
    public void switchPresident(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(president);
            president = leaders.remove(i);
        }
    }
    
    public void switchVicePresident(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(vicePresident);
            vicePresident = leaders.remove(i);
        }
    }
    
    public void switchCommander(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(commander);
            commander = leaders.remove(i);
        }
    }
    
    public void switchSubCommander(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(subCommander);
            subCommander = leaders.remove(i);
        }
    }
    
    public void switchTreasury(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(treasury);
            treasury = leaders.remove(i);
        }
    }
    
    public void switchForeign(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(foreign);
            foreign = leaders.remove(i);
        }
    }
    
    public void switchCouncil(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(council);
            council = leaders.remove(i);
        }
    }
    
    public void switchScience(short i)
    {
        if(i < leaders.size())
        {
            leaders.add(science);
            science = leaders.remove(i);
        }
    }
    
    public String getParasites()
    {
        String string = "Availible Politicians:\n";
        for(short i = 0; i < leaders.size(); i++)
        {
            string = string + "At position " + i + " we have " + leaders.get(i).getName() + "\n";
        }
        return string;
    }
    
    public String president()
    {
        return president.toString((short)0);
    }
    
    public String vicePresident()
    {
        return vicePresident.toString((short)1);
    }
    
    public String commander()
    {
        return commander.toString((short)2);
    }
    
    public String subCommander()
    {
        return subCommander.toString((short)3);
    }
    
    public String treasury()
    {
        return treasury.toString((short)4);
    }
    
    public String foreign()
    {
        return foreign.toString((short)5);
    }
    
    public String council()
    {
        return council.toString((short)6);
    }
    
    public String science()
    {
        return science.toString((short)7);
    }
    
    public void updateBonuses()
    {
        bonuses = new double[9];
        double[] p = new double[9];
        double[] vp = new double[9];
        double[] com = new double[9];
        double[] sc = new double[9];
        double[] t = new double[9];
        double[] f = new double[9];
        double[] c = new double[9];
        double[] s = new double[9];
        p = president.getBonusAndPenaltyPresident();
        vp = vicePresident.getBonusAndPenaltyPresident();
        com = commander.getBonusAndPenaltyCommander();
        sc = subCommander.getBonusAndPenaltyCommander();
        t = treasury.getBonusAndPenaltyTreasury();
        f = foreign.getBonusAndPenaltySeatHolder();
        c = council.getBonusAndPenaltySeatHolder();
        s = science.getBonusAndPenaltyScience();
        for(short i = 0; i < 9; i++)
        {
            bonuses[i] = p[i] + (vp[i]/2) + com[i] + (sc[i]/2) + t[i] + f[i] + (c[i]/1.5) + (s[i]/4);
        }
    }
    
    public double[] getBonuses()
    {
        return bonuses;
    }
    
    public double getUranium()
    {
        return uranium;
    }
    
    public double getTitanium()
    {
        return titanium;
    }
    
    public double getPromethium()
    {
        return promethium;
    }
    
    public void spendRares(double [] d)
    {
        uranium = uranium -d[0];
        titanium = titanium - d[1];
        promethium = promethium -d[2];
    }
    
    public void addEnemy(SpaceMapPlayer p)
    {
        enemies.add(p);
    }
    
    public SpaceMapPlanet removePlanet(String name)
    {
        for (short i = 0; i < planets.size(); i++)
        {
            if(planets.get(i).getName().equals(name))
            {
                return planets.remove(i);
            }
        }
        return null;
    }
    
    public void addPlanet(SpaceMapPlanet p)
    {
        if (p == null)
        {
            
        }
        else
        {
            planets.add(p);
        }
        
    }
    
    public void setGrowthRate(double d)
    {
        growthRate = d;
        if(growthRate > 2.5)
        {
            growthRate = 2.5;
        }
        else if(growthRate < -90)
        {
            growthRate = -90;
        }
    }
    
    public void changePopulation()
    {
        for(short i = 0; i < planets.size();i++)
        {
            planets.get(i).adjustPopulation(growthRate);
        }
    }
    
    public double[] getWeights()
    {
        return new double[] {foodWeight, metalWeight, industryWeight, uraniumWeight, titaniumWeight, promethiumWeight};
    }
    
    public boolean enoughFood()
    {
        return enoughFood;
    }
    
    public String getDescription()
    {
        String govType = "";
        String forGovType = "";
        String econGovType = "";
        if (gov == 1)
        {
            govType = "Communist";
        }
        else if(gov == 2)
        {
            govType = "Federal Republic";
        }
        else if(gov == 3)
        {
            govType = "Monarchy";
        }
        else if(gov == 4)
        {
            govType = "Confederation";
        }
        else if(gov == 5)
        {
            govType = "Fascist";
        }
        else
        {
            govType = "Oligarchy";
        }
        if (econGov == 1)
        {
            econGovType = "Government Control of Industry";
        }
        else if(econGov == 2)
        {
            econGovType = "Government and Private Cooperative Control of Industry";
        }
        else
        {
            econGovType = "Private Control of Industry";
        }
        if (forGov == 1)
        {
            forGovType = "Expansive";
        }
        else if(forGov == 2)
        {
            forGovType = "Defensive";
        }
        else if(forGov == 3)
        {
            forGovType = "Trade Oriented";
        }
        else if(forGov == 4)
        {
            forGovType = "Peaceful Coexistence Oriented";
        }
        else
        {
            forGovType = "Colony Focused";
        }
        return name + "'s turn:\n" + "Government Type: " + govType + "\nEconomic Policy: " + 
        econGovType + "\nForeign Policy: " +  forGovType + "\nCurrent Population: " + getPopulation() 
        + "\nCurrent Food: " + Math.round(food) + "\nCurrent Money: " + Math.round(money) + "\nCurrent Metal: "
        + Math.round(metal) + "\nCurrent Industry: " + Math.round(industry) + "\nCurrent Uranium: " + Math.round(uranium)
        + "\nCurrent Titanium: " + Math.round(titanium) + "\nCurrent Promethium: " + Math.round(promethium) + "\nGrowth Rate: " + growthRate + "%";            
    }
    
    public String getResourcesForLabel()
    {
        return name + ", Current Population: " + getPopulation() + ", Current Food: " + Math.round(food) + ", Current Money: " + Math.round(money) + ", Current Metal: " + Math.round(metal) + 
        ",\nCurrent Industry: " + Math.round(industry) + ",Current Uranium: " + Math.round(uranium) + ", Current Titanium: " + Math.round(titanium) + ", Current Promethium: " + Math.round(promethium);  
    }
    
    public boolean usesBothCapitals()
    {
        return usesBothCapitals;
    }
    
    public int getPopulation()
    {
        int population = 0;
        for(short i = 0; i < planets.size();i++)
        {
            population = population + planets.get(i).getPopulation();
        }
        return population;
    }
    
    public SpaceMapPlanet getCapital()
    {
        return capital;
    }
    
    public SpaceMapPlanet getAlternateCapital()
    {
        return alternateCapital;
    }
    
    public void setCapital(SpaceMapPlanet p)
    {
        capital = p;
    }
    
    public boolean capitalCheck()
    {
        if (capital == alternateCapital)
        {
            return true;
        }
        return false;
    }
    
    public void setAlternateCapital(SpaceMapPlanet p)
    {
        alternateCapital = p;
    }
    
    public ArrayList <SpaceMapPlanet> getPlanets()
    {
        return planets;
    }
    
    public ArrayList <SpaceMapPlayer> getEnemies()
    {
        return enemies;
    }
    
    public ArrayList <SpaceMapPlayer> getAllies()
    {
        return allies;
    }
    
    public ArrayList <SpaceMapPlayer> getFreePassages()
    {
        return freePassages;
    }
    
    public ArrayList <SpaceMapPlayer> getVassals()
    {
        return vassals;
    }
    
    public ArrayList <SpaceMapPlayer> getPuppets()
    {
        return puppets;
    }

    public String getName()
    {
        return name;
    }
    
    
    
    public boolean checkResources(double[] foodIndustryMetalMoney)
    {
        if(food > foodIndustryMetalMoney[0] && industry > foodIndustryMetalMoney[1] && metal > foodIndustryMetalMoney[2]&& money > foodIndustryMetalMoney[3])
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void spendResources(double[] foodIndustryMetalMoney)
    {
        food = food - foodIndustryMetalMoney[0];
        industry = industry - foodIndustryMetalMoney[1];
        metal = metal - foodIndustryMetalMoney[2];
        money = money - foodIndustryMetalMoney[3];        
    }
    
    public String getRares()
    {
        return name + "\nCurrent Uranium: " + Math.round(uranium) + ",\nCurrent Titanium: " + Math.round(titanium) + ",\nCurrent Promethium: " + Math.round(promethium);
    }
    
    public short getAttackTech()
    {
        return attackTech;
    }
    
    public short getDefenseTech()
    {
        return defenseTech;
    }
    
    public int getCulture()
    {
        return culture;
    }
    
    public int getGov()
    {
        return gov;
    }
    
    public int getEconGov()
    {
        return econGov;
    }
    
    public int getForGov()
    {
        return forGov;
    }
    
    public void emptyQueue()
    {
        for(int i = queue.size()-1;i>=0;i--)
        {
            queue.remove(i);
        }
    }
    
    public void cancelQueueItem(short i)
    {
        if (queue.size() > i)
        {
            queue.remove(i);
        }
    }
    
    public void runThroughQueue()
    {
        while(true)
        {
            if (queue.size() < 1)
            {
                break;
            }
            else if(checkResources(queue.get(0).cost()))
            {
                spendResources(queue.get(0).cost());
                queue.remove(0).complete();
            }
            else
            {
                break;
            }
        }
    }
    
    public void addQueueItem(SpaceMapPlanet p, short actionType)
    {
        if(actionType < 9)
        {
            queue.add(new SpaceMapQueueItem(p.getBuildingCost(),p,actionType));
        }
        else if (actionType == 9)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,800,800,1000},p,actionType));
        }
        else if (actionType == 10)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,1000,1000,1300},p,actionType));
        }
        else if (actionType == 11)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,1700,1700,2500},p,actionType));
        }
        else if (actionType == 12)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,2750,2750,3500},p,actionType));
        }
        
        else if (actionType == 13)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,2750,2750,3500},p,actionType));
        }
        else if (actionType == 14)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,3200,3200,4000},p,actionType));
        }
        else if (actionType == 15)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,3600,3600,4500},p,actionType));
        }
        else if (actionType == 16)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,4000,4000,5000},p,actionType));
        }
        else if (actionType == 17)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,5000,5000,6250},p,actionType));
        }
        else if (actionType == 18)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,5600,5600,7200},p,actionType));
        }
        else if (actionType == 19)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,2500,2500,3100},p,actionType));
        }
        else if (actionType == 20)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,4900,4900,6100},p,actionType));
        }
        else if (actionType == 21)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,8000,8000,10000},p,actionType));
        }
        else if (actionType == 22)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,11500,11500,14500},p,actionType));
        }
        else if (actionType == 23)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,14500,14500,18000},p,actionType));
        }
        else if (actionType == 24)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,16000,16000,20000},p,actionType));
        }
        else if (actionType == 25)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,18000,18000,22500},p,actionType));
        }
        else if (actionType == 26)
        {
            queue.add(new SpaceMapQueueItem(new double[] {0,800,800,1000},p,actionType));
        }
    }
    
    public void endTurnStuff()
    {
        updateBonuses();
        double foodHolder = food;
        getStuff();               
        runThroughQueue();
        engageFleets();
        doUpkeep();
        repairs();
        changePopulation();
        if (queue.size() == 0)
        {
            //industry
            if(enoughFood)
            {
                double r1 = Math.random() + .15;
                double r2 = Math.random() + .05;
                double t = r1 + r2;
                food = food + (r1*industry/(t*2));
                metal = metal + (r2*industry/(t*2));
            }
            else
            {
                double r1 = Math.random() + .45;
                double r2 = Math.random() + .05;
                double t = r1 + r2;
                food = food + (r1*industry/t);
                metal = metal + (r2*industry/t);
            }
            industry = 0;
        }
        if(foodHolder > food)
        {
            enoughFood = false;
        }
        else
        {
            enoughFood = true;
        }
        
    }
    
    public void repairs()
    {
        for(short i = 0; i < planets.size();i++)
        {
            planets.get(i).repairs();
        }
    }
    
    public void doUpkeep()
    {
        double[] stuff = new double[4];
        double[] holder = new double[4];
        for(short i = 0; i < planets.size();i++)
        {
            holder = planets.get(i).getCost();
            for (short j = 0; j < holder.length; j++)
            {
                stuff[j] = stuff[j] + holder[j];
            }
        }
        food = food - stuff[0];
        money = money - stuff[3];
    }
    
    public void reintegrateShips()
    {
        for(short i = 0; i < planets.size();i++)
        {
            planets.get(i).reintegrateShips();
        }
    }
    
    public void getStuff()
    {
        double[] stuff = new double[7];
        double[] holder = new double[7];
        int population = 0;
        for(short i = 0; i < planets.size();i++)
        {
            population = population + planets.get(i).getPopulation();
            holder = planets.get(i).getStuff();
            for (short j = 0; j < holder.length; j++)
            {
                stuff[j] = stuff[j] + holder[j];
            }
        }
        double t = population*.1;            
        double[] resSpread = new double[3];           
        double h;        
        double ran = 0;
        int populationLeft = population;
        for(int i = 0; i < population; i++)
        {
            if(Math.random() < .0001)
            {
                populationLeft --;
                if (Math.random() < .334)
                {
                    stuff[4] = stuff[4] + .01;
                }
                else if(Math.random() < .5)
                {
                    stuff[5] = stuff[5] + .01;
                }
                else
                {
                    stuff[6] = stuff[6] + .01;
                }
            }
        }
        h = Math.random(); 
        if (enoughFood())
        {
            resSpread[0] = h + .03; 
            ran = ran + h + .03;   
        }
        else
        {
            resSpread[0] = h + .05;
            ran = ran + h + .05;
        }
             
            for (int i = 1; i < 3;i++)
            {
                h = Math.random();      
                resSpread[i] = h + .01;
                ran = ran + h + .01;           
            }            
            for(int i = 0; i < 3;i++)
            {
                stuff[i] = stuff[i] + populationLeft*.1*resSpread[i]/ran;            
            }
            stuff[3] = stuff[3] + t;
        food = food + (stuff[0]*Math.pow(1.1,foodTech)*1.05*(1+bonuses[0])*(1+bonuses[4]));
        metal = metal + (stuff[1]*Math.pow(1.1,metalTech)*(1+bonuses[1])*(1+bonuses[4]));       
        industry = industry + (stuff[2]*Math.pow(1.1,industryTech)*(1+bonuses[2])*(1+bonuses[4]));
        money = money + (stuff[3]*Math.pow(1.1,moneyTech)*(1+bonuses[3])*(1+bonuses[4]));
        uranium = uranium + (stuff[4]*Math.pow(1.05,metalTech)*(1+bonuses[1]));
        titanium = titanium + (stuff[5]*Math.pow(1.05,metalTech)*(1+bonuses[1]));
        promethium = promethium + (stuff[6]*Math.pow(1.05,metalTech)*(1+bonuses[1]));
    }
    
    public void engageFleets()
    {
        for(short i = (short)(planets.size()-1);i >= 0; i--)
        {
            planets.get(i).engageFleets();
        }        
    }
    
    public String getQueue()
    {
        String string = "";
        if(queue.size() > 0)
        {
            string = string + "Item: " + 1 + " " + queue.get(0).toString() + ", ";
        }   
        for (short i = 1; i < queue.size(); i++)
        {
            if (i%3 == 0 && i != 0)
            {
                string = string + "\n";
            }
            string = string + "Item: " + i + " " + queue.get(i).toString() + ", "; //+"\n";          
        }
        if (string.length() > 5)
        {
            return string.substring(0, string.length()-2);
        }
        else
        {
            return "";
        }
    }
    
        public int getFoodResearchCost()
        {
            return 25000*(int)(Math.pow(2,foodTech));
        }
    
        public int getMetalResearchCost()
        {
            return 25000*(int)(Math.pow(2,metalTech));
        }
        
        public int getIndustryResearchCost()   
        {
            return 25000*(int)(Math.pow(2,industryTech));
        } 
        
        public int getMoneyResearchCost()  
        {
            return 25000*(int)(Math.pow(2,moneyTech));
        }   
        
        public int getShieldsResearchCost()   
        {
            return 25000*(int)(Math.pow(2,defenseTech));
        }
        
        public int getWeaponsResearchCost()
        {
            return 25000*(int)(Math.pow(2,attackTech));
        }
        
        public void researchFoodTech()
        {
            if (money > getFoodResearchCost())
            {
                money = money - getFoodResearchCost();
                foodTech++;
            }
        }
        
        public void researchMetalTech()
        {
            if (money > getMetalResearchCost())
            {
                money = money - getMetalResearchCost();
                metalTech++;
            }
        }
        
        public void researchIndustryTech()
        {
            if (money > getIndustryResearchCost())
            {
                money = money - getIndustryResearchCost();
                industryTech++;
            }
        }
        
        public void researchMoneyTech()
        {
            if (money > getMoneyResearchCost())
            {
                money = money - getMoneyResearchCost();
                moneyTech++;
            }
        }
        
        public void researchDefenseTech()
        {
            if (money > getShieldsResearchCost())
            {
                money = money - getShieldsResearchCost();
                defenseTech++;
            }
        }
        
        public void researchAttackTech()
        {
            if (money > getWeaponsResearchCost())
            {
                money = money - getWeaponsResearchCost();
                attackTech++;
            }
        }
}


