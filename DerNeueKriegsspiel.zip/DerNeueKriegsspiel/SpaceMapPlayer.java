import java.util.ArrayList;
/**
 * Write a description of class SpaceMapPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPlayer
{
    private String name;
    public int culture; 
    private int gov;
    private int econGov;
    private int forGov;
    private int foodTech;
    private int moneyTech;
    private int industryTech;
    private int metalTech;
    private int spaceTech;
    private int attackTech;
    private int defenseTech;
    private double food;
    private double money;
    private double metal;
    private double industry;
    private ArrayList <SpaceMapPlanet> planets;
    private ArrayList <SpaceMapPlayer> freePassages;
    private ArrayList <SpaceMapPlayer> enemies;
    private ArrayList <SpaceMapPlayer> vassals;
    private ArrayList <SpaceMapPlayer> puppets;
    private ArrayList <SpaceMapPlayer> allies;
    private SpaceMapPlayer vassalLord;
    private SpaceMapPlayer puppetMaster;
    private SpaceMapPlanet capital;
    private SpaceMapPlanet alternateCapital;
    private boolean usesBothCapitals;

    /**
     * Constructor for objects of class SpaceMapPlayer
     */
    public SpaceMapPlayer(String name, int culture, int gov, int econGov, int forGov, boolean usesBothCapitals)
    {
        this.name = name;
        this.culture = culture;
        this.gov = gov;
        this.econGov = econGov;
        this.forGov = forGov;
        this.usesBothCapitals = usesBothCapitals;
        this.planets = new ArrayList <SpaceMapPlanet> ();
        this.freePassages = new ArrayList <SpaceMapPlayer> ();
        this.enemies = new ArrayList <SpaceMapPlayer> ();
        this.vassals = new ArrayList <SpaceMapPlayer> ();
        this.puppets = new ArrayList <SpaceMapPlayer> ();
        this.allies = new ArrayList <SpaceMapPlayer> ();
        this.food = 1500000000;
        this.money = 1000000000;
        this.metal = 10000;
        this.industry = 10000;
        
    }
    
    public String getDescription()
    {
        String govType = "";
        String forGovType = "";
        String econGovType = "";
        if (gov == 1)
        {
            govType = "Communist";
        }
        else if(gov == 2)
        {
            govType = "Federal Republic";
        }
        else if(gov == 3)
        {
            govType = "Monarchy";
        }
        else if(gov == 4)
        {
            govType = "Confederation";
        }
        else if(gov == 5)
        {
            govType = "Fascist";
        }
        else
        {
            govType = "Oligarchy";
        }
        if (econGov == 1)
        {
            econGovType = "Government Control of Industry";
        }
        else if(econGov == 2)
        {
            econGovType = "Government and Private Cooperative Control of Industry";
        }
        else
        {
            econGovType = "Private Control of Industry";
        }
        if (forGov == 1)
        {
            forGovType = "Expansive";
        }
        else if(forGov == 2)
        {
            forGovType = "Defensive";
        }
        else if(forGov == 3)
        {
            forGovType = "Trade Oriented";
        }
        else if(forGov == 4)
        {
            forGovType = "Peaceful Coexistence Oriented";
        }
        else
        {
            forGovType = "Colony Focused";
        }
        return name + "'s turn:\n" + "Government Type: " + govType + "\nEconomic Policy: " + econGovType + "\nForeign Policy: " +  forGovType + "\nCurrent Food: " + Math.round(food) + "\nCurrent Money: " + Math.round(money) + "\nCurrent Metal: " + Math.round(metal) + "\nCurrent Industry: " + Math.round(industry);            
    }
    
    public boolean usesBothCapitals()
    {
        return usesBothCapitals;
    }
    
    public void addPlanet(SpaceMapPlanet p)
    {
        planets.add(p);
    }
    
    public SpaceMapPlanet getCapital()
    {
        return capital;
    }
    
    public SpaceMapPlanet getAlternateCapital()
    {
        return alternateCapital;
    }
    
    public void setCapital(SpaceMapPlanet p)
    {
        capital = p;
    }
    
    public boolean capitalCheck()
    {
        if (capital == alternateCapital)
        {
            return true;
        }
        return false;
    }
    
    public void setAlternateCapital(SpaceMapPlanet p)
    {
        alternateCapital = p;
    }
    
    public ArrayList <SpaceMapPlanet> getPlanets()
    {
        return planets;
    }
    
    public ArrayList <SpaceMapPlayer> getEnemies()
    {
        return enemies;
    }
    
    public ArrayList <SpaceMapPlayer> getAllies()
    {
        return allies;
    }
    
    public ArrayList <SpaceMapPlayer> getFreePassages()
    {
        return freePassages;
    }
    
    public ArrayList <SpaceMapPlayer> getVassals()
    {
        return vassals;
    }
    
    public ArrayList <SpaceMapPlayer> getPuppets()
    {
        return puppets;
    }

    public String getName()
    {
        return name;
    }
    
    public boolean checkResources(int[] foodIndustryMetalMoney)
    {
        if(food > foodIndustryMetalMoney[0] && industry > foodIndustryMetalMoney[1] && metal > foodIndustryMetalMoney[2]&& money > foodIndustryMetalMoney[3])
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void spendResources(int[] foodIndustryMetalMoney)
    {
        food = food - foodIndustryMetalMoney[0];
        industry = industry - foodIndustryMetalMoney[1];
        metal = metal - foodIndustryMetalMoney[2];
        money = money - foodIndustryMetalMoney[3];        
    }
    
    public int getAttackTech()
    {
        return attackTech;
    }
    
    public int getCulture()
    {
        return culture;
    }
    
    public int getGov()
    {
        return gov;
    }
    
    public int getEconGov()
    {
        return econGov;
    }
    
    public int getForGov()
    {
        return forGov;
    }
}
