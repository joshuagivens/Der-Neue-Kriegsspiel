import java.util.ArrayList;
/**
 * Write a description of class SpaceMapPlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPlayer
{
    private String name;
    public int culture; 
    private int gov;
    private int econGov;
    private int forGov;
    private int foodTech;
    private int moneyTech;
    private int industryTech;
    private int metalTech;
    private int spaceTech;
    private int attackTech;
    private int defenseTech;
    private int food;
    private int money;
    private int metal;
    private int industry;
    private ArrayList <SpaceMapPlanet> planets;
    private ArrayList <SpaceMapPlayer> freePassages;
    private ArrayList <SpaceMapPlayer> enemies;
    private ArrayList <SpaceMapPlayer> vassals;
    private ArrayList <SpaceMapPlayer> puppets;
    private ArrayList <SpaceMapPlayer> allies;
    private SpaceMapPlayer vassalLord;
    private SpaceMapPlayer puppetMaster;
    private SpaceMapPlanet capital;
    private SpaceMapPlanet alternateCapital;
    private boolean usesBothCapitals;

    /**
     * Constructor for objects of class SpaceMapPlayer
     */
    public SpaceMapPlayer(String name, int culture, int gov, int econGov, int forGov, boolean usesBothCapitals)
    {
        this.name = name;
        this.culture = culture;
        this.gov = gov;
        this.econGov = econGov;
        this.forGov = forGov;
        this.usesBothCapitals = usesBothCapitals;
        this.planets = new ArrayList <SpaceMapPlanet> ();
        this.freePassages = new ArrayList <SpaceMapPlayer> ();
        this.enemies = new ArrayList <SpaceMapPlayer> ();
        this.vassals = new ArrayList <SpaceMapPlayer> ();
        this.puppets = new ArrayList <SpaceMapPlayer> ();
        this.allies = new ArrayList <SpaceMapPlayer> ();
    }
    
    public boolean usesBothCapitals()
    {
        return usesBothCapitals;
    }
    
    public void addPlanet(SpaceMapPlanet p)
    {
        planets.add(p);
    }
    
    public SpaceMapPlanet getCapital()
    {
        return capital;
    }
    
    public SpaceMapPlanet getAlternateCapital()
    {
        return alternateCapital;
    }
    
    public void setCapital(SpaceMapPlanet p)
    {
        capital = p;
    }
    
    public boolean capitalCheck()
    {
        if (capital == alternateCapital)
        {
            return true;
        }
        return false;
    }
    
    public void setAlternateCapital(SpaceMapPlanet p)
    {
        alternateCapital = p;
    }
    
    public ArrayList <SpaceMapPlanet> getPlanets()
    {
        return planets;
    }
    
    public ArrayList <SpaceMapPlayer> getEnemies()
    {
        return enemies;
    }
    
    public ArrayList <SpaceMapPlayer> getAllies()
    {
        return allies;
    }
    
    public ArrayList <SpaceMapPlayer> getFreePassages()
    {
        return freePassages;
    }
    
    public ArrayList <SpaceMapPlayer> getVassals()
    {
        return vassals;
    }
    
    public ArrayList <SpaceMapPlayer> getPuppets()
    {
        return puppets;
    }

    public String getName()
    {
        return name;
    }
    
    public boolean checkResources(int[] foodIndustryMetalMoney)
    {
        if(food > foodIndustryMetalMoney[0] && industry > foodIndustryMetalMoney[1] && metal > foodIndustryMetalMoney[2]&& money > foodIndustryMetalMoney[3])
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void spendResources(int[] foodIndustryMetalMoney)
    {
        food = food - foodIndustryMetalMoney[0];
        industry = industry - foodIndustryMetalMoney[1];
        metal = metal - foodIndustryMetalMoney[2];
        money = money - foodIndustryMetalMoney[3];        
    }
    
    public int getAttackTech()
    {
        return attackTech;
    }
    
    public int getCulture()
    {
        return culture;
    }
    
    public int getGov()
    {
        return gov;
    }
    
    public int getEconGov()
    {
        return econGov;
    }
    
    public int getForGov()
    {
        return forGov;
    }
}
