import java.util.*;
/**
 * Write a description of class SpaceMapPolitician here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPolitician
{
    String name;
    SpaceMapPoliticianBonus president;
    SpaceMapPoliticianBonus seatHolder;
    SpaceMapPoliticianBonus treasury;
    SpaceMapPoliticianBonus commander;
    SpaceMapPoliticianBonus science;
    
    
    /**
     * Constructor for objects of class SpaceMapPolitician
     */
    public SpaceMapPolitician(String name)
    {
        this.name = name;
        // food, mining, industry, money, general production, combat, defense, diplomacy, influence
        
               this.president = new SpaceMapPoliticianBonus((short)(Math.random()*9),(short)(Math.random()*9));
              
        
        
               if (Math.random() > .5)
               {
                   if (Math.random() > .5)
                   {
                       this.seatHolder = new SpaceMapPoliticianBonus((short)(7),(short)(8));
                   }
                   else
                   {
                       this.seatHolder = new SpaceMapPoliticianBonus((short)(7),(short)(7));
                   }
                   
               }
               else
               {
                   if (Math.random() > .5)
                   {
                       this.seatHolder = new SpaceMapPoliticianBonus((short)(8),(short)(8));
                   }
                   else
                   {
                       this.seatHolder = new SpaceMapPoliticianBonus((short)(8),(short)(7));
                   }
                   //this.seatHolder = new SpaceMapPoliticianBonus((short)(8),(short)(7));
               }
               
               if (Math.random() > .5)
               {
                   if (Math.random() > .5)
                   {
                       this.treasury = new SpaceMapPoliticianBonus((short)(3),(short)(3));
                   }
                   else
                   {
                       this.treasury = new SpaceMapPoliticianBonus((short)(3),(short)(4));
                   }
                   //this.treasury = new SpaceMapPoliticianBonus((short)(3),(short)(4));
               }
               else
               {
                   if (Math.random() > .5)
                   {
                       this.treasury = new SpaceMapPoliticianBonus((short)(4),(short)(3));
                   }
                   else
                   {
                       this.treasury = new SpaceMapPoliticianBonus((short)(4),(short)(4));
                   }
                   //this.treasury = new SpaceMapPoliticianBonus((short)(4),(short)(3));
               }
               
               if (Math.random() > .5)
               {
                   if (Math.random() > .5)
                   {
                       this.commander = new SpaceMapPoliticianBonus((short)(5),(short)(5));
                   }
                   else
                   {
                       this.commander = new SpaceMapPoliticianBonus((short)(5),(short)(6));
                   }
                   //this.commander = new SpaceMapPoliticianBonus((short)(5),(short)(6));
               }
               else
               {
                   if (Math.random() > .5)
                   {
                       this.commander = new SpaceMapPoliticianBonus((short)(6),(short)(5));
                   }
                   else
                   {
                       this.commander = new SpaceMapPoliticianBonus((short)(6),(short)(6));
                   }
                   //this.commander = new SpaceMapPoliticianBonus((short)(6),(short)(5));
               }
        
               this.science = new SpaceMapPoliticianBonus((short)(Math.random()*7),(short)(Math.random()*7));
                      
               //this.science = new SpaceMapPoliticianBonus((short)(4),(short)(4));           
                   
               //this.science = new SpaceMapPoliticianBonus((short)(4),(short)(9));
               
               
        //same  same
        
        //influence, diplomacy
        
        //money, general production 

        //attack, defense
        
        //science, production
        
        //diplomacy, influence 
        
        //attack, defence 
    }

    public String getName()
    {
        return name;
    }
    
    public double[] getBonusAndPenaltyPresident()
    {
        double[] stuff = new double[9];
        stuff[president.getBonusId()] = stuff[president.getBonusId()] + president.getBonus();
        stuff[president.getPenaltyId()] = stuff[president.getPenaltyId()] - president.getPenalty();
        return stuff;
    }
    
    public double[] getBonusAndPenaltySeatHolder()
    {
        double[] stuff = new double[9];
        stuff[seatHolder.getBonusId()] = stuff[seatHolder.getBonusId()] + seatHolder.getBonus();
        stuff[seatHolder.getPenaltyId()] = stuff[seatHolder.getPenaltyId()] - seatHolder.getPenalty();
        return stuff;
    }     
     
    public double[] getBonusAndPenaltyTreasury()
    {
        double[] stuff = new double[9];
        stuff[treasury.getBonusId()] = stuff[treasury.getBonusId()] + treasury.getBonus();
        stuff[treasury.getPenaltyId()] = stuff[treasury.getPenaltyId()] - treasury.getPenalty();
        return stuff;
    }
    
    public double[] getBonusAndPenaltyCommander()
    {
        double[] stuff = new double[9];
        stuff[commander.getBonusId()] = stuff[commander.getBonusId()] + commander.getBonus();
        stuff[commander.getPenaltyId()] = stuff[commander.getPenaltyId()] - commander.getPenalty();
        return stuff;
    }
    
    public String idFinder(short i)
    {
        if(i == 0)
        {
            return "food";
        }
        else if(i == 1)
        {
            return "metal";
        }
        else if(i == 2)
        {
            return "industry";
        }
        else if(i == 3)
        {
            return "money";
        }
        else if(i == 4)
        {
            return "resources";
        }
        else if(i == 5)
        {
            return "attack";
        }
        else if(i == 6)
        {
            return "defense";
        }
        else if(i == 7)
        {
            return "diplomacy";
        }
        else if(i == 8)
        {
            return "influence";
        }
        else
        {
            return "Error";
        }
    }
    
    public String toString(short i)
    {
        String string = name + ":\n";
        double a = 0;
        double b = 0;
        if(i == 0)
        {
            if(president.getBonusId() == president.getPenaltyId())
            {
                a = president.getBonus() - president.getPenalty();
                if(a >= 0)
                {
                    string = string + "+" + ((double)(Math.round(a*10000))/100) + "% " + idFinder(president.getBonusId());
                }
                else
                {
                    string = string + ((double)(Math.round(a*10000))/100) + "% " + idFinder(president.getPenaltyId());
                }
            }
            else
            {
                a = president.getBonus();
                b = (-1)*president.getPenalty();
                
                    string = string + "+" + ((double)(Math.round(a*1000))/10) + "% " + idFinder(president.getBonusId()) + "\n";
                
                    string = string + ((double)(Math.round(b*1000))/10) + "% " + idFinder(president.getPenaltyId());
                
            }
        }
        else if(i == 1)
        {
            if(president.getBonusId() == president.getPenaltyId())
            {
                a = president.getBonus() - president.getPenalty();
                if(a >= 0)
                {
                    string = string + "+" + (((double)(Math.round(a*10000))/100)/2) + "% " + idFinder(president.getBonusId());
                }
                else
                {
                    string = string + (((double)(Math.round(a*10000))/100)/2) + "% " + idFinder(president.getPenaltyId());
                }
            }
            else
            {
                a = president.getBonus();
                b = (-1)*president.getPenalty();
                
                    string = string + "+" + (((double)(Math.round(a*10000))/100)/2) + "% " + idFinder(president.getBonusId()) + "\n";
                
                    string = string + (((double)(Math.round(b*10000))/100)/2) + "% " + idFinder(president.getPenaltyId());
                
            }
        }
        
        else if(i == 2)
        {
            if(commander.getBonusId() == commander.getPenaltyId())
            {
                a = commander.getBonus() - commander.getPenalty();
                if(a >= 0)
                {
                    string = string + "+" + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(commander.getBonusId());
                }
                else
                {
                    string = string + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(commander.getPenaltyId());
                }
            }
            else
            {
                a = commander.getBonus();
                b = (-1)*commander.getPenalty();
                
                    string = string + "+" + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(commander.getBonusId()) + "\n";
                
                    string = string + (((double)(Math.round(b*10000))/100)) + "% " + idFinder(commander.getPenaltyId());
                
            }
        }
        else if(i == 3)
        {
            if(commander.getBonusId() == commander.getPenaltyId())
            {
                a = commander.getBonus() - commander.getPenalty();
                if(a >= 0)
                {
                    string = string + "+" + (((double)(Math.round(a*10000))/100)/2) + "% " + idFinder(commander.getBonusId());
                }
                else
                {
                    string = string + (((double)(Math.round(a*10000))/100)/2) + "% " + idFinder(commander.getPenaltyId());
                }
            }
            else
            {
                a = commander.getBonus();
                b = (-1)*commander.getPenalty();
                
                    string = string + "+" + (((double)(Math.round(a*10000))/100)/2) + "% " + idFinder(commander.getBonusId()) + "\n";
                
                    string = string + (((double)(Math.round(b*10000))/100)/2) + "% " + idFinder(commander.getPenaltyId());
                
            }
        }
        else if(i == 4)
        {
            if(treasury.getBonusId() == treasury.getPenaltyId())
            {
                a = treasury.getBonus() - treasury.getPenalty();
                if(a >= 0)
                {
                    string = string + "+" + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(treasury.getBonusId());
                }
                else
                {
                    string = string + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(treasury.getPenaltyId());
                }
            }
            else
            {
                a = treasury.getBonus();
                b = (-1)*treasury.getPenalty();
                
                    string = string + "+" + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(treasury.getBonusId()) + "\n";
                
                    string = string + (((double)(Math.round(b*10000))/100)) + "% " + idFinder(treasury.getPenaltyId());
                
            }
        }
        else if(i == 5 || i == 6)
        {
            if(seatHolder.getBonusId() == seatHolder.getPenaltyId())
            {
                a = seatHolder.getBonus() - seatHolder.getPenalty();
                if(a >= 0)
                {
                    string = string + "+" + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(seatHolder.getBonusId());
                }
                else
                {
                    string = string + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(seatHolder.getPenaltyId());
                }
            }
            else
            {
                a = seatHolder.getBonus();
                b = (-1)*seatHolder.getPenalty();
                
                    string = string + "+" + (((double)(Math.round(a*10000))/100)) + "% " + idFinder(seatHolder.getBonusId()) + "\n";
                
                    string = string + (((double)(Math.round(b*10000))/100)) + "% " + idFinder(seatHolder.getPenaltyId());
                
            }
        }
        else if(i == 7)
        {
            if(science.getBonusId() == science.getPenaltyId())
            {
                a = science.getBonus() - science.getPenalty();
                if(a >= 0)
                {
                    string = string + "+" + (((double)(Math.round(a*10000))/100)/4) + "% " + idFinder(science.getBonusId());
                }
                else
                {
                    string = string + (((double)(Math.round(a*10000))/100)/4) + "% " + idFinder(science.getPenaltyId());
                }
            }
            else
            {
                a = science.getBonus();
                b = (-1)*science.getPenalty();
                
                    string = string + "+" + (((double)(Math.round(a*10000))/100)/4) + "% " + idFinder(science.getBonusId()) + "\n";
                
                    string = string + (((double)(Math.round(b*10000))/100)/4) + "% " + idFinder(science.getPenaltyId());
                
            }
        }
        return string;
    } 
    
    public double[] getBonusAndPenaltyScience()
    {
        double[] stuff = new double[9];
        stuff[science.getBonusId()] = stuff[science.getBonusId()] + science.getBonus();
        stuff[science.getPenaltyId()] = stuff[science.getPenaltyId()] - science.getPenalty();
        return stuff;
    }
}
