import java.util.*;
/**
 * Write a description of class SpaceMapPoliticianBonus here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPoliticianBonus
{
    //short id;
    short bonus;
    short penalty;
    float magnitudeBonus;
    float magnitudePenalty;
    /**
     * Constructor for objects of class SpaceMapPoliticianBonus
     */
    public SpaceMapPoliticianBonus(/*short id,*/ short bonus, short penalty)
    {
        //this.id = id;
        this.bonus = bonus;
        this.penalty = penalty;     
        this.magnitudeBonus = (float)(Math.random()/5);
        this.magnitudePenalty = (float)(Math.random()/10);
        if(bonus == 4)
        {
             this.magnitudeBonus = this.magnitudeBonus/4;
        }
        if(penalty == 4)
        {
             this.magnitudePenalty = this.magnitudePenalty/4;
        }
    }

    public short getBonusId()
    {
        return bonus;
    }
    
    public short getPenaltyId()
    {
        return penalty;
    }
    
    public float getBonus()
    {
        return magnitudeBonus;
    }
    
    public float getPenalty()
    {
        return magnitudePenalty;
    }
}
