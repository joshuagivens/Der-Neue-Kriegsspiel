
/**
 * Write a description of class SpaceMapPromethiumMine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapPromethiumMine extends SpaceMapBuilding
{
    

    /**
     * Constructor for objects of class SpaceMapPromethiumMine
     */
    public SpaceMapPromethiumMine()
    {
        
    }

    public double[] getProduction()
    {
        return new double[]{0,0,35,50,0,0,10};
    }
}
