
/**
 * Write a description of class SpaceMapQueueItem here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapQueueItem
{
    public double[] cost;
    SpaceMapPlanet location;
    int actionType; //In this order Farm, Factory, Mine, Trade Center, Uranium Mine, Titanium Mine,
    //Promethium Mine, Defense Battery, Hangar, Corvette, Frigate, Destroyer, Light Cruiser, Medium Cruiser,
    //Heavy Cruiser, Battlecruiser, Battleship, Heavy Battleship, Escort Carrier, Light Carrier,
    //Medium Carrier, Heavy Carrier, Light Capital Ship, Medium Capital Ship, Heavy Capital Ship, 
    //Sector Dominance Ship
    
    /**
     * Constructor for objects of class SpaceMapQueueItem
     */
    public SpaceMapQueueItem(double[] cost, SpaceMapPlanet location, short actionType)
    {
        this.cost = cost;
        this.location = location;
        this.actionType = actionType;
    }

    public double[] cost()
    {
        return cost;
    }
    
    public void complete()
    {
        if(actionType == 0)
        {
            location.buyFarm();
        }
        else if(actionType == 1)
        {
            location.buyFactory();
        }
        else if(actionType == 2)
        {
            location.buyMine();
        }
        else if(actionType == 3)
        {
            location.buyTradeCenter();
        }
        else if(actionType == 4)
        {
            location.buyUraniumMine();
        }
        else if(actionType == 5)
        {
            location.buyTitaniumMine();
        }
        else if(actionType == 6)
        {
            location.buyPromethiumMine();
        }
        else if(actionType == 7)
        {
            location.buyDefenseBattery();
        }
        else if(actionType == 8)
        {
            location.buyHangar();
        }
        else if(actionType == 9)
        {
            location.addCorvette();
        }
        else if(actionType == 10)
        {
            location.addFrigate();
        }
        else if(actionType == 11)
        {
            location.addDestroyer();
        }
        else if(actionType == 12)
        {
            location.addLightCruiser();
        }
        else if(actionType == 13)
        {
            location.addMediumCruiser();
        }
        else if(actionType == 14)
        {
            location.addHeavyCruiser();
        }
        else if(actionType == 15)
        {
            location.addBattlecruiser();
        }
        else if(actionType == 16)
        {
            location.addBattleship();
        }
        else if(actionType == 17)
        {
            location.addHeavyBattleship();
        }
        else if(actionType == 18)
        {
            location.addEscortCarrier();
        }
        else if(actionType == 19)
        {
            location.addLightCarrier();
        }
        else if(actionType == 20)
        {
            location.addMediumCarrier();
        }
        else if(actionType == 21)
        {
            location.addHeavyCarrier();
        }
        else if(actionType == 22)
        {
            location.addLightCapitalShip();
        }
        else if(actionType == 23)
        {
            location.addMediumCapitalShip();
        }
        else if(actionType == 24)
        {
            location.addHeavyCapitalShip();
        }
        else if(actionType == 25)
        {
            location.addSectorDominanceShip();
        }        
        
    }
    
    public String toString()
    {
        String string = "";
        string = string + location.getName();
        if (actionType == 0)
        {
            string = string + " build farm";
        }
        else if(actionType == 1)
        {
            string = string + " build factory";
        }
        else if(actionType == 2)
        {
            string = string + " build mine";
        }
        else if(actionType == 3)
        {
            string = string + " build trade center";
        }
        else if(actionType == 4)
        {
            string = string + " build uranium mine";
        }
        else if(actionType == 5)
        {
            string = string + " build titanium mine";
        }
        else if(actionType == 6)
        {
            string = string + " build promethium mine";
        }
        else if(actionType == 7)
        {
            string = string + " build defense battery";
        }
        else if(actionType == 8)
        {
            string = string + " build hangar";
        }
        else if(actionType == 9)
        {
            string = string + " build corvette";
        }
        else if(actionType == 10)
        {
            string = string + " build frigate";
        }
        else if(actionType == 11)
        {
            string = string + " build destroyer";
        }
        else if(actionType == 12)
        {
            string = string + " build light cruiser";
        }
        else if(actionType == 13)
        {
            string = string + " build medium cruiser";
        }
        else if(actionType == 14)
        {
            string = string + " build heavy cruiser";
        }
        else if(actionType == 15)
        {
            string = string + " build battlecruiser";
        }
        else if(actionType == 16)
        {
            string = string + " build battleship";
        }
        else if(actionType == 17)
        {
            string = string + " build heavy battleship";
        }
        else if(actionType == 18)
        {
            string = string + " build escort carrier";
        }
        else if(actionType == 19)
        {
            string = string + " build light carrier";
        }
        else if(actionType == 20)
        {
            string = string + " build medium carrier";
        }
        else if(actionType == 21)
        {
            string = string + " build heavy carrier";
        }
        else if(actionType == 22)
        {
            string = string + " build light capital ship";
        }
        else if(actionType == 23)
        {
            string = string + " build medium capital ship";
        }
        else if(actionType == 24)
        {
            string = string + " build heavy capital ship";
        }
        else if(actionType == 25)
        {
            string = string + " build sector dominance ship";
        }
        return string;
    }
}
