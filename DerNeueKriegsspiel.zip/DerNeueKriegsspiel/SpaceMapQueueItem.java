
/**
 * Write a description of class SpaceMapQueueItem here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapQueueItem
{
    public double[] cost;
    SpaceMapPlanet location;
    int actionType; //In this order Farm, Factory, Mine, Trade Center, Uranium Mine, Titanium Mine,
    //Promethium Mine, Defense Battery, Hangar, Corvette, Frigate, Destroyer, Light Cruiser, Medium Cruiser,
    //Heavy Cruiser, Battlecruiser, Battleship, Heavy Battleship, Escort Carrier, Light Carrier,
    //Medium Carrier, Heavy Carrier, Light Capital Ship, Medium Capital Ship, Heavy Capital Ship, 
    //Sector Dominance Ship
    
    /**
     * Constructor for objects of class SpaceMapQueueItem
     */
    public SpaceMapQueueItem(double[] cost, SpaceMapPlanet location, short actionType)
    {
        this.cost = cost;
        this.location = location;
        this.actionType = actionType;
    }

    public double[] cost()
    {
        return cost;
    }
    
    public void complete()
    {
        if(actionType == 0)
        {
            location.buyFarm();
        }
        else if(actionType == 1)
        {
            location.buyFactory();
        }
        else if(actionType == 2)
        {
            location.buyMine();
        }
        else if(actionType == 3)
        {
            location.buyTradeCenter();
        }
        else if(actionType == 4)
        {
            location.buyUraniumMine();
        }
        else if(actionType == 5)
        {
            location.buyTitaniumMine();
        }
        else if(actionType == 6)
        {
            location.buyPromethiumMine();
        }
        else if(actionType == 7)
        {
            location.buyDefenseBattery();
        }
        else if(actionType == 8)
        {
            location.buyHangar();
        }
        else if(actionType == 9)
        {
            location.addCorvette();
        }
        else if(actionType == 10)
        {
            location.addFrigate();
        }
        else if(actionType == 11)
        {
            location.addDestroyer();
        }
    }
    
    public String toString()
    {
        String string = "";
        string = string + location.getName();
        if (actionType == 0)
        {
            string = string + " build farm";
        }
        else if(actionType == 1)
        {
            string = string + " build factory";
        }
        else if(actionType == 2)
        {
            string = string + " build mine";
        }
        else if(actionType == 3)
        {
            string = string + " build trade center";
        }
        else if(actionType == 4)
        {
            string = string + " build uranium mine";
        }
        else if(actionType == 5)
        {
            string = string + " build titanium mine";
        }
        else if(actionType == 6)
        {
            string = string + " build promethium mine";
        }
        else if(actionType == 7)
        {
            string = string + " build defense battery";
        }
        else if(actionType == 8)
        {
            string = string + " build hangar";
        }
        else if(actionType == 9)
        {
            string = string + " build corvette";
        }
        else if(actionType == 10)
        {
            string = string + " build frigate";
        }
        else if(actionType == 11)
        {
            string = string + " build destroyer";
        }
        return string;
    }
}
