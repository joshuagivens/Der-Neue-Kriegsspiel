
/**
 * Write a description of class SpaceMapSectorDominanceShip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapSectorDominanceShip extends SpaceMapShip
{
    

    /**
     * Constructor for objects of class SpaceMapSectorDominanceShip
     */
    public SpaceMapSectorDominanceShip()
    {
        this.shipType = /*"Sector */"Dominance Ship";
        this.size = 12;
        this.carrierCapacity = 300;
        this.moneyCost = 27000;
        this.metalCost = 22500;
        this.industryCost = 22500;
        this.baseHealth = 750;
        this.baseAttack = 300;
        this.baseDefense = 200;
        this.health = baseHealth;
    }

    
}
