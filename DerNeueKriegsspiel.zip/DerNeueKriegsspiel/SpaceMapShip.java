import java.util.ArrayList;
/**
 * Write a description of class SpaceMapShip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class SpaceMapShip
{
    public String name;
    public String shipType;
    public short fighters;
    public short people;
    public short size;
    public short carrierCapacity;
    public static short moneyCost;
    public static short metalCost;
    public static short industryCost;
    public short baseHealth;
    public short baseAttack;
    public short baseDefense;
    public double health;
    public boolean hasTitanium;
    public boolean hasPromethium;
    public boolean hasUranium;
    /**
     * Constructor for objects of class SpaceMapShip
     */
    public SpaceMapShip()
    {
        ArrayList <String> planetNames = new ArrayList <String> ();
        
        planetNames.add("Bismarck");
        planetNames.add("Regensburg");        
        planetNames.add("Herr Schreiber");        
        planetNames.add("Hörmansdorf");
        planetNames.add("Regensburg");
        planetNames.add("Regensberg");        
        planetNames.add("Bayern");
        planetNames.add("München");        
        planetNames.add("Berlin");
        planetNames.add("Hamburg");
        planetNames.add("Schweinfurt");
        planetNames.add("Frankfurt");
        planetNames.add("Nuremburg");        
        planetNames.add("Dresden");                        
        planetNames.add("Preußen");                
        planetNames.add("Österreich");        
        planetNames.add("Viena");
        planetNames.add("Bern");
        planetNames.add("Zurich");      
        planetNames.add("Hannover");              
        planetNames.add("Sachsen");      
        planetNames.add("Köln");
        planetNames.add("Hesse");
        planetNames.add("Leipzig");
        planetNames.add("Zürich");
        planetNames.add("Brandenburg");
        planetNames.add("Rostock");
        planetNames.add("Bremerhaven");
        planetNames.add("Kiel");
        planetNames.add("Salzburg");
        planetNames.add("Dar es Salaam");       
        planetNames.add("Liechtenstein");
        planetNames.add("Schweizerisch Traum");
        planetNames.add("Einstein");
        planetNames.add("Verwandlung");
        planetNames.add("Vergeltung");
        planetNames.add("Eisenschwert");
        planetNames.add("Rhein");
        planetNames.add("Fredrich der Große");
        planetNames.add("Prinz Eugen");
        planetNames.add("Graf Zepplin");
        planetNames.add("Panzerschiff");
        planetNames.add("Danzig");
        planetNames.add("Königsberg");
        planetNames.add("Holstein");
        planetNames.add("Kampfschiff");
        planetNames.add("Kriegschiff");
        planetNames.add("Schnellboot");
        planetNames.add("Abwehrschiff");
        planetNames.add("Stern Krieger");
        planetNames.add("Ziegschiff");
        planetNames.add("Tirpitz");
        
        //planetNames.add("Givens");
        //planetNames.add("Cairo");
        //planetNames.add("Austria");
        //planetNames.add("Prussia");
        //planetNames.add("Enterprise");
        //planetNames.add("Defiant");
        //planetNames.add("Saxony");
        //planetNames.add("Switzerland");
        //planetNames.add("Munich");
        /*planetNames.add("Pluto");
        planetNames.add("Mars");
        planetNames.add("Mercury");
        planetNames.add("Venus");
        planetNames.add("Earth");
        planetNames.add("Jupiter");
        planetNames.add("Neptune");*/
        
        /*planetNames.add("Leningrad");
        planetNames.add("St. Petersburg");
        planetNames.add("Stalingrad");
        planetNames.add("Moscow");
        planetNames.add("Vladivostok");
        planetNames.add("Egypt");
        planetNames.add("Jordan");*/
        
        /*planetNames.add("Rome");
        planetNames.add("Germany");
        planetNames.add("France");
        planetNames.add("Italy");
        planetNames.add("Paris");
        planetNames.add("Versialles");*/
        
        /*planetNames.add("Copenhagen");
        planetNames.add("Brasilia");
        planetNames.add("Brazil");
        planetNames.add("Brasil");
        planetNames.add("Geneva");
        planetNames.add("Denmark");
        planetNames.add("Norway");
        planetNames.add("Stavanger");
        planetNames.add("Oslo");
        planetNames.add("Stockholm");
        planetNames.add("Sweden");
        planetNames.add("Belgium");
        planetNames.add("Brussels");
        planetNames.add("Quebec");
        planetNames.add("Montreal");
        planetNames.add("Nova Scotia");
        planetNames.add("New Brunswick");
        planetNames.add("Newfoundland");
        planetNames.add("Labrador");
        planetNames.add("Ontario");
        planetNames.add("Ottawa");
        planetNames.add("Toronto");
        planetNames.add("Manitoba");
        planetNames.add("Saskatchewan");
        planetNames.add("British Columbia");
        planetNames.add("Alberta");
        planetNames.add("Vancouver");
        planetNames.add("Edmonton");
        planetNames.add("Calgary");
        planetNames.add("Victoria");
        planetNames.add("Chigago");
        planetNames.add("York");
        planetNames.add("New York");
        planetNames.add("Washington");
        planetNames.add("Spain");
        planetNames.add("Portugal");
        planetNames.add("Lisbon");
        planetNames.add("Madrid");
        planetNames.add("Jacksterdam");
        planetNames.add("Amsterdam");
        planetNames.add("New Amsterdam");
        planetNames.add("Barcalona");
        planetNames.add("Tangiers");
        planetNames.add("Morroco");
        planetNames.add("Algeria");
        planetNames.add("Algiers");
        planetNames.add("Tunis");
        planetNames.add("Tunisia");
        planetNames.add("Carthage");
        planetNames.add("Dallas");
        planetNames.add("Cinncinati");
        planetNames.add("Los Angeles");
        planetNames.add("San Diego");
        planetNames.add("San Francisco");
        planetNames.add("Sacramento");
        planetNames.add("Rocklin");
        planetNames.add("Boise");
        planetNames.add("Las Vegas");
        planetNames.add("Trenton");
        planetNames.add("Albany");
        planetNames.add("Boston");
        planetNames.add("Richmond");
        planetNames.add("Baltimore");
        planetNames.add("St. Louis");
        planetNames.add("Baton Rouge");
        planetNames.add("Montgomery");
        planetNames.add("Dublin");
        planetNames.add("Ireland");
        planetNames.add("England");
        planetNames.add("Wales");
        planetNames.add("Scotland");
        planetNames.add("Britain");
        planetNames.add("Austin");
        planetNames.add("London");
        planetNames.add("Glasgow");
        planetNames.add("Texas");
        planetNames.add("Mexico");
        planetNames.add("New Mexico");
        planetNames.add("Arizona");
        planetNames.add("Phoenix");
        planetNames.add("California");
        planetNames.add("Oregon");
        planetNames.add("Salem");
        planetNames.add("Idaho");
        planetNames.add("Nevada");
        planetNames.add("Utah");
        planetNames.add("Montana");
        planetNames.add("Deseret");
        planetNames.add("Colorado");
        planetNames.add("Florida");
        planetNames.add("Georgia");
        planetNames.add("Azerbajan");
        planetNames.add("Armenia");
        planetNames.add("Maine");
        planetNames.add("Vermont");
        planetNames.add("Massachusetts");
        planetNames.add("Connecticut");
        planetNames.add("New England");
        planetNames.add("Pennsylvania");
        planetNames.add("New Jersey");
        planetNames.add("Virginia");
        planetNames.add("Dakota");
        planetNames.add("Tahoe");
        planetNames.add("Wyoming");
        planetNames.add("Ohio");
        planetNames.add("Delaware");
        planetNames.add("Maryland");
        planetNames.add("Carolina");
        planetNames.add("Tennesee");
        planetNames.add("Memphis");
        planetNames.add("Kansas");
        planetNames.add("Kentucky");
        planetNames.add("Illinois");
        planetNames.add("Puerto Rico");
        planetNames.add("Costa Rica");
        planetNames.add("San Salvador");
        planetNames.add("El Salvador");
        planetNames.add("Managua");
        planetNames.add("Nicaragua");
        planetNames.add("Masaya");
        planetNames.add("Leon");
        planetNames.add("Honduras");
        planetNames.add("Panama");
        planetNames.add("Belize");
        planetNames.add("Guatemala");
        planetNames.add("Indiana");
        planetNames.add("Wisconsin");
        planetNames.add("Michigan");
        planetNames.add("Eire");
        planetNames.add("Erie");
        planetNames.add("Nebraska");
        planetNames.add("Iowa");
        planetNames.add("Mississippi");
        planetNames.add("Minnesota");
        planetNames.add("Alaska");
        planetNames.add("Hawaii");
        planetNames.add("Missouri");
        planetNames.add("Oklahoma");
        planetNames.add("Omaha");
        planetNames.add("Louisiana");
        planetNames.add("New Hampshire");
        planetNames.add("Arkansas");
        planetNames.add("Greenland");
        planetNames.add("Raykjavik");
        planetNames.add("Iceland");
        planetNames.add("Cuba");
        planetNames.add("Havana");
        planetNames.add("Habana");
        planetNames.add("Santo Domingo");
        planetNames.add("Marseille");*/
        
        /*planetNames.add("Grenada");
        planetNames.add("Russia");
        planetNames.add("Moldovia");
        planetNames.add("Romania");
        planetNames.add("Poland");
        planetNames.add("Belorus");
        planetNames.add("Lithuania");
        planetNames.add("Latvia");
        planetNames.add("Finland");
        planetNames.add("Estonia");
        planetNames.add("Kazakhstan");
        planetNames.add("Uzbekistan");
        planetNames.add("Turkmenistan");
        planetNames.add("Korea");
        planetNames.add("Seoul");
        planetNames.add("Pyongyang");
        planetNames.add("Japan");
        planetNames.add("Tokyo");
        planetNames.add("Warsaw");*/
        
        /*planetNames.add("Kaliningrad");
        planetNames.add("Helsinki");
        planetNames.add("Maputo");
        planetNames.add("Mozambique");
        planetNames.add("Alexandria");
        planetNames.add("Libya");
        planetNames.add("Tripoli");
        planetNames.add("Toranto");
        planetNames.add("Greece");
        planetNames.add("Crete");
        planetNames.add("Cyprus");
        planetNames.add("Malta");
        planetNames.add("India");
        planetNames.add("Calcutta");
        planetNames.add("New Delhi");
        planetNames.add("Delhi");
        planetNames.add("Vietnam");
        planetNames.add("Cambodia");
        planetNames.add("Macedonia");
        planetNames.add("Argentina");
        planetNames.add("Chile");
        planetNames.add("Bolivia");
        planetNames.add("Paraguay");
        planetNames.add("Uruguay");
        planetNames.add("Peru");
        planetNames.add("Ecuador");
        planetNames.add("Venezuala");
        planetNames.add("Columbia");
        planetNames.add("Quito");
        planetNames.add("Lima");
        planetNames.add("Santiago");
        planetNames.add("Buanos Aires");
        planetNames.add("Star");
        planetNames.add("Nampa");
        planetNames.add("España");
        planetNames.add("Lebanon");
        planetNames.add("Beirut");
        planetNames.add("Jordan");
        planetNames.add("Amman");*/
        
        /*planetNames.add("Haiti");
        planetNames.add("Sudan");
        planetNames.add("Angola");
        planetNames.add("Africa");
        planetNames.add("America");
        planetNames.add("Europe");
        planetNames.add("Asia");
        planetNames.add("Australia");
        planetNames.add("Austria");
        planetNames.add("Macedonia");
        planetNames.add("Skopje");
        planetNames.add("Bulgaria");
        planetNames.add("Yugoslavia");
        planetNames.add("Serbia");
        planetNames.add("Belgrade");
        planetNames.add("Budapest");
        planetNames.add("Hungary");
        planetNames.add("Belfast");
        planetNames.add("Bucharest");
        planetNames.add("Slovenia");
        planetNames.add("Slovakia");
        planetNames.add("Czechoslovakia");
        planetNames.add("Bohemia");
        planetNames.add("Moravia");
        planetNames.add("Prague");
        planetNames.add("Silesia");
        planetNames.add("Pretoria");
        planetNames.add("Bloemfont");
        planetNames.add("Johannesburg");
        planetNames.add("Guazapa");
        planetNames.add("Beijing");
        planetNames.add("Hanio");
        planetNames.add("Hainan");
        planetNames.add("Taiwan");
        planetNames.add("Honshu");
        planetNames.add("Hokkaido");
        planetNames.add("Kyushu");
        planetNames.add("Mongolia");
        planetNames.add("China");
        planetNames.add("Kyrgyzstan");
        planetNames.add("Tajikistan");
        planetNames.add("Afganistan");
        planetNames.add("Pakistan");
        planetNames.add("Nepal");
        planetNames.add("Oman");
        planetNames.add("Yemen");
        planetNames.add("Qatar");
        planetNames.add("Kuwait");
        planetNames.add("Iraq");
        planetNames.add("Baghdad");
        planetNames.add("Iran");
        planetNames.add("Tehran");*/
        
        /*planetNames.add("Tanzania");
        planetNames.add("Tanganyika");
        planetNames.add("Zanzibar");
        planetNames.add("Kenya");
        planetNames.add("Uganda");
        planetNames.add("Somalia");
        planetNames.add("Ethiopia");
        planetNames.add("Eritrea");
        planetNames.add("Chad");
        planetNames.add("Myanmar");
        planetNames.add("Burma");
        planetNames.add("Thailand");
        planetNames.add("Laos");
        planetNames.add("Malaysia");
        planetNames.add("Indonesia");
        planetNames.add("Singapore");
        planetNames.add("New Guinea");
        planetNames.add("Sri Lanka");
        planetNames.add("Zimbabwe");
        planetNames.add("Congo");
        planetNames.add("Cameroon");
        planetNames.add("Kamerun");
        planetNames.add("Nigeria");
        planetNames.add("Niger");
        planetNames.add("Mali");
        planetNames.add("Mauritania");
        planetNames.add("Svalbard");
        planetNames.add("Karachi");
        planetNames.add("Phnom Penh");
        planetNames.add("Java");
        planetNames.add("Sumatra");
        planetNames.add("Borneo");
        planetNames.add("Celebes");
        planetNames.add("Timor");
        planetNames.add("New Zealand");
        planetNames.add("Manila");
        planetNames.add("Luzon");
        planetNames.add("Jakarta");
        planetNames.add("Guyana");
        planetNames.add("Suriname");
        planetNames.add("Guiana");
        planetNames.add("Ghana");
        planetNames.add("Côte D'Ivoire");
        planetNames.add("Togo");
        planetNames.add("Guinea");
        planetNames.add("Sierra Leone");
        planetNames.add("Liberia");
        planetNames.add("Kabul");
        planetNames.add("Minsk");
        planetNames.add("Kiev");
        planetNames.add("Syria");
        planetNames.add("Damascus");
        planetNames.add("Rio de Janeiro");
        planetNames.add("Bangkok");
        planetNames.add("Fiji");
        planetNames.add("Croatia");
        planetNames.add("Bahrain");
        planetNames.add("Riyadh");
        planetNames.add("Sardinia");
        planetNames.add("Corsica");
        planetNames.add("Athens");
        planetNames.add("Sparta");
        planetNames.add("Istanbul");
        planetNames.add("Ankara");
        planetNames.add("Turkey");*/
        
        /*planetNames.add("Albania");
        planetNames.add("Bombay");
        planetNames.add("Mumbia");
        planetNames.add("Bangalore");
        planetNames.add("Shanghai");
        planetNames.add("Osaka");
        planetNames.add("Essen");
        planetNames.add("São Paulo");
        planetNames.add("Addis Ababa");
        planetNames.add("Québec");
        planetNames.add("Halifax");
        planetNames.add("Winnipeg");
        planetNames.add("Regina");
        planetNames.add("Nunavut");
        planetNames.add("Yukon");
        planetNames.add("Denver");
        planetNames.add("Milwaukee");
        planetNames.add("Detroit");
        planetNames.add("Toledo");
        planetNames.add("Concord");
        planetNames.add("Augusta");
        planetNames.add("Norfolk");
        planetNames.add("Philadelphia");
        planetNames.add("Savannah");
        planetNames.add("Atlanta");
        planetNames.add("Tampa");
        planetNames.add("Jackson");
        planetNames.add("Tallahassee");
        planetNames.add("Miami");
        planetNames.add("Orlando");
        planetNames.add("Birmingham");
        planetNames.add("Springfield");
        planetNames.add("Santa Fe");
        planetNames.add("Portland");
        planetNames.add("Seattle");
        planetNames.add("Honolulu");
        planetNames.add("Juneau");
        planetNames.add("Anchorage");
        planetNames.add("Buffalo");
        planetNames.add("Newark");
        planetNames.add("Campeche");
        planetNames.add("Oaxaca");
        planetNames.add("Veracruz");
        planetNames.add("Guadalajara");
        planetNames.add("Zacatecas");
        planetNames.add("Sonora");
        planetNames.add("Acapulco");
        planetNames.add("Sofia");
        planetNames.add("Venice");
        planetNames.add("Milan");
        planetNames.add("Genoa");
        planetNames.add("Lyon");
        planetNames.add("Canberra");
        planetNames.add("Queensland");
        planetNames.add("New Britain");
        planetNames.add("Sydney");
        planetNames.add("Derby");
        planetNames.add("Tasmania");
        planetNames.add("Wellington");
        planetNames.add("Perth");
        planetNames.add("Darwin");
        planetNames.add("Newcastle");
        planetNames.add("Samoa");
        planetNames.add("Polynesia");
        planetNames.add("New Caledonia");
        planetNames.add("Palau");
        planetNames.add("The Netherlands");
        planetNames.add("The Hague");*/
        
        /*if (Math.random() > .5)
        {
            name = "H.M.S. " + planetNames.get((int)(Math.random()*planetNames.size()));
        }
        else
        {
            name = "U.S.S. " + planetNames.get((int)(Math.random()*planetNames.size()));
        }*/
        name = "S.S. " + planetNames.get((short)(Math.random()*planetNames.size()));
        
        this.hasTitanium = false;
        this.hasPromethium = false;
        this.hasUranium = false;
    }
    
    public String getDescription()
    {
        return "Type: " + shipType + "\nName: " + name + "\nCarrier Capacity: " + carrierCapacity + "\nFighters: " + fighters
        + "\nSize: " + size + "\nHealth: " + ((double)(Math.round(health*10)))/10 + "/" + baseHealth + "\nAttack Value: "
        + baseAttack + "\nDefense Value: " + baseDefense + "\nTitanium: " + hasTitanium + "\nPromethium: " + hasPromethium + "\nUranium: " + hasUranium;
    }
    
    public String getType()
    {
        return shipType;
    }

    public double getHealth()
    {
        return health;
    }
    
    public short getAttackValue()
    {
        return baseAttack;
    }
    
    public double getAttack()
    {
        double potato = 0;
        double k = 4;
        for (int i = 0; i < k; i++)
        {
            if(Math.random() < .01)
            {
                potato = potato + ((double)(baseAttack))*2.0/k;
            }
            else if (Math.random() < .7)
            {
                potato = potato + ((double)(baseAttack))/k;
            }
            else if (Math.random() < .7)
            {
                potato = potato + ((double)(baseAttack)*.5)/k;
            }
            else if (Math.random() < .2)
            {
                potato = potato + ((double)(baseAttack)*.1)/k;
            }
        }
        return potato;
    }
    
    public void damage(double hurt)
    {       
        health =  health - (hurt*(Math.pow(.99,baseDefense)));
    }
    
    public static double[] getCost()
    {
        return new double[] {0,metalCost,industryCost,moneyCost};
    }
    
    public void repair()
    {
        health = baseHealth;
    }
    
    public  double[] getRepairCost()
    {
        return new double[] {0.0,metalCost*health*.8/baseHealth ,industryCost*health*.8/baseHealth,moneyCost*health*1.1/baseHealth};
    }
    
    public short getUpkeep()
    {
        if (hasUranium)
        {
            return (short)(fighters*10 + size*5);
        }
        return (short)(fighters*10 + size*25);
    }
    
    public short deployFighters()
    {
        short holder = fighters;
        fighters = 0;
        return holder;
    }
    
    public double[] getUpgradeCosts()
    {
        return new double[] {size*150, size*100,size*75};
    }
    
    public void upgradeTitanium()
    {
        hasTitanium = true;
        baseHealth = (short)(baseHealth + (short)(baseHealth*.7));
    }
    
    public void upgradePromethium()
    {
        hasPromethium = true;
        baseAttack = (short)(baseAttack + (short)(baseAttack*.7));
    }
    
    public void upgradeUranium()
    {
        hasUranium = true;
        baseDefense = (short)(baseDefense + 5);
    }
    
    public boolean[] checkUpgrades()
    {
        return new boolean[] {hasTitanium, hasPromethium, hasUranium};
    }
    
    public short size()
    {
        return size;
    }
    
    public short carrierCapacity()
    {
        return carrierCapacity;
    }
    
    public void addFighters(short i)
    {
        fighters = (short)(fighters + i);
    }
    
    public short populationCapacity()
    {
        return (short)(size*10 + carrierCapacity*10 + 5);
    }
}
