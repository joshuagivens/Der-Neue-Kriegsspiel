
/**
 * Write a description of class SpaceMapShip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class SpaceMapShip
{
    public int fighters;
    public int people;
    public int size;
    public int carrierCapacity;
    public int moneyCost;
    public int metalCost;
    public int industryCost;
    public int baseHealth;
    public int baseAttack;
    public int baseDefense;
    public double health;
    /**
     * Constructor for objects of class SpaceMapShip
     */
    public SpaceMapShip()
    {
        this.health = baseHealth;
    }

    public double getHealth()
    {
        return health;
    }
    
    public int getAttack()
    {
        return baseAttack;
    }
    
    public void damage(double hurt)
    {       
        health =  health - (hurt*(Math.pow(.99,baseDefense)));
    }
    
    public int[] getCost()
    {
        return new int[] {0,metalCost,industryCost,moneyCost};
    }
    
    public void repair()
    {
        health = baseHealth;
    }
    
    public double[] getRepairCost()
    {
        return new double[] {0.0,metalCost*health*.8/baseHealth ,industryCost*health*.8/baseHealth,moneyCost*health*1.1/baseHealth};
    }
    
    public int getUpkeep()
    {
        return fighters*10 + size*25;
    }
    
    public int deployFighters()
    {
        int holder = fighters;
        fighters = 0;
        return holder;
    }
}
