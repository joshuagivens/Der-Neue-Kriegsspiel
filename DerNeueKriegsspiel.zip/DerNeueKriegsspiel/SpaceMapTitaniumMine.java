
/**
 * Write a description of class SpaceMapTitaniumMine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapTitaniumMine extends SpaceMapBuilding
{
    
    /**
     * Constructor for objects of class SpaceMapTitaniumMine
     */
    public SpaceMapTitaniumMine()
    {
        
    }

    public double[] getProduction()
    {
        return new double[]{0,0,25,35,0,10,0};
    }
}
