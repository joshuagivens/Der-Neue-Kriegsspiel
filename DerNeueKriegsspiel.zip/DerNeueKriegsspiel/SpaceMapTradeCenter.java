
/**
 * Write a description of class SpaceMapTradeCenter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapTradeCenter extends SpaceMapBuilding
{
    

    /**
     * Constructor for objects of class SpaceMapTradeCenter
     */
    public SpaceMapTradeCenter()
    {
        
    }

    public double[] getProduction()
    {
        return new double[]{0,0,0,875,0,0,0};
    }
}
