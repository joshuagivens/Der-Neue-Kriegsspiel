   
/**
 * Write a description of class SpaceMapCorvette here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapTransport extends SpaceMapShip
{
    public static int moneyCost = 1000;

    /**
     * Constructor for objects of class SpaceMapCorvette
     */
    public SpaceMapTransport()
    {     
        this.shipType = "Tranport";
        this.size = 0;
        this.carrierCapacity = 200;
        //this.moneyCost = 1000;
        this.metalCost = 800;
        this.industryCost = 800;
        this.baseHealth = 25;
        this.baseAttack = 1;
        this.baseDefense = 15;       
        this.health = baseHealth;
    }

    public short carrierCapacity()
    {
        return 0;
    }
    
    public short getOpenCarrierSpace()
    {
        return 0;
    }
}

