
/**
 * Write a description of class SpaceMapUraniumMine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceMapUraniumMine extends SpaceMapBuilding
{
    

    /**
     * Constructor for objects of class SpaceMapUraniumMine
     */
    public SpaceMapUraniumMine()
    {
        
    }

    public double[] getProduction()
    {
        return new double[]{0,0,35,50,10,0,0};
    }
}
