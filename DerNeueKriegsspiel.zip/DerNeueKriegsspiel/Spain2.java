
/**
 * Write a description of class Spain2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spain2
{
    Spain2Player[] playerArray = new Spain2Player[] {null,null,null};//3
    Spain2Territory[] territoryArray = new Spain2Territory[] {null,null,null, null, null,null,null, null, null,null,null, null, null,null,null, null, null,null,null, null, null,null,null, null, null, null};//26
    
    /**
     * Constructor for objects of class Spain2
     */
    public Spain2(/*boolean p1Player, boolean p2Player, boolean p3Player*/)
    {
        this.playerArray[0] = new Spain2Player("Fascist Faction",25000, 25000, 500, 1000, 3000, 25, /*p1Player*/ false,true);
        this.playerArray[1] = new Spain2Player("German Support", 0,0,0,0,0,0,/*p2Player*/false,true);
        this.playerArray[2] = new Spain2Player("Republican Faction", 35000, 35000, 2000, 6000, 2000, 25, /*p3Player*/false,false);
        
        this.territoryArray[0] = new Spain2Territory("Spanish Sahara", 250, 100, 50, 75, 3500, playerArray[0]);
        this.territoryArray[1] = new Spain2Territory("Spanish Morocco", 3500, 5000, 125, 550, 23500, playerArray[0]);
        this.territoryArray[2] = new Spain2Territory("Majorca", 4500, 7250, 165, 850, 43500, playerArray[0]);
        this.territoryArray[3] = new Spain2Territory("Minorca", 3500, 5000, 75, 400, 20000, playerArray[2]);
        this.territoryArray[4] = new Spain2Territory("Ibiza", 2500, 4000, 25, 550, 17000, playerArray[0]);
        this.territoryArray[5] = new Spain2Territory("East Canaries", 3800, 6500, 100, 450, 30000, playerArray[0]);
        this.territoryArray[6] = new Spain2Territory("West Canaries", 3800, 6500, 100, 450, 30000, playerArray[0]);
        this.territoryArray[7] = new Spain2Territory("Galicia", 4800, 7250, 110, 660, 50000, playerArray[0]);
        this.territoryArray[8] = new Spain2Territory("Asturias", 3600, 5200, 80, 420, 21000, playerArray[2]);
        this.territoryArray[9] = new Spain2Territory("Northern Old Castile", 2400, 3750, 24, 530, 16000, playerArray[2]);
        this.territoryArray[10] = new Spain2Territory("Basque Country", 2650, 4250, 30, 575, 21000, playerArray[2]);
        this.territoryArray[11] = new Spain2Territory("Navarre", 4850, 7300, 115, 665, 51000, playerArray[0]);
        this.territoryArray[12] = new Spain2Territory("Aragon", 6500, 8000, 175, 750, 67000, playerArray[0]);
        this.territoryArray[13] = new Spain2Territory("Catalonia", 6100, 7800, 165, 720, 66000, playerArray[2]);
        this.territoryArray[14] = new Spain2Territory("León", 6600, 8150, 200, 870, 81000, playerArray[0]);
        this.territoryArray[15] = new Spain2Territory("Cental Old Castile", 5200, 6100, 115, 640, 30000, playerArray[0]);
        this.territoryArray[16] = new Spain2Territory("Rioja", 500, 350, 15, 250, 15000, playerArray[0]);
        this.territoryArray[17] = new Spain2Territory("Southern Old Castile", 4500, 5000, 100, 580, 29000, playerArray[0]);
        this.territoryArray[18] = new Spain2Territory("Madrid", 500, 10000, 85, 650, 20000, playerArray[2]);
        this.territoryArray[19] = new Spain2Territory("East New Castile", 6200, 7700, 125, 690, 17000, playerArray[2]);
        this.territoryArray[20] = new Spain2Territory("Valencia", 5900, 6000, 135, 600, 31000, playerArray[2]);
        this.territoryArray[21] = new Spain2Territory("Extremadura", 4500, 5000, 90, 550, 27000, playerArray[2]);
        this.territoryArray[22] = new Spain2Territory("South-West New Castile", 4400, 4900, 85, 540, 25000, playerArray[2]);
        this.territoryArray[23] = new Spain2Territory("Murcia", 3600, 5100, 77, 410, 20500, playerArray[2]);
        this.territoryArray[24] = new Spain2Territory("Western Andelucia", 4600, 5100, 100, 560, 27500, playerArray[2]);
        this.territoryArray[25] = new Spain2Territory("Eastern Andelucia", 4650, 5150, 100, 560, 27600, playerArray[2]);
    }
    
    public void endTurn(Spain2Player p)
    {
        for(int i = 0; i < territoryArray.length; i++)
        {
            if (territoryArray[i].getName().equals(p.getName()))
            {
                territoryArray[i].addResources(p);
                territoryArray[i].trainMen(p);
            }
        }
        p.healWounded();
    }
    
    
    
}
