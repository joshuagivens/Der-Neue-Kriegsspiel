
/**
 * Write a description of class Spain2Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spain2Player extends Player
{
    boolean isFascist;
    double food;
    double money;
    double oil;
    double industry;
    int trainedMen;
    int wounded;
    /**
     * Constructor for objects of class Spain2Player
     */
    public Spain2Player(String name, int food, int money, int oil, int industry, int trainedMen, int wounded,  boolean isAI, boolean isFascist)
    {
        super(name, isAI);
        this.isFascist = isFascist;
        this.food = food;
        this.money = money;
        this.oil = oil;
        this.industry = industry;
        this.trainedMen = trainedMen;
        this.wounded = wounded;
    }

    void spendResources(int f, int m, int o, int i, int t)
    {
        if (food - f < 0 || money - m < 0 || oil - o < 0 || industry - i < 0 || trainedMen - t < 0)
        {
            throw new IllegalArgumentException("You don't have enough resources!");
        }
        else
        {
            food = food - f;
            money = money - m;
            oil = oil - o;
            industry = industry - i;
            trainedMen = trainedMen - t;
        }
        
    }
    
    void addResources(int f, int m, int o, int i)
    {
        food = food + f;
        money = money + m;
        oil = oil + o;
        industry = industry + i;
        
    }
    
    void healWounded()
    {
        trainedMen = trainedMen + (wounded/10) + (wounded%10);
        wounded = wounded - (wounded/10) - (wounded%10);
    }
    
    void addTrainedMen(int m)
    {
        trainedMen = trainedMen + m;
    }
}
