
/**
 * Write a description of class Spain2Territory here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spain2Territory extends Territory
{
    int foodProduction;
    int moneyProduction;
    int oilProduction;
    int industryProduction;
    
    /**
     * Constructor for objects of class Spain2Territory
     */
    public Spain2Territory(String name, int foodProduction, int moneyProduction, int oilProduction, int industryProduction, int population, /*String[] geographicalFeatures,*/ Spain2Player owner)
    {
        super(name, population,/*geographicalFeatures,*/ owner);
        this.foodProduction = foodProduction;
        this.moneyProduction = moneyProduction;
        this.oilProduction = oilProduction;
        this.industryProduction = industryProduction;
    }

    void addResources(Spain2Player p)
    {
        p.addResources(foodProduction, moneyProduction, oilProduction, industryProduction);
    }
    
    void trainMen(Spain2Player p)
    {
        p.addTrainedMen(population/1000);
        population = population - (population/1000);
        population ++;
    }
    
    void switchOwner(Spain2Player p)
    {
        owner = p;
    }
}
