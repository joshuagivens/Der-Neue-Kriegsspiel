
/**
 * Write a description of class Spain2Unit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spain2UnitGroup extends Unit
{
    int unitCount;
    int foodCost;
    int trainedMenCost;
    int moneyCost;
    int industryCost;
    int foodUpkeep;
    int foodmoveUpkeep;
    int foodFightUpkeep;
    int moneyUpkeep;
    int oilUpkeep;
    int oilmoveUpkeep;
    int oilFightUpkeep;
    Spain2Player owner;
    /**
     * Constructor for objects of class Spain2Unit
     */
    public Spain2UnitGroup(int foodCost,  int moneyCost, int industryCost, int trainedMenCost, int foodUpkeep, int foodmoveUpkeep, int foodFightUpkeep, int moneyUpkeep, int oilUpkeep, int oilmoveUpkeep, int oilFightUpkeep, int move, double combatValue, String unitType, int unitCount, Spain2Player owner)
    {
        super(move,  combatValue, unitType);
        this.foodCost = foodCost;
        this.trainedMenCost = trainedMenCost;
        this.owner = owner;
        this.moneyCost = moneyCost;
        this.industryCost = industryCost;
        this.foodUpkeep = foodUpkeep;
        this.foodmoveUpkeep = foodmoveUpkeep;
        this.foodFightUpkeep = foodFightUpkeep;
        this.moneyUpkeep = moneyUpkeep;
        this.oilUpkeep = oilUpkeep;
        this.oilmoveUpkeep = oilmoveUpkeep;
        this.oilFightUpkeep = oilFightUpkeep;
        this.unitCount = unitCount;
        
    }

    public void buyUnits(int y)
    {
        getOwner().spendResources(foodCost*y,moneyCost*y, 0, industryCost*y,trainedMenCost*y);
        addUnits(y);
        
    }
    
    public void removeUnits(int y)
    {
        unitCount = unitCount - y;
         
    }
    
    public void addUnits(int y)
    {
        unitCount = unitCount + y;
         
    }
    
    public Spain2UnitGroup[] conductBattle(Spain2UnitGroup[] battleGroup)
    {
        
        return battleGroup;
    }
    
    public Spain2Player getOwner()
    {
        return owner;
    }
}
