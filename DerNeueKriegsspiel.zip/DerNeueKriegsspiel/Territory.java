
/**
 * Write a description of class Territory here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Territory
{
    Player owner;
    int population;
    //String[] geographicalFeatures;
    String name;
    /**
     * Constructor for objects of class Territory
     */
    public Territory(String name,int population, /*String[] geographicalFeatures,*/ Player owner)
    {
        this.owner = owner;
        this.population = population;
        this.name = name;
        
        /*this.geographicalFeatures = geographicalFeatures;*/
        
    }

    public String getName()
    {
        return owner.getName();
    }
}
