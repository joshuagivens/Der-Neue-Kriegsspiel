
/**
 * Write a description of class Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tester
{
    

    /**
     * Constructor for objects of class Tester
     */
    public Tester()
    {
        
    }

    public static void actions()
    {
        SpaceMapFunStringGenerator a = new SpaceMapFunStringGenerator();      
        for (int i = 0; i < 5; i++)
        {
            //System.out.println(a.getTheRandomAction("The Klingon Empire"));
        }        
    }
    
    
    public static void puppy()
    {
        //SpaceMapCorvette
        //SpaceMapFrigate
        //SpaceMapDestroyer
        //SpaceMapLightCruiser
        
        //SpaceMapBattleship
        
        SpaceMapTransport a = new SpaceMapTransport();
        //System.out.println(a.getDescription());
        //String[] funArray = new String[25];
        System.out.println("");
        System.out.println("");
        a.upgradePromethium();
        a.upgradeUranium();
        a.upgradeTitanium();
        a.repair();
        //System.out.println("Upgraded vessel");
        System.out.println("");
        System.out.println(a.getDescription());
        System.out.println("");
        System.out.println("");
        SpaceMapBattleship b = new SpaceMapBattleship();
        b.upgradePromethium();
        b.upgradeUranium();
        b.upgradeTitanium();
        b.repair();
        System.out.println(b.getDescription());
        
        System.out.println("");
        System.out.println("");
        SpaceMapHeavyBattleship d = new SpaceMapHeavyBattleship();
        d.upgradePromethium();
        d.upgradeUranium();
        d.upgradeTitanium();
        d.repair();
        System.out.println(d.getDescription());
        System.out.println("");
        System.out.println("");
        SpaceMapHeavyBattleship e = new SpaceMapHeavyBattleship();
        e.upgradePromethium();
        e.upgradeUranium();
        e.upgradeTitanium();
        e.repair();
        System.out.println(e.getDescription());
        System.out.println("");
        System.out.println("");
        SpaceMapHeavyBattleship f = new SpaceMapHeavyBattleship();
        f.upgradePromethium();
        f.upgradeUranium();
        f.upgradeTitanium();
        f.repair();
        System.out.println(f.getDescription());
        System.out.println("");
        System.out.println("");
        SpaceMapHeavyBattleship g = new SpaceMapHeavyBattleship();
        g.upgradePromethium();
        g.upgradeUranium();
        g.upgradeTitanium();
        g.repair();
        System.out.println(g.getDescription());
        
        /*for(int i = 0; i < 8; i++)
        {
            b.damage(a.getAttack());
            a.damage(b.getAttack());
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println(a.getDescription());
            System.out.println("");
            System.out.println(b.getDescription());
        }*/
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        SpaceMapSectorDominanceShip c = new SpaceMapSectorDominanceShip();
        //c.upgradePromethium();
        //c.upgradeUranium();
        //c.upgradeTitanium();
        //c.repair();
        double fire0 = 0;
        double fire1 = 0;
        double fire2 = 0;
        double fire3 = 0;
        double fire5 = 0;
        double fire6 = 0;
        double total = 0;
        double fire4 = 0;
        System.out.println(c.getDescription());
        
        for (int i = 0; i < 5; i++)
        {
            fire1 = a.getAttack();
            System.out.println("" + fire1);
            fire2 = b.getAttack();
            System.out.println("" + fire2);
            fire3 = d.getAttack();
            System.out.println("" + fire3);
            fire0 = e.getAttack();
            System.out.println("" + fire0);
            fire5 = f.getAttack();
            System.out.println("" + fire5);
            fire6 = g.getAttack();
            System.out.println("" + fire6);
            total = fire1 + fire2 + fire3 + fire0 + fire5 + fire6;
            System.out.println("Total team 1 = " + total);
            fire4 = c.getAttack();
            System.out.println("");
            System.out.println("" + fire4);
            c.damage(total);
            double[] damSpread = new double[6]; 
            double h;        
            double ran = 0;
            h = Math.random();
            damSpread[0] = h*a.size()+a.size()+ .1;
            ran = h*a.size()+a.size()+ .1;
            h = Math.random();
            damSpread[1] = h*b.size()+b.size()+ .1;
            ran = h*b.size()+b.size()+ .1;
            h = Math.random();
            damSpread[2] = h*d.size()+d.size()+ .1;
            ran = h*d.size()+d.size()+ .1;
            h = Math.random();
            damSpread[3] = h*e.size()+e.size()+ .1;
            ran = h*e.size()+e.size()+ .1;
            h = Math.random();
            damSpread[4] = h*f.size()+f.size()+ .1;
            ran = h*f.size()+f.size()+ .1;
            h = Math.random();
            damSpread[5] = h*g.size()+g.size()+ .1;
            ran = h*g.size()+g.size()+ .1;
            a.damage(fire4*damSpread[0]/ran);
            b.damage(fire4*damSpread[1]/ran);
            d.damage(fire4*damSpread[2]/ran);
            e.damage(fire4*damSpread[3]/ran);
            f.damage(fire4*damSpread[4]/ran);
            g.damage(fire4*damSpread[5]/ran);
            System.out.println("");
            System.out.println(a.getDescription());
            System.out.println("");
            System.out.println(b.getDescription());
            System.out.println("");
            System.out.println(d.getDescription());
            System.out.println("");
            System.out.println(e.getDescription());
            System.out.println("");
            System.out.println(f.getDescription());
            System.out.println("");
            System.out.println(g.getDescription());
            System.out.println("");
            System.out.println("");
            System.out.println(c.getDescription());
            
            System.out.println("");
            System.out.println("");
            System.out.println("");
        }
    }
}
