
/**
 * Abstract class Unit - write a description of the class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public  class Unit
{
    
    int move;
    String[] targetingPriority;
    double combatValue;
    String unitType;
    public Unit(int move, String[] targetingPriority, double combatValue, String unitType)
    {
        
        this.move = move;
        this.targetingPriority = targetingPriority;
        this.combatValue = combatValue;
        this.unitType = unitType;
    }
    
    
}
